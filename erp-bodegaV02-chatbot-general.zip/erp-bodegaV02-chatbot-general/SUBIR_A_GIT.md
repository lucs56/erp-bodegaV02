# Subir esta corrección a erp-bodegaV02

Repositorio correcto:

https://github.com/lucs56/erp-bodegaV02

## Si ya tenés el repositorio clonado

1. Abrí la carpeta `erp-bodegaV02` en el Explorador.
2. Copiá dentro de esa carpeta todo el contenido de este paquete, reemplazando los archivos que Windows pregunte.
3. No borres la carpeta oculta `.git` ni archivos adicionales que ya existan en el repositorio.
4. Abrí Git Bash dentro de `erp-bodegaV02` y ejecutá:

```bash
git status
git add -A
git commit -m "Mejorar sincronizacion multiusuario y habilitar chatbot general"
git push origin main
```

Si Git informa que el remoto tiene cambios más nuevos:

```bash
git pull --rebase origin main
git push origin main
```

## Si todavía no tenés el repositorio clonado

```bash
git clone https://github.com/lucs56/erp-bodegaV02.git
cd erp-bodegaV02
```

Después copiá dentro de esa carpeta el contenido de este paquete y ejecutá los comandos del bloque anterior.

## Qué corrige esta versión

- La sincronización automática ya no deja la interfaz varios segundos en `Actualizando...`.
- El primer ingreso espera una lectura útil si D1 todavía está vacío.
- Los ciclos automáticos leen D1 inmediatamente y revalidan Google en segundo plano.
- El lock distribuido en D1 evita que múltiples dispositivos consulten Google Sheets al mismo tiempo.
- Si Google falla, se conserva la última programación válida de D1.
- El chatbot deja de estar limitado al ERP cuando la API de OpenAI está configurada.
- El chatbot conserva los últimos mensajes de la conversación.
- Para consultas recientes puede usar búsqueda web.
- Si el modelo configurado no existe o no está disponible, prueba modelos compatibles de respaldo.
