import { NextResponse } from "next/server";
import {
  readLastStoredProgram,
  readLiveProgram,
  readProgramSyncState,
  type LiveProgram,
} from "../../../lib/google-sheets";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const mode = new URL(request.url).searchParams;

  if (mode.get("stored") === "1") {
    const [stored, state] = await Promise.all([
      readLastStoredProgram(),
      readProgramSyncState(),
    ]);
    return stored
      ? liveResponse(
          stored,
          !state.lastError,
          state.lastError
            ? "Google Sheets tuvo un error; se conserva la última lectura válida compartida en D1."
            : state.syncing
              ? "Sincronización central en curso. La pantalla sigue operativa con la última lectura completada."
              : "Programación compartida desde Cloudflare D1.",
          state.syncing,
        )
      : snapshotResponse("La primera lectura de Google Sheets todavía no fue completada.");
  }

  // Ciclo normal de los navegadores: responde inmediatamente con D1 y deja que
  // un único Worker intente actualizar Google. El lock distribuido evita que
  // 100 usuarios se conviertan en 100 lecturas simultáneas del Sheet.
  if (mode.get("background") === "1") {
    const stored = await readLastStoredProgram();
    scheduleBackgroundRefresh();
    return stored
      ? liveResponse(
          stored,
          true,
          "Programación compartida desde D1. La actualización de Google se ejecuta en segundo plano sin bloquear la pantalla.",
          true,
        )
      : snapshotResponse("Todavía no hay una lectura compartida. La sincronización inicial fue solicitada.");
  }

  try {
    const force = mode.get("fresh") === "1";
    const stored = force ? null : await readLastStoredProgram();

    // Para una navegación normal, si ya existe una copia válida en D1 la
    // devolvemos de inmediato y revalidamos por detrás. Así ningún usuario
    // espera a Google solamente por abrir el ERP.
    if (stored && !force) {
      scheduleBackgroundRefresh();
      const state = await readProgramSyncState();
      return liveResponse(
        stored,
        !state.lastError,
        state.lastError
          ? "Google Sheets tuvo un error; se conserva la última lectura válida compartida en D1."
          : "Programación compartida desde D1. La revalidación de Google no bloquea la pantalla.",
        state.syncing,
      );
    }

    // Si D1 está vacío (primer despliegue) o el usuario pulsa "Actualizar
    // ahora", esta petición sí espera al líder para garantizar una respuesta
    // útil en vez de dejar la pantalla en cero durante varios ciclos.
    const live = await readLiveProgram(force);
    if (!live) {
      return snapshotResponse("Todavía no existe una lectura válida de Google Sheets.");
    }

    const state = await readProgramSyncState();
    return liveResponse(
      live,
      !state.lastError,
      state.lastError
        ? "Google Sheets tuvo un error; se conserva la última lectura válida compartida en D1."
        : "Programación sincronizada y compartida desde D1.",
      state.syncing,
    );
  } catch {
    const [stored, state] = await Promise.all([
      readLastStoredProgram(),
      readProgramSyncState(),
    ]);
    if (stored) {
      return liveResponse(
        stored,
        false,
        "Google no respondió; el ERP sigue funcionando con la última lectura real guardada en D1.",
        state.syncing,
      );
    }
    return snapshotResponse("No se pudo leer Google Sheets y todavía no existe una lectura real guardada.");
  }
}

function scheduleBackgroundRefresh() {
  const refresh = readLiveProgram(false).catch(() => null);
  void import("cloudflare:workers")
    .then((workers) => workers.waitUntil(refresh))
    .catch(() => {
      // En validación local no existe el runtime de Cloudflare. La promesa ya
      // quedó iniciada; en producción waitUntil mantiene vivo el trabajo.
      void refresh;
    });
}

function liveResponse(
  live: LiveProgram,
  isLive: boolean,
  notice?: string,
  syncing = false,
) {
  return NextResponse.json(
    {
      source: {
        mode: isLive ? "live" : "stored",
        live: isLive,
        title: live.title,
        fetchedAt: live.fetchedAt,
        notice,
        syncing,
      },
      records: live.weeks.flatMap((week) => week.records),
      diagnostics: live.weeks.flatMap((week) =>
        week.diagnostics.map((item) => ({
          ...item,
          weekId: week.weekId,
          weekLabel: week.weekLabel,
        })),
      ),
    },
    {
      headers: {
        "cache-control": "private, no-store, max-age=0",
      },
    },
  );
}

function snapshotResponse(notice: string) {
  return NextResponse.json(
    {
      source: {
        mode: "unavailable",
        live: false,
        title: "Programación",
        fetchedAt: new Date().toISOString(),
        notice,
        syncing: false,
      },
      records: [],
      diagnostics: [],
    },
    { headers: { "cache-control": "private, no-store, max-age=0" } },
  );
}
