"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  PROGRAM_SOURCE,
  type ProgramRecord,
} from "../lib/program-data";
import { diffProgram } from "../lib/program-diff";
import { parseStockRows, type StockImportItem } from "../lib/stock-import";
import { suggestBomFromProgram } from "../lib/bom-suggestions";
import {
  generalAssistantFallback,
  type GeneralAssistantContext,
} from "../lib/assistant";
import {
  calculateClientRequirements,
  type ClientStockItem,
} from "../lib/client-requirements";
import { fetchWithRetry, RequestTimeoutError } from "../lib/resilient-fetch";

type View =
  | "resumen"
  | "programacion"
  | "productos"
  | "bom"
  | "consumos"
  | "stock"
  | "faltantes"
  | "usuarios"
  | "pendiente";
type BomItem = {
  materialCode: string;
  materialName: string;
  category: string;
  quantity: number;
  unit: string;
  action: string;
  substitutes: string[];
};
type BomProduct = { id: number; code: string; name: string; items: BomItem[] };
type OperationalSettings={spreadsheetId:string;syncIntervalSeconds:number;cacheSeconds:number;includedDepots:string[]};
const DEFAULT_OPERATIONAL_SETTINGS:OperationalSettings={spreadsheetId:"1XL44rx3sNKpxowAQzY1iSjy7s8lYOsPTMngD6xeBDPQ",syncIntervalSeconds:30,cacheSeconds:30,includedDepots:["2","13","C18","R18","2OB"]};
type Requirement = {
  materialCode: string;
  materialName: string;
  category: string;
  unit: string;
  total: number;
  substitutes: string[];
  weeks: Array<{ weekId: string; weekLabel: string; quantity: number }>;
  products: Array<{
    productCode: string;
    productName: string;
    quantity: number;
  }>;
};
type ShortageRequirement = Requirement & {
  groupKey: string;
  stockCodes: string[];
  originalTotal: number;
  pendingNeed: number;
  available: number;
  transferred: number;
  effectiveAvailable: number;
  depots: Record<string,number>;
  stockBreakdown: Array<{
    materialCode: string;
    materialName: string;
    quantity: number;
    depots: Record<string,number>;
  }>;
  weeklyShortages: Array<{
    weekId: string;
    weekLabel: string;
    quantity: number;
    transferred: number;
    pendingQuantity: number;
    covered: number;
    shortage: number;
    remainingAvailable: number;
  }>;
  shortage: number;
};
type LineTransferRecord = {
  materialKey: string;
  materialCode: string;
  quantity: number;
  updatedAt: string;
};
type CalculationStatusState = {
  running: boolean;
  phase: string;
  lastCalculatedAt: string;
  sourceMessage: string;
};
type ProgramRefreshMode = "standard" | "automatic" | "stored";
const emptyBomItem = (): BomItem => ({
  materialCode: "",
  materialName: "",
  category: "Botellas",
  quantity: 1,
  unit: "unidad",
  action: "FRACCIONAR",
  substitutes: [],
});

function summarizeWeeks(records: ProgramRecord[]) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const ids = [...new Set(records.map((record) => record.weekId))].sort();
  return ids.map((id, index) => {
    const weekRecords = records.filter((record) => record.weekId === id);
    const start = new Date(`${id}T00:00:00`);
    const end = new Date(start);
    end.setDate(end.getDate() + 6);
    const tentative = weekRecords.some((record) =>
      record.sourceSheet.toLocaleUpperCase("es").includes("TENTATIVO"),
    );
    const current = today >= start && today <= end;
    const status = tentative
      ? "Tentativa"
      : current
        ? "Actual"
        : start > today
          ? "Próxima"
          : "Cerrada";
    const detail = tentative
      ? "Plan preliminar"
      : current
        ? "Esta semana"
        : start > today
          ? `Semana futura ${index + 1}`
          : "Semana anterior";
    return {
      id,
      label: weekRecords[0]?.weekLabel ?? id,
      status,
      detail,
      fractionBottles: weekRecords
        .filter((record) => record.action === "FRACCIONAR")
        .reduce((total, record) => total + record.bottles, 0),
      operations: weekRecords.length,
      fraccionar: weekRecords.filter((record) => record.action === "FRACCIONAR")
        .length,
      vestir: weekRecords.filter((record) => record.action === "VESTIR").length,
      encajonar: weekRecords.filter((record) => record.action === "ENCAJONAR")
        .length,
      issues: weekRecords.filter((record) => !record.productCode).length,
    };
  });
}

function lineLabel(line: string) {
  if (line === "tareas-manuales") return "Tareas manuales";
  const number = line.match(/\d+/)?.[0];
  return number ? `Línea ${number}` : "Sin sector";
}

function formatNumber(value: number) {
  return new Intl.NumberFormat("es-AR").format(value);
}

function formatCalculationTime(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? "sin fecha disponible"
    : new Intl.DateTimeFormat("es-AR", {
        dateStyle: "short",
        timeStyle: "medium",
      }).format(date);
}

function materialCodeKey(value: string) {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9]/g, "")
    .toUpperCase();
}

function detectMaterialCode(question: string, knownCodes: Map<string, string>) {
  const candidates = question
    .split(/\s+/)
    .map((value) => materialCodeKey(value))
    .filter((value) => value.length >= 3 && /\d/.test(value));
  const known = candidates.find((candidate) => knownCodes.has(candidate));
  if (known) return knownCodes.get(known) ?? "";
  const normalizedQuestion = question
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toUpperCase();
  const explicitLookup = /\b(CODIGO|INSUMO|MATERIAL|PRODUCTO)\b/.test(
    normalizedQuestion,
  );
  const onlyCode =
    candidates.length === 1 && materialCodeKey(question) === candidates[0];
  return explicitLookup || onlyCode ? (candidates[0] ?? "") : "";
}

function depotLabel(depot:string){
  const labels:Record<string,string>={"13":"13 (Producción)","2":"2 (Depósito 2)",C18:"C18 (Calidad)",R18:"R18", "2OB":"2OB"};
  return labels[depot.trim().toUpperCase()]??depot;
}

function shortageCategoryLabel(category:string){
  const normalized=category.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLocaleLowerCase("es");
  if(normalized.includes("capsul")||(/\btapa/.test(normalized)&&!normalized.includes("tapon")))return "Cápsulas / tapas";
  if(normalized.includes("botell"))return "Botellas";
  if(normalized.includes("tapon")||normalized.includes("corcho"))return "Tapones / corchos";
  if(normalized.includes("caja")||normalized.includes("embal"))return "Cajas";
  if(normalized.includes("etiquet")||normalized.includes("collarin"))return "Etiquetas";
  if(normalized.includes("film")||normalized.includes("separador")||normalized.includes("pallet"))return "Embalaje auxiliar";
  return category.trim()||"Otros";
}

function escapeReportHtml(value:string|number){
  return String(value).replace(/[&<>"']/g,(character)=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"})[character]??character);
}

function buildShortageReportHtml(items:ShortageRequirement[],sourceDate:string){
  const order=["Cápsulas / tapas","Botellas","Tapones / corchos","Cajas","Etiquetas","Embalaje auxiliar","Otros"];
  const grouped=new Map<string,ShortageRequirement[]>();
  for(const item of items){const label=shortageCategoryLabel(item.category);const values=grouped.get(label)??[];values.push(item);grouped.set(label,values);}
  const groups=[...grouped.entries()].sort(([left],[right])=>{const li=order.indexOf(left),ri=order.indexOf(right);return (li<0?999:li)-(ri<0?999:ri)||left.localeCompare(right);});
  const number=(value:number)=>new Intl.NumberFormat("es-AR").format(value);
  const generated=new Intl.DateTimeFormat("es-AR",{dateStyle:"long",timeStyle:"short"}).format(new Date());
  const totalShortage=items.reduce((sum,item)=>sum+item.shortage,0);
  const totalOriginalNeed=items.reduce((sum,item)=>sum+item.originalTotal,0);
  const totalNeed=items.reduce((sum,item)=>sum+item.pendingNeed,0);
  const totalStock=items.reduce((sum,item)=>sum+item.available,0);
  const totalTransferred=items.reduce((sum,item)=>sum+item.transferred,0);
  const sections=groups.map(([label,values])=>`
    <section class="category">
      <header><div><span>TIPO DE INSUMO</span><h2>${escapeReportHtml(label)}</h2></div><strong>${values.length} insumos · faltante ${number(values.reduce((sum,item)=>sum+item.shortage,0))}</strong></header>
      ${values.map(item=>`
        <article class="material">
          <div class="material-title"><div><h3>${escapeReportHtml(item.materialCode)} · ${escapeReportHtml(item.materialName)}</h3><p>${item.stockCodes.length>1?`Stock compartido entre ${item.stockCodes.map(escapeReportHtml).join(" + ")}`:"Código individual"}</p></div><b>${number(item.shortage)} ${escapeReportHtml(item.unit)} faltantes</b></div>
          <div class="metrics"><div><span>Necesidad total</span><strong>${number(item.total)}</strong><small>Necesidad original ${number(item.originalTotal)} − trasladado ${number(item.transferred)}</small></div><div><span>Stock depósitos</span><strong>${number(item.available)}</strong></div><div><span>Trasladado a línea</span><strong>${number(item.transferred)}</strong><small>Descuenta directamente la necesidad total</small></div><div class="danger"><span>Faltante total</span><strong>${number(item.shortage)}</strong><small>Necesidad total ajustada − stock</small></div></div>
          <h4>Stock por código y depósito</h4>
          <table><thead><tr><th>Código</th><th>Descripción</th><th>Total</th><th>Depósitos</th></tr></thead><tbody>${item.stockBreakdown.map(stockItem=>`<tr><td>${escapeReportHtml(stockItem.materialCode)}</td><td>${escapeReportHtml(stockItem.materialName)}</td><td>${number(stockItem.quantity)}</td><td>${Object.entries(stockItem.depots).map(([depot,quantity])=>`${escapeReportHtml(depotLabel(depot))}: ${number(quantity)}`).join(" · ")||"Sin stock"}</td></tr>`).join("")}</tbody></table>
          <h4>Necesidad y faltante por semana</h4>
          <table><thead><tr><th>Semana</th><th>Necesidad original</th><th>Trasladado</th><th>Necesidad pendiente</th><th>Cubierto por stock</th><th>Faltante</th><th>Saldo stock</th></tr></thead><tbody>${item.weeklyShortages.map(week=>`<tr><td>${escapeReportHtml(week.weekLabel)}</td><td>${number(week.quantity)}</td><td>${number(week.transferred)}</td><td>${number(week.pendingQuantity)}</td><td>${number(week.covered)}</td><td class="danger-text">${number(week.shortage)}</td><td>${number(week.remainingAvailable)}</td></tr>`).join("")}</tbody></table>
        </article>`).join("")}
    </section>`).join("");
  return `<!doctype html><html lang="es"><head><meta charset="utf-8"><title>Reporte de faltantes</title><style>
  *{box-sizing:border-box}body{margin:0;background:#f3f6f7;color:#173044;font-family:Arial,sans-serif}.page{max-width:1180px;margin:0 auto;padding:32px}.hero{padding:28px;border-radius:18px;color:white;background:linear-gradient(135deg,#0d3349,#127c82)}.hero p{margin:5px 0 0;opacity:.82}.kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:18px 0}.kpis div,.metrics div{padding:15px;border:1px solid #dbe5e8;border-radius:12px;background:white}.kpis span,.metrics span{display:block;color:#657984;font-size:11px;text-transform:uppercase;letter-spacing:.05em}.kpis strong,.metrics strong{display:block;margin-top:5px;font-size:22px}.category{margin:22px 0}.category>header{display:flex;justify-content:space-between;align-items:end;padding:16px 20px;border-radius:14px 14px 0 0;color:white;background:#173f55}.category header span{font-size:9px;letter-spacing:.12em;opacity:.7}.category header h2{margin:3px 0 0}.category>header>strong{font-size:12px}.material{padding:20px;margin:0 0 12px;border:1px solid #d7e2e5;border-top:0;border-radius:0 0 14px 14px;background:white;page-break-inside:avoid}.material+.material{border-top:1px solid #d7e2e5;border-radius:14px}.material-title{display:flex;justify-content:space-between;gap:20px;align-items:flex-start}.material-title h3{margin:0;font-size:17px}.material-title p{margin:5px 0 0;color:#70818a;font-size:11px}.material-title>b{padding:9px 12px;border-radius:9px;color:#a12e26;background:#fdebea;white-space:nowrap}.metrics{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:16px 0}.metrics .danger{border-color:#f0b4ae;background:#fff4f3}.metrics .danger strong,.danger-text{color:#b1322b}h4{margin:18px 0 8px;font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:#50707b}table{width:100%;border-collapse:collapse;font-size:11px}th{text-align:left;color:#60757f;background:#eef4f5}th,td{padding:9px;border-bottom:1px solid #e4ebed}footer{margin-top:24px;color:#6c7d84;font-size:10px;text-align:center}@media print{body{background:white}.page{max-width:none;padding:12mm}.hero{-webkit-print-color-adjust:exact;print-color-adjust:exact}.category>header{-webkit-print-color-adjust:exact;print-color-adjust:exact}}
  </style></head><body><main class="page"><section class="hero"><small>ERP DE INSUMOS · REPORTE OPERATIVO</small><h1>Faltantes de insumos</h1><p>Programación leída: ${escapeReportHtml(sourceDate||"sin fecha")} · Generado: ${escapeReportHtml(generated)}</p></section><section class="kpis"><div><span>Insumos faltantes</span><strong>${items.length}</strong></div><div><span>Necesidad original</span><strong>${number(totalOriginalNeed)}</strong></div><div><span>Necesidad pendiente</span><strong>${number(totalNeed)}</strong></div><div><span>Faltante</span><strong>${number(totalShortage)}</strong></div></section>${sections}<footer>El traslado se resta una sola vez de la necesidad. Luego el saldo pendiente se compara contra el stock compartido.</footer></main></body></html>`;
}



type ExcelCellStyle={
  font?:{bold?:boolean;color?:{rgb:string};sz?:number};
  fill?:{patternType:"solid";fgColor:{rgb:string}};
  alignment?:{horizontal?:"left"|"center"|"right";vertical?:"top"|"center";wrapText?:boolean};
  border?:Record<string,{style:"thin";color:{rgb:string}}>;
};

type ExcelSheetLayout={
  "!cols"?:Array<{wch:number}>;
  "!rows"?:Array<{hpt:number}>;
  "!merges"?:Array<{s:{r:number;c:number};e:{r:number;c:number}}>;
  "!autofilter"?:{ref:string};
};

function applyExcelCellStyle(
  sheet:Record<string,unknown>,
  address:string,
  style:ExcelCellStyle,
  numberFormat?:string,
){
  const cell=sheet[address] as {s?:ExcelCellStyle;z?:string}|undefined;
  if(!cell)return;
  cell.s=style;
  if(numberFormat)cell.z=numberFormat;
}

function formatExcelSheet(
  XLSX:typeof import("xlsx"),
  sheet:import("xlsx").WorkSheet,
  headerRow:number,
  widths:number[],
  numericColumns:number[]=[],
){
  const layout=sheet as import("xlsx").WorkSheet&ExcelSheetLayout;
  layout["!cols"]=widths.map((wch)=>({wch}));
  layout["!autofilter"]={ref:`A${headerRow}:${XLSX.utils.encode_col(widths.length-1)}${headerRow}`};
  const range=XLSX.utils.decode_range(sheet["!ref"]??"A1:A1");
  const border={
    top:{style:"thin" as const,color:{rgb:"D9E4E8"}},
    bottom:{style:"thin" as const,color:{rgb:"D9E4E8"}},
    left:{style:"thin" as const,color:{rgb:"D9E4E8"}},
    right:{style:"thin" as const,color:{rgb:"D9E4E8"}},
  };
  for(let column=range.s.c;column<=range.e.c;column+=1){
    applyExcelCellStyle(sheet as Record<string,unknown>,XLSX.utils.encode_cell({r:headerRow-1,c:column}),{
      font:{bold:true,color:{rgb:"FFFFFF"}},
      fill:{patternType:"solid",fgColor:{rgb:"173F55"}},
      alignment:{horizontal:"center",vertical:"center",wrapText:true},
      border,
    });
  }
  for(let row=headerRow;row<=range.e.r;row+=1){
    for(let column=range.s.c;column<=range.e.c;column+=1){
      applyExcelCellStyle(
        sheet as Record<string,unknown>,
        XLSX.utils.encode_cell({r:row,c:column}),
        {
          alignment:{horizontal:numericColumns.includes(column)?"right":"left",vertical:"top",wrapText:true},
          border,
        },
        numericColumns.includes(column)?"#,##0":undefined,
      );
    }
  }
}

function uniqueExcelSheetName(label:string,used:Set<string>){
  const base=(label||"Otros").replace(/[\\/?*\[\]:]/g," ").trim().slice(0,31)||"Otros";
  let candidate=base;
  let counter=2;
  while(used.has(candidate.toLocaleLowerCase("es"))){
    const suffix=` ${counter}`;
    candidate=`${base.slice(0,31-suffix.length)}${suffix}`;
    counter+=1;
  }
  used.add(candidate.toLocaleLowerCase("es"));
  return candidate;
}

async function exportShortagesToExcel(items:ShortageRequirement[],sourceDate:string){
  const XLSX=await import("xlsx");
  const workbook=XLSX.utils.book_new();
  workbook.Props={
    Title:"Reporte detallado de faltantes de insumos",
    Subject:"Necesidad, stock, traslados, faltantes, semanas, depósitos y códigos compatibles",
    Author:"ERP de Insumos para Bodega",
    CreatedDate:new Date(),
  };
  const generated=new Intl.DateTimeFormat("es-AR",{dateStyle:"long",timeStyle:"short"}).format(new Date());
  const totalOriginalNeed=items.reduce((sum,item)=>sum+item.originalTotal,0);
  const totalNeed=items.reduce((sum,item)=>sum+item.pendingNeed,0);
  const totalStock=items.reduce((sum,item)=>sum+item.available,0);
  const totalTransferred=items.reduce((sum,item)=>sum+item.transferred,0);
  const totalShortage=items.reduce((sum,item)=>sum+item.shortage,0);
  const order=["Cápsulas / tapas","Botellas","Tapones / corchos","Cajas","Etiquetas","Embalaje auxiliar","Otros"];
  const grouped=new Map<string,ShortageRequirement[]>();
  for(const item of items){
    const label=shortageCategoryLabel(item.category);
    const values=grouped.get(label)??[];
    values.push(item);
    grouped.set(label,values);
  }
  const groups=[...grouped.entries()]
    .map(([label,values])=>[label,values.sort((left,right)=>right.shortage-left.shortage||left.materialCode.localeCompare(right.materialCode))] as const)
    .sort(([left],[right])=>{
      const leftIndex=order.indexOf(left),rightIndex=order.indexOf(right);
      return (leftIndex<0?999:leftIndex)-(rightIndex<0?999:rightIndex)||left.localeCompare(right);
    });

  // Primera hoja: el reporte operativo completo que replica la información visible en la web.
  const depotNames=[...new Set(items.flatMap((item)=>Object.keys(item.depots)))].sort((left,right)=>depotLabel(left).localeCompare(depotLabel(right),"es"));
  const completeHeaders=[
    "Tipo de insumo","Código / grupo","Descripción","Códigos compatibles","Unidad","Semana",
    "Necesidad original semana","Trasladado semana","Necesidad pendiente semana","Cubierto por stock","Faltante semana","Saldo stock después de la semana",
    "Necesidad original total","Trasladado a línea","Necesidad pendiente total","Stock total del grupo","Faltante total","Primer faltante",
    "Productos programados","Stock detallado por código","Stock detallado por depósito",
    ...depotNames.map((depot)=>`Stock · ${depotLabel(depot)}`),
  ];
  const completeRows:Array<Array<string|number>>=[
    ["ERP DE INSUMOS · REPORTE DETALLADO DE FALTANTES"],
    [`Programación leída: ${sourceDate||"Sin fecha disponible"} · Reporte generado: ${generated}`],
    [],
    completeHeaders,
  ];
  for(const [label,values] of groups){
    for(const item of values){
      const products=item.products
        .map((product)=>`${product.productCode} · ${product.productName}: ${formatNumber(product.quantity)}`)
        .join(" | ")||"Sin productos asociados";
      const stockByCode=item.stockBreakdown
        .map((stockItem)=>`${stockItem.materialCode} · ${stockItem.materialName}: ${formatNumber(stockItem.quantity)}`)
        .join(" | ")||"Sin stock";
      const stockByDepot=Object.entries(item.depots)
        .map(([depot,quantity])=>`${depotLabel(depot)}: ${formatNumber(quantity)}`)
        .join(" | ")||"Sin stock";
      const weeks=item.weeklyShortages.length>0?item.weeklyShortages:[{
        weekId:"sin-semana",weekLabel:"Sin semana",quantity:item.originalTotal,transferred:item.transferred,pendingQuantity:item.pendingNeed,covered:Math.min(item.pendingNeed,item.available),shortage:item.shortage,remainingAvailable:Math.max(0,item.available-item.pendingNeed),
      }];
      for(const week of weeks){
        completeRows.push([
          label,item.materialCode,item.materialName,item.stockCodes.join(" + "),item.unit,week.weekLabel,
          week.quantity,week.transferred,week.pendingQuantity,week.covered,week.shortage,week.remainingAvailable,
          item.originalTotal,item.transferred,item.pendingNeed,item.available,item.shortage,firstShortageWeek(item),
          products,stockByCode,stockByDepot,
          ...depotNames.map((depot)=>item.depots[depot]??0),
        ]);
      }
    }
  }
  const complete=XLSX.utils.aoa_to_sheet(completeRows);
  const completeLayout=complete as import("xlsx").WorkSheet&ExcelSheetLayout;
  completeLayout["!merges"]=[
    {s:{r:0,c:0},e:{r:0,c:completeHeaders.length-1}},
    {s:{r:1,c:0},e:{r:1,c:completeHeaders.length-1}},
  ];
  completeLayout["!rows"]=[{hpt:28},{hpt:22},{hpt:8},{hpt:36}];
  const completeWidths=[24,20,46,30,13,28,20,18,22,18,18,22,20,18,22,20,18,26,58,62,48,...depotNames.map(()=>20)];
  const completeNumericColumns=[6,7,8,9,10,11,12,13,14,15,16,...depotNames.map((_,index)=>21+index)];
  formatExcelSheet(XLSX,complete,4,completeWidths,completeNumericColumns);
  applyExcelCellStyle(complete as Record<string,unknown>,"A1",{font:{bold:true,color:{rgb:"FFFFFF"},sz:16},fill:{patternType:"solid",fgColor:{rgb:"127C82"}},alignment:{horizontal:"left",vertical:"center"}});
  applyExcelCellStyle(complete as Record<string,unknown>,"A2",{font:{bold:true,color:{rgb:"FFFFFF"},sz:10},fill:{patternType:"solid",fgColor:{rgb:"173F55"}},alignment:{horizontal:"left",vertical:"center"}});
  const detailBorder={
    top:{style:"thin" as const,color:{rgb:"D9E4E8"}},bottom:{style:"thin" as const,color:{rgb:"D9E4E8"}},
    left:{style:"thin" as const,color:{rgb:"D9E4E8"}},right:{style:"thin" as const,color:{rgb:"D9E4E8"}},
  };
  const completeRange=XLSX.utils.decode_range(complete["!ref"]??"A1:A1");
  for(let row=4;row<=completeRange.e.r;row+=1){
    const alternatingFill=row%2===0?"F7FAFB":"FFFFFF";
    for(let column=0;column<=completeRange.e.c;column+=1){
      const isNumber=completeNumericColumns.includes(column);
      applyExcelCellStyle(complete as Record<string,unknown>,XLSX.utils.encode_cell({r:row,c:column}),{
        fill:{patternType:"solid",fgColor:{rgb:alternatingFill}},
        alignment:{horizontal:isNumber?"right":"left",vertical:"top",wrapText:true},
        border:detailBorder,
      },isNumber?"#,##0":undefined);
    }
    for(const column of [10,16]){
      applyExcelCellStyle(complete as Record<string,unknown>,XLSX.utils.encode_cell({r:row,c:column}),{
        font:{bold:true,color:{rgb:"A12E26"}},fill:{patternType:"solid",fgColor:{rgb:"FDEBEA"}},
        alignment:{horizontal:"right",vertical:"top",wrapText:true},border:detailBorder,
      },"#,##0");
    }
    for(const column of [7,8,13,14,15]){
      applyExcelCellStyle(complete as Record<string,unknown>,XLSX.utils.encode_cell({r:row,c:column}),{
        font:{bold:true,color:{rgb:"165C46"}},fill:{patternType:"solid",fgColor:{rgb:"EAF7F1"}},
        alignment:{horizontal:"right",vertical:"top",wrapText:true},border:detailBorder,
      },"#,##0");
    }
  }
  XLSX.utils.book_append_sheet(workbook,complete,"Reporte completo");

  const summaryRows:Array<Array<string|number>>=[
    ["ERP DE INSUMOS · REPORTE OPERATIVO"],
    ["Faltantes de insumos"],
    ["Programación leída",sourceDate||"Sin fecha disponible"],
    ["Reporte generado",generated],
    [],
    ["Indicador","Cantidad"],
    ["Insumos faltantes",items.length],
    ["Necesidad original",totalOriginalNeed],
    ["Trasladado a línea",totalTransferred],
    ["Necesidad pendiente",totalNeed],
    ["Stock en depósitos",totalStock],
    ["Faltante total",totalShortage],
    [],
    ["Tipo de insumo","Insumos","Necesidad original","Trasladado","Necesidad pendiente","Stock","Faltante"],
    ...groups.map(([label,values])=>[
      label,
      values.length,
      values.reduce((sum,item)=>sum+item.originalTotal,0),
      values.reduce((sum,item)=>sum+item.transferred,0),
      values.reduce((sum,item)=>sum+item.pendingNeed,0),
      values.reduce((sum,item)=>sum+item.available,0),
      values.reduce((sum,item)=>sum+item.shortage,0),
    ]),
  ];
  const summary=XLSX.utils.aoa_to_sheet(summaryRows);
  const summaryLayout=summary as import("xlsx").WorkSheet&ExcelSheetLayout;
  summaryLayout["!cols"]=[{wch:31},{wch:22},{wch:20},{wch:18},{wch:20},{wch:18},{wch:18}];
  summaryLayout["!merges"]=[{s:{r:0,c:0},e:{r:0,c:6}},{s:{r:1,c:0},e:{r:1,c:6}}];
  summaryLayout["!rows"]=[{hpt:24},{hpt:30}];
  applyExcelCellStyle(summary as Record<string,unknown>,"A1",{font:{bold:true,color:{rgb:"FFFFFF"},sz:12},fill:{patternType:"solid",fgColor:{rgb:"127C82"}},alignment:{horizontal:"left",vertical:"center"}});
  applyExcelCellStyle(summary as Record<string,unknown>,"A2",{font:{bold:true,color:{rgb:"FFFFFF"},sz:20},fill:{patternType:"solid",fgColor:{rgb:"173F55"}},alignment:{horizontal:"left",vertical:"center"}});
  for(const address of ["A6","B6","A14","B14","C14","D14","E14","F14","G14"]){
    applyExcelCellStyle(summary as Record<string,unknown>,address,{font:{bold:true,color:{rgb:"FFFFFF"}},fill:{patternType:"solid",fgColor:{rgb:"173F55"}},alignment:{horizontal:"center",vertical:"center",wrapText:true}});
  }
  const summaryRange=XLSX.utils.decode_range(summary["!ref"]??"A1:A1");
  for(let row=6;row<=summaryRange.e.r;row+=1){
    for(let column=1;column<=6;column+=1){
      applyExcelCellStyle(summary as Record<string,unknown>,XLSX.utils.encode_cell({r:row,c:column}),{alignment:{horizontal:"right",vertical:"center"}},"#,##0");
    }
  }
  XLSX.utils.book_append_sheet(workbook,summary,"Resumen");

  const consolidatedRows:Array<Array<string|number>>=[
    ["Tipo de insumo","Código principal","Descripción","Códigos compatibles","Unidad","Necesidad original","Trasladado a línea","Necesidad pendiente","Stock depósitos","Faltante total","Primer faltante","Stock por depósito","Productos programados"],
    ...groups.flatMap(([label,values])=>values.map((item)=>[
      label,item.materialCode,item.materialName,item.stockCodes.join(" + "),item.unit,item.originalTotal,item.transferred,item.pendingNeed,item.available,item.shortage,firstShortageWeek(item),
      Object.entries(item.depots).map(([depot,quantity])=>`${depotLabel(depot)}: ${formatNumber(quantity)}`).join(" · ")||"Sin stock",
      item.products.map((product)=>`${product.productCode} · ${product.productName}: ${formatNumber(product.quantity)}`).join(" | ")||"Sin productos asociados",
    ])),
  ];
  const consolidated=XLSX.utils.aoa_to_sheet(consolidatedRows);
  formatExcelSheet(XLSX,consolidated,1,[24,18,44,28,13,19,18,20,18,18,25,50,58],[5,6,7,8,9]);
  XLSX.utils.book_append_sheet(workbook,consolidated,"Faltantes");

  const weeklyRows:Array<Array<string|number>>=[["Tipo de insumo","Código principal","Descripción","Códigos compatibles","Semana","Necesidad original","Trasladado","Necesidad pendiente","Cubierto por stock","Faltante","Saldo stock","Necesidad original total","Trasladado total","Necesidad pendiente total","Stock total"]];
  for(const [label,values] of groups){
    for(const item of values){
      for(const week of item.weeklyShortages){
        weeklyRows.push([label,item.materialCode,item.materialName,item.stockCodes.join(" + "),week.weekLabel,week.quantity,week.transferred,week.pendingQuantity,week.covered,week.shortage,week.remainingAvailable,item.originalTotal,item.transferred,item.pendingNeed,item.available]);
      }
    }
  }
  const weekly=XLSX.utils.aoa_to_sheet(weeklyRows);
  formatExcelSheet(XLSX,weekly,1,[24,18,44,28,26,18,16,19,18,16,18,20,18,20,18],[5,6,7,8,9,10,11,12,13,14]);
  XLSX.utils.book_append_sheet(workbook,weekly,"Detalle semanal");

  const stockRows:Array<Array<string|number>>=[["Grupo / código principal","Tipo de insumo","Código compatible","Descripción","Depósito","Stock","Stock total del grupo","Códigos compatibles"]];
  for(const [label,values] of groups){
    for(const item of values){
      for(const stockItem of item.stockBreakdown){
        const depotEntries=Object.entries(stockItem.depots);
        if(depotEntries.length===0){
          stockRows.push([item.materialCode,label,stockItem.materialCode,stockItem.materialName,"Sin stock",0,item.available,item.stockCodes.join(" + ")]);
          continue;
        }
        for(const [depot,quantity] of depotEntries){
          stockRows.push([item.materialCode,label,stockItem.materialCode,stockItem.materialName,depotLabel(depot),quantity,item.available,item.stockCodes.join(" + ")]);
        }
      }
    }
  }
  const stockDetail=XLSX.utils.aoa_to_sheet(stockRows);
  formatExcelSheet(XLSX,stockDetail,1,[24,24,20,44,24,18,20,30],[5,6]);
  XLSX.utils.book_append_sheet(workbook,stockDetail,"Stock por código");

  const usedSheetNames=new Set(workbook.SheetNames.map((name)=>name.toLocaleLowerCase("es")));
  for(const [label,values] of groups){
    const categoryDepotNames=[...new Set(values.flatMap((item)=>Object.keys(item.depots)))].sort();
    const weekNames=[...new Map(values.flatMap((item)=>item.weeklyShortages.map((week)=>[week.weekId,week.weekLabel] as const))).entries()];
    const headers=[
      "Código principal","Descripción","Códigos compatibles","Unidad","Necesidad original","Trasladado a línea","Necesidad pendiente","Stock depósitos","Faltante total","Primer faltante","Productos programados","Stock detallado por código",
      ...categoryDepotNames.map((depot)=>`Stock ${depotLabel(depot)}`),
      ...weekNames.flatMap(([,weekLabel])=>[`Necesidad original · ${weekLabel}`,`Trasladado · ${weekLabel}`,`Necesidad pendiente · ${weekLabel}`,`Cubierto por stock · ${weekLabel}`,`Faltante · ${weekLabel}`,`Saldo stock · ${weekLabel}`]),
    ];
    const rows:Array<Array<string|number>>=[headers];
    for(const item of values){
      const weeksById=new Map(item.weeklyShortages.map((week)=>[week.weekId,week]));
      rows.push([
        item.materialCode,item.materialName,item.stockCodes.join(" + "),item.unit,item.originalTotal,item.transferred,item.pendingNeed,item.available,item.shortage,firstShortageWeek(item),
        item.products.map((product)=>`${product.productCode} · ${product.productName}: ${formatNumber(product.quantity)}`).join(" | ")||"Sin productos asociados",
        item.stockBreakdown.map((stockItem)=>`${stockItem.materialCode}: ${formatNumber(stockItem.quantity)}`).join(" | ")||"Sin stock",
        ...categoryDepotNames.map((depot)=>item.depots[depot]??0),
        ...weekNames.flatMap(([weekId])=>{
          const week=weeksById.get(weekId);
          return week?[week.quantity,week.transferred,week.pendingQuantity,week.covered,week.shortage,week.remainingAvailable]:[0,0,0,0,0,0];
        }),
      ]);
    }
    const categorySheet=XLSX.utils.aoa_to_sheet(rows);
    const widths=[18,44,28,13,19,18,20,18,18,25,58,42,...categoryDepotNames.map(()=>19),...weekNames.flatMap(()=>[20,18,21,20,19,19])];
    const numericColumns=[4,5,6,7,8,...categoryDepotNames.map((_,index)=>12+index),...weekNames.flatMap((_,index)=>{
      const start=12+categoryDepotNames.length+(index*6);
      return [start,start+1,start+2,start+3,start+4,start+5];
    })];
    formatExcelSheet(XLSX,categorySheet,1,widths,numericColumns);
    XLSX.utils.book_append_sheet(workbook,categorySheet,uniqueExcelSheetName(label,usedSheetNames));
  }

  (workbook as typeof workbook&{Workbook?:{Views?:Array<{activeTab:number}>}}).Workbook={Views:[{activeTab:0}]};
  XLSX.writeFile(workbook,`reporte-faltantes-detallado-${new Date().toISOString().slice(0,10)}.xlsx`,{
    compression:true,
    cellStyles:true,
  });
}

async function responseJson<T>(response:Response):Promise<T>{
  const text=await response.text();
  try{return JSON.parse(text) as T;}catch{throw new Error(response.status===503?"El servicio está ocupado. Se conservan los últimos datos válidos y se reintentará automáticamente.":`El servidor devolvió una respuesta inválida (${response.status}).`);}
}

function firstShortageWeek(item: ShortageRequirement) {
  return item.weeklyShortages.find((week)=>week.shortage>0)?.weekLabel??item.weeks[0]?.weekLabel??"Sin semana";
}

function Icon({
  name,
}: {
  name:
    | "calendar"
    | "bottle"
    | "clipboard"
    | "alert"
    | "sync"
    | "sheet"
    | "check"
    | "lock"
    | "search";
}) {
  const common = {
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.8,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  };
  const paths = {
    calendar: (
      <>
        <path d="M6 3v3M18 3v3M4 9h16" />
        <rect x="3" y="5" width="18" height="16" rx="2" />
      </>
    ),
    bottle: (
      <>
        <path d="M9 3h6M10 3v5l-2 3v9h8v-9l-2-3V3" />
        <path d="M8 14h8" />
      </>
    ),
    clipboard: (
      <>
        <rect x="5" y="4" width="14" height="17" rx="2" />
        <path d="M9 4.5V3h6v1.5M9 10h6M9 14h6M9 18h4" />
      </>
    ),
    alert: (
      <>
        <path d="M10.3 4.3 2.8 18a2 2 0 0 0 1.8 3h14.8a2 2 0 0 0 1.8-3L13.7 4.3a2 2 0 0 0-3.4 0Z" />
        <path d="M12 9v4M12 17h.01" />
      </>
    ),
    sync: (
      <>
        <path d="M20 7h-5V2" />
        <path d="M4.9 16a8 8 0 0 0 13.8 1M4 17v5h5" />
        <path d="M19.1 8A8 8 0 0 0 5.3 7" />
      </>
    ),
    sheet: (
      <>
        <path d="M6 2h9l4 4v16H6z" />
        <path d="M14 2v5h5M9 11h7M9 15h7M9 19h5" />
      </>
    ),
    check: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="m8 12 2.5 2.5L16 9" />
      </>
    ),
    lock: (
      <>
        <rect x="5" y="10" width="14" height="11" rx="2" />
        <path d="M8 10V7a4 4 0 0 1 8 0v3" />
      </>
    ),
    search: (
      <>
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-4-4" />
      </>
    ),
  };
  return (
    <svg aria-hidden="true" {...common}>
      {paths[name]}
    </svg>
  );
}

function CalculationStatus({
  status,
  mapped,
  materials,
  shortages,
  stockItems,
}: {
  status: CalculationStatusState;
  mapped: number;
  materials: number;
  shortages: number;
  stockItems: number;
}) {
  const ready = Boolean(status.lastCalculatedAt);
  return (
    <div
      className={`calculation-status ${status.running ? "running" : ready ? "ready" : "pending"}`}
      role="status"
      aria-live="polite"
    >
      <span className="calculation-status-icon">
        <Icon name={status.running ? "sync" : ready ? "check" : "clipboard"} />
      </span>
      <div className="calculation-status-copy">
        <strong>
          {status.running
            ? status.phase
            : ready
              ? "Necesidad comparada con stock"
              : "Cálculo inicial pendiente"}
        </strong>
        <p>
          {status.running
            ? "La aplicación está actualizando las fuentes y volverá a comparar la necesidad con el stock."
            : ready
              ? `Último cálculo: ${formatCalculationTime(status.lastCalculatedAt)}. ${status.sourceMessage}`
              : "Se ejecutará al terminar de cargar la programación, las fichas técnicas y el stock."}
        </p>
      </div>
      {ready && !status.running && (
        <div className="calculation-status-summary">
          <span><b>{mapped}</b> operaciones</span>
          <span><b>{materials}</b> insumos</span>
          <span><b>{shortages}</b> faltantes</span>
          <span><b>{stockItems}</b> registros de stock</span>
        </div>
      )}
    </div>
  );
}

export default function Home() {
  const [session, setSession] = useState<{
    username: string;
    name: string;
    email: string;
    role: string;
    permissions: string;
  } | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [loginDraft, setLoginDraft] = useState({ username: "", password: "" });
  const [loginError, setLoginError] = useState("");
  const [profileOpen, setProfileOpen] = useState(false);
  const [passwordPanelOpen,setPasswordPanelOpen]=useState(false);
  const [passwordDraft,setPasswordDraft]=useState({current:"",next:"",confirm:""});
  const [passwordMessage,setPasswordMessage]=useState("");
  const [records, setRecords] = useState<ProgramRecord[]>([]);
  const recordsRef = useRef<ProgramRecord[]>([]);
  const liveRef = useRef(false);
  const [sourceState, setSourceState] = useState({
    live: false,
    fetchedAt: PROGRAM_SOURCE.capturedAt,
    notice:
      "La conexión productiva de solo lectura todavía no está configurada.",
  });
  const [refreshing, setRefreshing] = useState(false);
  const refreshPromiseRef=useRef<Promise<{changed:boolean;live:boolean}>|null>(null);
  const requirementsPromiseRef=useRef<Promise<boolean>|null>(null);
  const fullRecalculationPromiseRef=useRef<Promise<boolean>|null>(null);
  const [view, setView] = useState<View>("resumen");
  const [adminTab,setAdminTab]=useState<"usuarios"|"configuracion"|"diagnostico">("usuarios");
  const [selectedWeek, setSelectedWeek] = useState("");
  const [query, setQuery] = useState("");
  const [productQuery, setProductQuery] = useState("");
  const [weekFilter, setWeekFilter] = useState("all");
  const [actionFilter, setActionFilter] = useState("all");
  const [lineFilter, setLineFilter] = useState("all");
  const [showChangesOnly,setShowChangesOnly]=useState(false);
  const [settings,setSettings]=useState(DEFAULT_OPERATIONAL_SETTINGS);
  const [settingsDraft,setSettingsDraft]=useState(DEFAULT_OPERATIONAL_SETTINGS);
  const [settingsMessage,setSettingsMessage]=useState("");
  const [bomProducts, setBomProducts] = useState<BomProduct[]>([]);
  const bomProductsRef = useRef<BomProduct[]>([]);
  const [bomLoading, setBomLoading] = useState(false);
  const [bomMessage, setBomMessage] = useState("");
  const [bomQuery, setBomQuery] = useState("");
  const [bomDraft, setBomDraft] = useState({
    code: "",
    name: "",
    items: [emptyBomItem()],
  });
  const [requirements, setRequirements] = useState<Requirement[]>([]);
  const [requirementQuery, setRequirementQuery] = useState("");
  const [shortageQuery, setShortageQuery] = useState("");
  const [shortages, setShortages] = useState<ShortageRequirement[]>([]);
  const [lineTransfers,setLineTransfers]=useState<LineTransferRecord[]>([]);
  const lineTransfersRef=useRef<Record<string,number>>({});
  const [transferDrafts,setTransferDrafts]=useState<Record<string,string>>({});
  const [transferSaving,setTransferSaving]=useState("");
  const [transferMessage,setTransferMessage]=useState("");
  const [requirementState, setRequirementState] = useState({
    loading: false,
    mapped: 0,
    blocked: 0,
    completed: 0,
    provisional: 0,
    stockItems: 0,
    error: "",
  });
  const [calculationStatus, setCalculationStatus] =
    useState<CalculationStatusState>({
      running: false,
      phase: "Preparando cálculo inicial…",
      lastCalculatedAt: "",
      sourceMessage: "",
    });
  const [programChange, setProgramChange] = useState({
    added: 0,
    removed: 0,
    modified: 0,
    total: 0,
    detectedAt: "",
    changedIds: [] as string[],
    changedWeekIds: [] as string[],
  });
  const [stock, setStock] = useState<ClientStockItem[]>([]);
  const stockRef = useRef<ClientStockItem[]>([]);
  const [stockQuery, setStockQuery] = useState("");
  const [stockDraft, setStockDraft] = useState({
    materialCode: "",
    materialName: "",
    category: "Otros",
    quantity: 0,
    unit: "unidad",
  });
  const stockFileRef = useRef<HTMLInputElement>(null);
  const [stockImport, setStockImport] = useState<{
    fileName: string;
    items: StockImportItem[];
    errors: string[];
    loading: boolean;
    message: string;
    includedRows: number;
    excludedRows: number;
  }>({
    fileName: "",
    items: [],
    errors: [],
    loading: false,
    message: "",
    includedRows: 0,
    excludedRows: 0,
  });
  const [users, setUsers] = useState<
    Array<{
      id: number;
      email: string;
      username: string | null;
      name: string;
      role: string;
      active: boolean;
      permissions: string;
      passwordConfigured?:boolean;
    }>
  >([]);
  const [userDraft, setUserDraft] = useState({
    id: 0,
    email: "",
    username: "",
    password: "",
    name: "",
    role: "planner",
    active: true,
    permissions:
      "resumen,programacion,productos,consumos,stock,faltantes",
  });
  const [userMessage, setUserMessage] = useState("");
  const [userQuery, setUserQuery] = useState("");
  const [chatOpen, setChatOpen] = useState(false);
  const [chatInput, setChatInput] = useState("");
  const [chatLoading,setChatLoading]=useState(false);
  const [chatMessages, setChatMessages] = useState<
    Array<{ from: "user" | "bot"; text: string }>
  >([
    {
      from: "bot",
      text: "¡Hola! Soy el asistente del ERP. Puedo ayudarte con stock, faltantes y programación, y también responder preguntas generales de cualquier tema.",
    },
  ]);
  const weeks = useMemo(() => summarizeWeeks(records), [records]);
  const selected = weeks.find((week) => week.id === selectedWeek) ?? weeks[0] ?? {
    id: "",
    label: "Esperando programación",
    status: "Actualizando",
    detail: "Se mostrará la primera semana disponible",
    fractionBottles: 0,
    operations: 0,
    fraccionar: 0,
    vestir: 0,
    encajonar: 0,
    issues: 0,
  };
  const missingCodeRecords = useMemo(
    () => records.filter((record) => !record.completed && !record.productCode),
    [records],
  );
  const withoutEmbeddedMaterials = useMemo(
    () =>
      records.filter((record) =>
        !record.completed&&Object.values(record.materials).every((value) => !value),
      ),
    [records],
  );
  const totalFractionBottles = useMemo(
    () =>
      records
        .filter((record) => record.action === "FRACCIONAR")
        .reduce((total, record) => total + record.bottles, 0),
    [records],
  );
  const actionTotals = useMemo(
    () => ({
      fraccionar: records.filter((record) => record.action === "FRACCIONAR")
        .length,
      vestir: records.filter((record) => record.action === "VESTIR").length,
      encajonar: records.filter((record) => record.action === "ENCAJONAR")
        .length,
    }),
    [records],
  );
  const filteredRows = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase("es");
    return records.filter((record) => {
      if (weekFilter !== "all" && record.weekId !== weekFilter) return false;
      if (actionFilter !== "all" && record.action !== actionFilter)
        return false;
      if (lineFilter !== "all" && record.line !== lineFilter) return false;
      if(showChangesOnly&&!programChange.changedIds.includes(record.id))return false;
      if (!normalized) return true;
      return [
        record.productCode,
        record.brand,
        record.variety,
        record.vintage,
        record.pin,
        record.client,
        record.country,
      ]
        .join(" ")
        .toLocaleLowerCase("es")
        .includes(normalized);
    });
  }, [records, query, weekFilter, actionFilter, lineFilter,showChangesOnly,programChange.changedIds]);
  const groupedProgramRows = useMemo(
    () =>
      weeks
        .map((week) => ({
          week,
          lines: ["linea-1", "linea-2", "linea-3", "tareas-manuales"]
            .map((line) => ({
              line,
              rows: filteredRows
                .filter(
                  (record) => record.weekId === week.id && record.line === line,
                )
                .sort((a, b) => a.sourceRow - b.sourceRow),
            }))
            .filter((group) => group.rows.length),
        }))
        .filter((group) => group.lines.length),
    [weeks, filteredRows],
  );
  const programmedProducts = useMemo(
    () => [
      ...new Map(
        records
          .filter((record) => record.productCode)
          .map((record) => [
            record.productCode,
            {
              code: record.productCode,
              name: `${record.brand} · ${record.variety} ${record.vintage}`.trim(),
            },
          ]),
      ).values(),
    ],
    [records],
  );
  const productReport = useMemo(() => {
    const grouped = new Map<string, ProgramRecord[]>();
    for (const record of records.filter((item) => item.productCode))
      grouped.set(record.productCode, [
        ...(grouped.get(record.productCode) ?? []),
        record,
      ]);
    return [...grouped.entries()]
      .map(([code, rows]) => {
        const descriptions = [
          ...new Set(
            rows.map((row) =>
              `${row.brand} · ${row.variety} ${row.vintage}`.trim(),
            ),
          ),
        ];
        return {
          code,
          description: descriptions[0],
          descriptions,
          operations: [...new Set(rows.map((row) => row.action))],
          weeks: [...new Set(rows.map((row) => row.weekLabel))],
          bottles: rows.reduce((sum, row) => sum + row.bottles, 0),
          inconsistent: descriptions.length > 1,
        };
      })
      .sort((left, right) => left.code.localeCompare(right.code));
  }, [records]);
  const visibleProducts = useMemo(() => {
    const term = productQuery.trim().toLocaleLowerCase("es");
    return term
      ? productReport.filter((item) =>
          `${item.code} ${item.descriptions.join(" ")}`
            .toLocaleLowerCase("es")
            .includes(term),
        )
      : productReport;
  }, [productQuery, productReport]);
  const productsWithSheetMaterials = useMemo(
    () =>
      programmedProducts.filter(
        (product) =>
          suggestBomFromProgram(records, product.code).items.length > 0,
      ),
    [programmedProducts, records],
  );
  const visibleStock = useMemo(() => {
    const term = stockQuery.trim().toLocaleLowerCase("es");
    return term
      ? stock.filter((item) =>
          `${item.materialCode} ${item.materialName} ${item.category} ${Object.keys(item.depots??{}).join(" ")}`
            .toLocaleLowerCase("es")
            .includes(term),
        )
      : stock;
  }, [stock, stockQuery]);
  const visibleBomProducts = useMemo(() => {
    const term = bomQuery.trim().toLocaleLowerCase("es");
    return term
      ? programmedProducts.filter((product) =>
          `${product.code} ${product.name}`
            .toLocaleLowerCase("es")
            .includes(term),
        )
      : programmedProducts;
  }, [programmedProducts, bomQuery]);
  const visibleRequirements = useMemo(() => {
    const term = requirementQuery.trim().toLocaleLowerCase("es");
    return term
      ? requirements.filter((item) =>
          `${item.materialCode} ${item.materialName} ${item.category} ${item.weeks.map((week) => week.weekLabel).join(" ")} ${item.products.map((product) => `${product.productCode} ${product.productName}`).join(" ")}`
            .toLocaleLowerCase("es")
            .includes(term),
        )
      : requirements;
  }, [requirements, requirementQuery]);
  const visibleShortages = useMemo(() => {
    const term = shortageQuery.trim().toLocaleLowerCase("es");
    return term
      ? shortages.filter((item) =>
          `${item.materialCode} ${item.stockCodes.join(" ")} ${item.materialName} ${item.category} ${item.weeks.map((week) => week.weekLabel).join(" ")} ${item.products.map((product) => `${product.productCode} ${product.productName}`).join(" ")}`
            .toLocaleLowerCase("es")
            .includes(term),
        )
      : shortages;
  }, [shortages, shortageQuery]);
  const shortageGroups=useMemo(()=>{
    const order=["Cápsulas / tapas","Botellas","Tapones / corchos","Cajas","Etiquetas","Embalaje auxiliar","Otros"];
    const grouped=new Map<string,ShortageRequirement[]>();
    for(const item of visibleShortages){const label=shortageCategoryLabel(item.category);const values=grouped.get(label)??[];values.push(item);grouped.set(label,values);}
    return [...grouped.entries()]
      .map(([label,items])=>({label,items:items.sort((left,right)=>right.shortage-left.shortage||left.materialCode.localeCompare(right.materialCode)),totalShortage:items.reduce((sum,item)=>sum+item.shortage,0)}))
      .sort((left,right)=>{const li=order.indexOf(left.label),ri=order.indexOf(right.label);return (li<0?999:li)-(ri<0?999:ri)||left.label.localeCompare(right.label);});
  },[visibleShortages]);
  const visibleUsers = useMemo(() => {
    const term = userQuery.trim().toLocaleLowerCase("es");
    return term
      ? users.filter((user) =>
          `${user.name} ${user.username ?? ""} ${user.email} ${user.role} ${user.active ? "activo" : "inactivo"}`
            .toLocaleLowerCase("es")
            .includes(term),
        )
      : users;
  }, [users, userQuery]);
  const bomSuggestion = useMemo(
    () => suggestBomFromProgram(records, bomDraft.code),
    [records, bomDraft.code],
  );

  const loadBoms = useCallback(async () => {
    setBomLoading(true);
    try {
      const response = await fetch("/api/bom", { cache: "no-store" });
      const payload = (await response.json()) as {
        products?: BomProduct[];
        error?: string;
      };
      if (!response.ok)
        throw new Error(payload.error || "No se pudieron cargar las fichas técnicas.");
      const products = payload.products ?? [];
      bomProductsRef.current = products;
      setBomProducts(products);
      setBomMessage("");
      return true;
    } catch (error) {
      setBomMessage(
        error instanceof Error
          ? error.message
          : "No se pudieron cargar las fichas técnicas.",
      );
      return false;
    } finally {
      setBomLoading(false);
    }
  }, []);
  const saveBom = async () => {
    setBomLoading(true);
    setBomMessage("");
    try {
      const response = await fetch("/api/bom", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(bomDraft),
      });
      const payload = (await response.json()) as { error?: string };
      if (!response.ok)
        throw new Error(payload.error || "No se pudo guardar la ficha técnica.");
      setBomDraft({ code: "", name: "", items: [emptyBomItem()] });
      await loadBoms();
      setBomMessage("Ficha técnica guardada correctamente.");
    } catch (error) {
      setBomMessage(
        error instanceof Error ? error.message : "No se pudo guardar la ficha técnica.",
      );
    } finally {
      setBomLoading(false);
    }
  };
  const updateBomItem = (index: number, values: Partial<BomItem>) =>
    setBomDraft((draft) => ({
      ...draft,
      items: draft.items.map((item, itemIndex) =>
        itemIndex === index ? { ...item, ...values } : item,
      ),
    }));
  const applySheetMaterials = () => {
    setBomDraft((draft) => {
      const current = draft.items.filter((item) => item.materialCode.trim());
      const known = new Set(
        current.map((item) => `${item.materialCode}:${item.action}`),
      );
      const additions = bomSuggestion.items.filter(
        (item) => !known.has(`${item.materialCode}:${item.action}`),
      );
      return { ...draft, items: [...current, ...additions] };
    });
    setBomMessage(
      `${bomSuggestion.items.length} referencias encontradas en el Sheet. Revisá descripción y consumo antes de guardar.`,
    );
  };
  const loadLineTransfers=useCallback(async()=>{
    try{
      const response=await fetch("/api/line-transfers",{cache:"no-store"});
      const payload=await responseJson<{transfers?:LineTransferRecord[];error?:string}>(response);
      if(!response.ok)throw new Error(payload.error||"No se pudieron leer los traslados a línea.");
      const transfers=payload.transfers??[];
      lineTransfersRef.current=Object.fromEntries(transfers.map(item=>[item.materialKey,Number(item.quantity)||0]));
      setLineTransfers(transfers);
      setTransferDrafts(current=>{const next={...current};for(const item of transfers)next[item.materialKey]=String(item.quantity);return next;});
      return true;
    }catch(error){
      setTransferMessage(error instanceof Error?error.message:"No se pudieron leer los traslados a línea.");
      return false;
    }
  },[]);
  const loadRequirements = useCallback(async () => {
    if(requirementsPromiseRef.current)return requirementsPromiseRef.current;
    const operation=(async()=>{
      setRequirementState((state) => ({ ...state, loading: true, error: "" }));
      setCalculationStatus((current) => ({
        ...current,
        running: true,
        phase: "Comparando necesidad con stock…",
      }));
      try {
        await new Promise<void>((resolve) =>
          window.requestAnimationFrame(() => resolve()),
        );
        const payload = calculateClientRequirements(
          recordsRef.current,
          bomProductsRef.current,
          stockRef.current,
          lineTransfersRef.current,
        );
        setRequirements(payload.requirements);
        setShortages(payload.shortages);
        setRequirementState({
          loading: false,
          mapped: payload.mappedOperations,
          blocked: payload.blockedOperations,
          completed: payload.completedOperations,
          provisional: payload.provisionalProducts,
          stockItems: payload.stockItems,
          error: "",
        });
        setCalculationStatus((current) => ({
          ...current,
          running: false,
          phase: "Necesidad comparada con stock",
          lastCalculatedAt: new Date().toISOString(),
          sourceMessage:
            current.sourceMessage ||
            "Cálculo realizado con la programación, las fichas técnicas y el stock disponibles.",
        }));
        return true;
      } catch (error) {
        const message =
          error instanceof Error
            ? error.message
            : "No se pudo calcular el consumo.";
        setRequirementState((state) => ({
          ...state,
          loading: false,
          error: message,
        }));
        setCalculationStatus((current) => ({
          ...current,
          running: false,
          phase: "No se pudo completar el cálculo",
          sourceMessage: message,
        }));
        return false;
      }
    })();
    requirementsPromiseRef.current=operation;
    try{return await operation;}finally{if(requirementsPromiseRef.current===operation)requirementsPromiseRef.current=null;}
  }, []);
  const loadStock = useCallback(async () => {
    try {
      const r = await fetch("/api/stock", { cache: "no-store" });
      const p = await responseJson<{ items?: ClientStockItem[] }>(r);
      if (!r.ok) return false;
      const items = p.items ?? [];
      stockRef.current = items;
      setStock(items);
      return true;
    } catch {
      return false;
    }
  }, []);
  const saveLineTransfer=async(materialKey:string,materialCode:string,rawValue?:string)=>{
    const quantity=Number(rawValue??transferDrafts[materialKey]??0);
    if(!Number.isFinite(quantity)||quantity<0){setTransferMessage("Ingresá una cantidad igual o mayor que cero.");return;}
    setTransferSaving(materialKey);
    setTransferMessage("");
    try{
      const response=await fetch("/api/line-transfers",{method:"PUT",headers:{"content-type":"application/json"},body:JSON.stringify({materialKey,materialCode,quantity})});
      const payload=await responseJson<{error?:string}>(response);
      if(!response.ok)throw new Error(payload.error||"No se pudo guardar el traslado.");
      await loadLineTransfers();
      await loadRequirements();
      setTransferMessage(quantity>0?`Traslado de ${formatNumber(quantity)} unidades guardado para ${materialCode}.`:`Se eliminó el traslado informado para ${materialCode}.`);
    }catch(error){setTransferMessage(error instanceof Error?error.message:"No se pudo guardar el traslado.");}
    finally{setTransferSaving("");}
  };
  const downloadShortageReport=async()=>{
    try{
      setTransferMessage("Preparando el reporte Excel…");
      await exportShortagesToExcel(visibleShortages,sourceState.fetchedAt);
      setTransferMessage(`Reporte Excel generado con ${visibleShortages.length} insumos faltantes.`);
    }catch(error){
      setTransferMessage(error instanceof Error?error.message:"No se pudo generar el reporte Excel.");
    }
  };
  const printShortageReport=()=>{
    const previousFrame=document.getElementById("shortage-print-frame");
    previousFrame?.remove();

    const printFrame=document.createElement("iframe");
    printFrame.id="shortage-print-frame";
    printFrame.title="Reporte de faltantes para imprimir";
    printFrame.setAttribute("aria-hidden","true");
    printFrame.style.position="fixed";
    printFrame.style.right="0";
    printFrame.style.bottom="0";
    printFrame.style.width="1px";
    printFrame.style.height="1px";
    printFrame.style.border="0";
    printFrame.style.opacity="0";
    printFrame.style.pointerEvents="none";

    const cleanup=()=>{
      window.setTimeout(()=>printFrame.remove(),250);
    };

    printFrame.addEventListener("load",async()=>{
      try{
        const printWindow=printFrame.contentWindow;
        const printDocument=printFrame.contentDocument;
        if(!printWindow||!printDocument)throw new Error("No se pudo preparar el reporte para imprimir.");
        await printDocument.fonts?.ready;
        printWindow.addEventListener("afterprint",cleanup,{once:true});
        printWindow.focus();
        printWindow.print();
        setTransferMessage("Reporte abierto en el diálogo de impresión. Elegí Guardar como PDF para descargarlo.");
        window.setTimeout(()=>{if(document.body.contains(printFrame))printFrame.remove();},120000);
      }catch(error){
        cleanup();
        setTransferMessage(error instanceof Error?error.message:"No se pudo imprimir el reporte.");
      }
    },{once:true});

    printFrame.srcdoc=buildShortageReportHtml(visibleShortages,sourceState.fetchedAt);
    document.body.appendChild(printFrame);
  };
  const saveStock = async () => {
    const r = await fetch("/api/stock", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(stockDraft),
    });
    if (r.ok) {
      setStockDraft({
        materialCode: "",
        materialName: "",
        category: "Otros",
        quantity: 0,
        unit: "unidad",
      });
      const stockUpdated = await loadStock();
      if (stockUpdated) await loadRequirements();
    }
  };
  const selectStockFile = async (file?: File) => {
    if (!file) return;
    setStockImport({
      fileName: file.name,
      items: [],
      errors: [],
      loading: true,
      message: "Leyendo archivo…",
      includedRows: 0,
      excludedRows: 0,
    });
    try {
      const XLSX = await import("xlsx");
      const workbook = XLSX.read(await file.arrayBuffer(), { type: "array" });
      const rows = workbook.SheetNames.flatMap((name) => {
        const sheet = workbook.Sheets[name];
        return sheet
          ? XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, {
              defval: "",
            })
          : [];
      });
      if (!rows.length) throw new Error("El archivo no contiene filas.");
      const parsed = parseStockRows(rows,new Set(settings.includedDepots));
      setStockImport({
        fileName: file.name,
        ...parsed,
        loading: false,
        message: parsed.items.length
          ? `${parsed.items.length} insumos agrupados y listos para importar.`
          : "No se encontraron filas válidas.",
      });
    } catch (error) {
      setStockImport({
        fileName: file.name,
        items: [],
        errors: [],
        loading: false,
        message:
          error instanceof Error
            ? error.message
            : "No se pudo leer el archivo.",
        includedRows: 0,
        excludedRows: 0,
      });
    }
  };
  const importStock = async () => {
    setStockImport((current) => ({
      ...current,
      loading: true,
      message: "Actualizando stock…",
    }));
    try {
      const r = await fetch("/api/stock/bulk", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ items: stockImport.items }),
      });
      const p = (await r.json()) as { imported?: number; error?: string };
      if (!r.ok) throw new Error(p.error || "No se pudo importar el stock.");
      await loadStock();
      if(requirementsPromiseRef.current)await requirementsPromiseRef.current;
      await loadRequirements();
      setStockImport((current) => ({
        ...current,
        loading: false,
        items: [],
        errors: [],
        message: `Importación completada: ${p.imported ?? 0} insumos actualizados.`,
      }));
    } catch (error) {
      setStockImport((current) => ({
        ...current,
        loading: false,
        message:
          error instanceof Error
            ? error.message
            : "No se pudo importar el stock.",
      }));
    }
  };
  const emptyUserDraft = () => ({
    id: 0,
    email: "",
    username: "",
    password: "",
    name: "",
    role: "planner",
    active: true,
    permissions:
      "resumen,programacion,productos,consumos,stock,faltantes",
  });
  const loadUsers = useCallback(async () => {
    const r = await fetch("/api/users", { cache: "no-store" });
    const p = (await r.json()) as { users?: typeof users };
    if (r.ok) setUsers(p.users ?? []);
  }, []);
  const saveUser = async () => {
    setUserMessage("");
    const r = await fetch("/api/users", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(userDraft),
    });
    const p = (await r.json()) as { error?: string };
    if (r.ok) {
      setUserDraft(emptyUserDraft());
      setUserMessage("Usuario guardado correctamente.");
      await loadUsers();
    } else setUserMessage(p.error || "No se pudo guardar el usuario.");
  };
  const editUser = (user: (typeof users)[number]) => {
    setUserDraft({
      id: user.id,
      email: user.email,
      username: user.username ?? "",
      password: "",
      name: user.name,
      role: user.role,
      active: user.active,
      permissions: user.permissions,
    });
    setUserMessage("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const toggleUser = async (user: (typeof users)[number]) => {
    const r = await fetch("/api/users", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ ...user, active: !user.active }),
    });
    const p = (await r.json()) as { error?: string };
    setUserMessage(
      r.ok
        ? `Acceso ${user.active ? "bloqueado" : "habilitado"} para ${user.name}.`
        : p.error || "No se pudo cambiar el acceso.",
    );
    if (r.ok) await loadUsers();
  };
  const deleteUser = async (user: (typeof users)[number]) => {
    if (user.username === "admin") {
      setUserMessage(
        "La cuenta principal admin está protegida y no puede eliminarse.",
      );
      return;
    }
    if (
      !window.confirm(
        `¿Eliminar definitivamente a ${user.name} (${user.username})?`,
      )
    )
      return;
    const r = await fetch("/api/users", {
      method: "DELETE",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ id: user.id }),
    });
    const p = (await r.json()) as { error?: string };
    if (r.ok) {
      if (userDraft.id === user.id) setUserDraft(emptyUserDraft());
      await loadUsers();
      setUserMessage(`Usuario ${user.name} eliminado correctamente.`);
    } else setUserMessage(p.error || "No se pudo eliminar el usuario.");
  };
  const login = async () => {
    setAuthLoading(true);
    setLoginError("");
    const r = await fetch("/api/auth", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(loginDraft),
    });
    const p = (await r.json()) as { user?: typeof session; error?: string };
    if (r.ok && p.user) {
      setSession(p.user);
      setLoginDraft({ username: "", password: "" });
    } else setLoginError(p.error || "No se pudo iniciar sesión.");
    setAuthLoading(false);
  };
  const logout = async () => {
    setProfileOpen(false);
    await fetch("/api/auth", { method: "DELETE" });
    setSession(null);
    setView("resumen");
  };
  const changeOwnPassword=async()=>{
    setPasswordMessage("");
    if(passwordDraft.next.length<4){setPasswordMessage("La nueva contraseña debe tener al menos 4 caracteres.");return;}
    if(passwordDraft.next!==passwordDraft.confirm){setPasswordMessage("La confirmación no coincide.");return;}
    const response=await fetch("/api/auth",{method:"PATCH",headers:{"content-type":"application/json"},body:JSON.stringify({currentPassword:passwordDraft.current,newPassword:passwordDraft.next})});
    const payload=await response.json() as {error?:string};
    if(!response.ok){setPasswordMessage(payload.error||"No se pudo cambiar la contraseña.");return;}
    setPasswordDraft({current:"",next:"",confirm:""});setPasswordMessage("Contraseña actualizada correctamente.");
  };

  const refreshProgram = useCallback(async (
    force=false,
    mode:ProgramRefreshMode="standard",
  ) => {
    if(refreshPromiseRef.current)return refreshPromiseRef.current;
    const operation=(async()=>{
      // La sincronización automática corre en segundo plano y no bloquea la interfaz.
      // El indicador grande solo se usa cuando el usuario pide una actualización
      // manual o durante una carga estándar que realmente debe esperar respuesta.
      const showActivity=force||mode==="standard";
      if(showActivity)setRefreshing(true);
      try {
        type ProgramPayload={
          source?: { live?: boolean; fetchedAt?: string; notice?: string; syncing?: boolean };
          records?: ProgramRecord[];
        };
        const requestProgram=async(endpoint:string,timeoutMs:number,maxRetries:number)=>{
          const response=await fetchWithRetry(
            endpoint,
            {cache:"no-store"},
            {timeoutMs,maxRetries},
          );
          if(!response.ok)throw new Error("No se pudo actualizar");
          return responseJson<ProgramPayload>(response);
        };
        let changed=false;
        const applyPayload=(payload:ProgramPayload)=>{
          let payloadChanged=false;
          if(Array.isArray(payload.records)){
            if(liveRef.current&&payload.source?.live){
              const change=diffProgram(recordsRef.current,payload.records);
              payloadChanged=change.total>0;
              if(change.total)setProgramChange({...change,detectedAt:new Date().toISOString()});
            }
            recordsRef.current=payload.records;
            setRecords(payload.records);
          }
          liveRef.current=Boolean(payload.source?.live);
          setSourceState({
            live:Boolean(payload.source?.live),
            fetchedAt:payload.source?.fetchedAt??PROGRAM_SOURCE.capturedAt,
            notice:payload.source?.notice??(
              payload.source?.live
                ? "La programación se comparte desde D1 y Google Sheets se actualiza de forma centralizada."
                : "Se conserva la última lectura validada."
            ),
          });
          return payloadChanged;
        };

        const endpoint=force
          ? "/api/program?fresh=1"
          : mode==="automatic"
            ? "/api/program?background=1"
            : mode==="stored"
              ? "/api/program?stored=1"
              : "/api/program";

        const payload=await requestProgram(
          endpoint,
          mode==="automatic"||mode==="stored"?5_000:35_000,
          force?1:0,
        );
        changed=applyPayload(payload)||changed;

        return{changed,live:liveRef.current};
      } catch (error) {
        const timedOut=error instanceof RequestTimeoutError;
        setSourceState((current)=>({
          ...current,
          notice:timedOut
            ? "La sincronización central demoró demasiado. Se conserva la última lectura válida y se volverá a intentar automáticamente."
            : "No se pudo actualizar; se conservan la programación y los cálculos de la última lectura válida.",
        }));
        return{changed:false,live:liveRef.current};
      } finally {
        if(showActivity)setRefreshing(false);
      }
    })();
    refreshPromiseRef.current=operation;
    try{return await operation;}finally{if(refreshPromiseRef.current===operation)refreshPromiseRef.current=null;}
  }, []);
  const loadSettings=useCallback(async()=>{try{const response=await fetch("/api/settings",{cache:"no-store"});const payload=await responseJson<{settings?:OperationalSettings}>(response);if(response.ok&&payload.settings){setSettings(payload.settings);setSettingsDraft(payload.settings);}}catch{}},[]);
  const synchronizeProgram=useCallback(async(
    force=false,
    recalculate=false,
    mode:ProgramRefreshMode="standard",
  )=>{
    const result=await refreshProgram(force,mode);
    if(recalculate||result.changed){
      if(requirementsPromiseRef.current)await requirementsPromiseRef.current;
      await loadRequirements();
    }
    return result;
  },[refreshProgram,loadRequirements]);
  const updateAndRecalculate=useCallback(async()=>{
    if(fullRecalculationPromiseRef.current)return fullRecalculationPromiseRef.current;
    const operation=(async()=>{
      setCalculationStatus((current)=>({
        ...current,
        running:true,
        phase:"Actualizando programación desde Google Sheets…",
      }));
      if(refreshPromiseRef.current)await refreshPromiseRef.current;
      const programResult=await refreshProgram(true);

      setCalculationStatus((current)=>({
        ...current,
        running:true,
        phase:"Actualizando fichas técnicas y stock…",
      }));
      const [bomsUpdated,stockUpdated,transfersUpdated]=await Promise.all([loadBoms(),loadStock(),loadLineTransfers()]);

      setCalculationStatus((current)=>({
        ...current,
        running:true,
        phase:"Comparando necesidad con stock…",
      }));
      if(requirementsPromiseRef.current)await requirementsPromiseRef.current;
      const calculated=await loadRequirements();
      const sourceMessage=[
        programResult.live?"programación actualizada":"última programación válida",
        bomsUpdated?"fichas técnicas actualizadas":"últimas fichas técnicas disponibles",
        stockUpdated?"stock actualizado":"último stock disponible",
        transfersUpdated?"traslados a línea actualizados":"últimos traslados disponibles",
      ].join(" · ");
      setCalculationStatus((current)=>({
        ...current,
        running:false,
        phase:calculated?"Necesidad comparada con stock":"No se pudo completar el cálculo",
        sourceMessage,
      }));
      return calculated;
    })();
    fullRecalculationPromiseRef.current=operation;
    try{return await operation;}finally{if(fullRecalculationPromiseRef.current===operation)fullRecalculationPromiseRef.current=null;}
  },[loadBoms,loadLineTransfers,loadRequirements,loadStock,refreshProgram]);
  const saveSettings=async()=>{setSettingsMessage("Guardando…");try{const response=await fetch("/api/settings",{method:"PUT",headers:{"content-type":"application/json"},body:JSON.stringify(settingsDraft)});const payload=await responseJson<{settings?:OperationalSettings;error?:string}>(response);if(!response.ok||!payload.settings)throw new Error(payload.error||"No se pudo guardar.");setSettings(payload.settings);setSettingsDraft(payload.settings);setSettingsMessage("Configuración guardada en Cloudflare D1.");await synchronizeProgram(true,true);}catch(error){setSettingsMessage(error instanceof Error?error.message:"No se pudo guardar.");}};

  useEffect(() => {
    if(!session)return;
    const runAutomaticCycle=()=>{
      if(document.visibilityState!=="visible"||!navigator.onLine)return;
      void synchronizeProgram(false,false,"automatic");
    };
    const timer=window.setInterval(
      runAutomaticCycle,
      settings.syncIntervalSeconds*1000,
    );
    const onVisible=()=>{if(document.visibilityState==="visible")runAutomaticCycle();};
    const onFocus=()=>runAutomaticCycle();
    const onOnline=()=>runAutomaticCycle();
    document.addEventListener("visibilitychange",onVisible);
    window.addEventListener("focus",onFocus);
    window.addEventListener("online",onOnline);
    return()=>{
      window.clearInterval(timer);
      document.removeEventListener("visibilitychange",onVisible);
      window.removeEventListener("focus",onFocus);
      window.removeEventListener("online",onOnline);
    };
  },[session,synchronizeProgram,settings.syncIntervalSeconds]);
  useEffect(() => {
    void fetch("/api/auth", { cache: "no-store" })
      .then(async (r) => {
        const p = (await r.json()) as { user?: typeof session };
        if (r.ok && p.user) setSession(p.user);
      })
      .finally(() => setAuthLoading(false));
  }, []);
  useEffect(() => {
    if (!session) return;
    let active=true;
    void (async()=>{
      await loadSettings();
      if(!active)return;
      // En el primer ingreso se usa el modo estándar. Si D1 todavía no tiene
      // programación, un único Worker hace la primera lectura de Google y los
      // demás esperan al líder. Después de esto, los ciclos son no bloqueantes.
      await synchronizeProgram(false,false,"standard");
      if(!active)return;
      await Promise.all([loadBoms(), loadStock(), loadLineTransfers()]);
      if(!active)return;
      await loadRequirements();
    })();
    return()=>{active=false;};
  }, [session, loadBoms, loadLineTransfers, loadStock, loadRequirements,loadSettings,synchronizeProgram]);

  const canAccess = (target: string) =>
    session?.role === "admin" ||
    target === "resumen" ||
    (session?.permissions ?? "").split(",").includes(target);
  const askAssistant = async (question: string) => {
    const clean = question.trim();
    if (!clean||chatLoading) return;
    const dateTime=(value:string)=>{
      const parsed=new Date(value);
      return Number.isNaN(parsed.getTime())?"sin fecha disponible":new Intl.DateTimeFormat("es-AR",{dateStyle:"short",timeStyle:"short"}).format(parsed);
    };
    const knownMaterialCodes=new Map<string,string>();
    const registerMaterialCode=(code:string)=>{
      const key=materialCodeKey(code);
      if(key&&!knownMaterialCodes.has(key))knownMaterialCodes.set(key,code);
    };
    requirements.forEach(item=>registerMaterialCode(item.materialCode));
    shortages.forEach(item=>registerMaterialCode(item.materialCode));
    stock.forEach(item=>registerMaterialCode(item.materialCode));
    bomProducts.forEach(product=>product.items.forEach(item=>registerMaterialCode(item.materialCode)));
    const materialQuery=detectMaterialCode(clean,knownMaterialCodes);
    const materialKey=materialCodeKey(materialQuery);
    const requirement=materialKey
      ? requirements.find(item=>materialCodeKey(item.materialCode)===materialKey)
      : undefined;
    const stockItem=materialKey
      ? stock.find(item=>materialCodeKey(item.materialCode)===materialKey)
      : undefined;
    const shortage=materialKey
      ? shortages.find(item=>materialCodeKey(item.materialCode)===materialKey)
      : undefined;
    const technicalUses=materialKey
      ? bomProducts.flatMap(product=>
          product.items
            .filter(item=>materialCodeKey(item.materialCode)===materialKey)
            .map(item=>({product,item})),
        )
      : [];
    const technicalItem=technicalUses[0]?.item;
    const available=Number(stockItem?.quantity??shortage?.available??0);
    const required=Number(requirement?.total??shortage?.total??0);
    const materialMatches=materialQuery&&(requirement||stockItem||technicalItem)
      ? [{
          materialCode:
            requirement?.materialCode??
            stockItem?.materialCode??
            technicalItem?.materialCode??
            materialQuery,
          materialName:
            stockItem?.materialName??
            requirement?.materialName??
            technicalItem?.materialName??
            "",
          category:
            stockItem?.category??
            requirement?.category??
            technicalItem?.category??
            "",
          unit:
            requirement?.unit??
            stockItem?.unit??
            technicalItem?.unit??
            "unidad",
          required,
          available,
          shortage:Math.max(0,required-available),
          depots:stockItem?.depots??shortage?.depots??{},
          weeks:(requirement?.weeks??shortage?.weeks??[]).map(week=>week.weekLabel),
          products:[
            ...(requirement?.products??shortage?.products??[]).map(product=>
              `${product.productCode} - ${product.productName}`,
            ),
            ...technicalUses.map(({product})=>`${product.code} - ${product.name}`),
          ],
          inCurrentProgram:Boolean(requirement||shortage),
          inStock:Boolean(stockItem),
          inTechnicalSheet:technicalUses.length>0,
        }]
      : [];
    const context:GeneralAssistantContext={
      now:new Intl.DateTimeFormat("es-AR",{dateStyle:"full",timeStyle:"short"}).format(new Date()),
      synchronized:sourceState.live,
      fetchedAt:dateTime(sourceState.fetchedAt),
      operations:records.length,
      weeks:weeks.length,
      completedOperations:records.filter(record=>record.completed).length,
      mappedOperations:requirementState.mapped,
      blockedOperations:requirementState.blocked,
      shortages:shortages.length,
      stockItems:stock.length,
      shortageItems:[...shortages]
        .sort((left,right)=>right.shortage-left.shortage)
        .map(item=>({
          materialCode:item.materialCode,
          materialName:item.materialName,
          category:item.category,
          unit:item.unit,
          required:item.total,
          available:item.available,
          shortage:item.shortage,
          weeks:item.weeks.map(week=>week.weekLabel),
        })),
      materialQuery,
      materialMatches,
      calculation:{
        running:calculationStatus.running,
        phase:calculationStatus.phase,
        lastCalculatedAt:calculationStatus.lastCalculatedAt
          ? dateTime(calculationStatus.lastCalculatedAt)
          : "",
        sourceMessage:calculationStatus.sourceMessage,
      },
      changes:{
        added:programChange.added,
        modified:programChange.modified,
        removed:programChange.removed,
        detectedAt:programChange.detectedAt,
      },
    };
    setChatMessages(messages=>[...messages,{from:"user",text:clean}]);
    setChatInput("");
    setChatLoading(true);
    let answer=generalAssistantFallback(clean,context);
    try{
      const history=chatMessages.slice(-12).map(message=>({role:message.from==="user"?"user":"assistant",content:message.text}));
      const response=await fetch("/api/assistant",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({question:clean,context,history})});
      const payload=await responseJson<{answer?:string;error?:string}>(response);
      if(response.ok&&payload.answer)answer=payload.answer;
    }catch{
      // La respuesta local mantiene disponible el asistente aunque falle la IA.
    }finally{
      setChatMessages(messages=>[...messages,{from:"bot",text:answer}]);
      setChatLoading(false);
    }
  };
  const navigate = (target: string) => {
    if (!canAccess(target)) return;
    if (
      [
        "resumen",
        "programacion",
        "productos",
        "bom",
        "consumos",
        "stock",
        "faltantes",
        "usuarios",
      ].includes(target)
    ) {
      setView(target as View);
      if (target === "bom") void loadBoms();
      if (["consumos", "faltantes"].includes(target))
        void loadRequirements();
      if (target === "stock") void loadStock();
      if (target === "usuarios") void loadUsers();
    } else setView("pendiente");
  };

  if (authLoading && !session)
    return (
      <main className="login-page">
        <div className="login-card">
          <span className="brand-mark">
            <Icon name="bottle" />
          </span>
          <h1>Planificación de Insumos</h1>
          <p>Validando acceso…</p>
        </div>
      </main>
    );
  if (!session)
    return (
      <main className="login-page">
        <form
          className="login-card"
          onSubmit={(e) => {
            e.preventDefault();
            void login();
          }}
        >
          <span className="brand-mark">
            <Icon name="bottle" />
          </span>
          <p className="eyebrow">ERP de Bodega</p>
          <h1>Iniciar sesión</h1>
          <p>Ingresá con el usuario asignado por el administrador.</p>
          <label>
            Usuario
            <input
              autoFocus
              value={loginDraft.username}
              onChange={(e) =>
                setLoginDraft({ ...loginDraft, username: e.target.value })
              }
            />
          </label>
          <label>
            Contraseña
            <input
              type="password"
              value={loginDraft.password}
              onChange={(e) =>
                setLoginDraft({ ...loginDraft, password: e.target.value })
              }
            />
          </label>
          {loginError && <div className="login-error">{loginError}</div>}
          <button className="primary-button" disabled={authLoading}>
            {authLoading ? "Ingresando…" : "Ingresar"}
          </button>
          <small>Acceso inicial de prueba: admin / 1234</small>
        </form>
      </main>
    );
  return (
    <main className="app-shell">
      <header className="topbar">
        <button
          className="brand"
          onClick={() => setView("resumen")}
          aria-label="Ir al resumen"
        >
          <span className="brand-mark">
            <Icon name="bottle" />
          </span>
          <span>Planificación de Insumos</span>
        </button>
        <nav aria-label="Navegación principal">
          {[
            ["resumen", "Resumen"],
            ["programacion", "Programación"],
            ["productos", "Productos"],
            ["bom", "Ficha técnica"],
            ["consumos", "Consumos"],
            ["stock", "Stock"],
            ["faltantes", "Faltantes"],
            ["usuarios", "Administración"],
          ]
            .filter(([id]) => canAccess(id))
            .map(([id, label]) => (
              <button
                key={id}
                onClick={() => navigate(id)}
                className={
                  view === id ||
                  (view === "pendiente" &&
                    !["resumen", "programacion"].includes(id))
                    ? ""
                    : ""
                }
                data-active={view === id}
              >
                {label}
                {![
                  "resumen",
                  "programacion",
                  "productos",
                  "bom",
                  "consumos",
                  "stock",
                  "faltantes",
                  "usuarios",
                ].includes(id) && (
                  <span className="nav-lock">
                    <Icon name="lock" />
                  </span>
                )}
              </button>
            ))}
        </nav>
        <div className="sync-state">
          <span className={`pulse ${sourceState.live ? "live" : ""}`} />
          {sourceState.live ? "Sincronizado en vivo" : "Instantánea validada"}
        </div>
        <div className="profile-menu">
          <button
            className="avatar"
            aria-label="Abrir menú de usuario"
            aria-expanded={profileOpen}
            onClick={() => setProfileOpen((value) => !value)}
          >
            {session.name
              .split(/\s+/)
              .map((value) => value[0])
              .join("")
              .slice(0, 2)
              .toUpperCase()}
          </button>
          {profileOpen && (
            <div className="profile-popover">
              <strong>{session.name}</strong>
              <span>@{session.username}</span>
              <small>
                {session.role === "admin" ? "Administrador" : "Usuario normal"}
              </small>
              <button onClick={()=>{setPasswordPanelOpen(value=>!value);setPasswordMessage("");}}>Cambiar contraseña</button>
              {passwordPanelOpen&&<div className="password-panel"><input type="password" placeholder="Contraseña actual" value={passwordDraft.current} onChange={e=>setPasswordDraft({...passwordDraft,current:e.target.value})}/><input type="password" placeholder="Nueva contraseña" value={passwordDraft.next} onChange={e=>setPasswordDraft({...passwordDraft,next:e.target.value})}/><input type="password" placeholder="Repetir nueva contraseña" value={passwordDraft.confirm} onChange={e=>setPasswordDraft({...passwordDraft,confirm:e.target.value})}/>{passwordMessage&&<small>{passwordMessage}</small>}<button onClick={()=>void changeOwnPassword()}>Guardar contraseña</button></div>}
              <button onClick={() => void logout()}>Cerrar sesión</button>
            </div>
          )}
        </div>
      </header>

      <div className="page">
        {view === "resumen" && (
          <>
            <section className="page-heading">
              <div>
                <p className="eyebrow">Google Sheets · Programación Junin</p>
                <h1>Centro de operaciones</h1>
                <p>Planificá insumos y anticipá faltantes de producción.</p>
              </div>
              <button
                className={`refresh-button ${refreshing ? "busy" : ""}`}
                onClick={() => void synchronizeProgram(true)}
                disabled={refreshing}
                aria-busy={refreshing}
              >
                <Icon name="sync" />{" "}
                {refreshing ? "Actualizando…" : "Actualizar ahora"}
              </button>
            </section>

            {programChange.total > 0 && (
              <section className="change-banner">
                <span className="mini-icon">
                  <Icon name="sync" />
                </span>
                <button className="change-banner-link" onClick={()=>{setView("programacion");setShowChangesOnly(true);setWeekFilter(programChange.changedWeekIds.length===1?programChange.changedWeekIds[0]:"all");}}>
                <div>
                  <strong>Cambio detectado en la programación</strong>
                  <p>
                    {programChange.added} agregadas · {programChange.modified}{" "}
                    modificadas · {programChange.removed} eliminadas
                  </p>
                </div>
                </button>
                <time>
                  {new Intl.DateTimeFormat("es-AR", {
                    hour: "2-digit",
                    minute: "2-digit",
                  }).format(new Date(programChange.detectedAt))}
                </time>
                <button
                  onClick={() =>
                    setProgramChange({
                      added: 0,
                      removed: 0,
                      modified: 0,
                      total: 0,
                      detectedAt: "",
                      changedIds: [],
                      changedWeekIds: [],
                    })
                  }
                >
                  Descartar
                </button>
              </section>
            )}

            <section className="week-timeline" aria-label="Semanas programadas">
              {weeks.map((week, index) => (
                <div className="week-segment" key={week.id}>
                  <button
                    className="week-card"
                    data-selected={selected?.id === week.id}
                    onClick={() => setSelectedWeek(week.id)}
                  >
                    <div className="week-title-row">
                      <span className="week-icon">
                        <Icon name="calendar" />
                      </span>
                      <span>
                        <strong>{week.label}</strong>
                        <small>{week.detail}</small>
                      </span>
                      <span className="week-tag">{week.status}</span>
                    </div>
                    <div className="week-metrics">
                      <span>
                        <Icon name="bottle" />
                        <strong>{formatNumber(week.fractionBottles)}</strong>
                        <small>a fraccionar</small>
                      </span>
                      <span>
                        <Icon name="clipboard" />
                        <strong>{week.operations}</strong>
                        <small>operaciones</small>
                      </span>
                      <span
                        className={week.issues ? "metric-warning" : "metric-ok"}
                      >
                        <Icon name={week.issues ? "alert" : "check"} />
                        <strong>{week.issues || "OK"}</strong>
                        <small>
                          {week.issues ? "incidencia" : "estructura"}
                        </small>
                      </span>
                    </div>
                  </button>
                  {index < weeks.length - 1 && (
                    <span className="timeline-link" />
                  )}
                </div>
              ))}
            </section>

            <section className="overview-grid">
              <div className="left-column">
                <div className="kpi-grid">
                  <article className="kpi-card">
                    <span className="kpi-icon">
                      <Icon name="bottle" />
                    </span>
                    <div>
                      <span>Fraccionamiento · {weeks.length} {weeks.length===1?"semana":"semanas"}</span>
                      <strong>{formatNumber(totalFractionBottles)}</strong>
                      <small>botellas programadas</small>
                    </div>
                  </article>
                  <article className="kpi-card">
                    <span className="kpi-icon soft">
                      <Icon name="clipboard" />
                    </span>
                    <div>
                      <span>Operaciones detectadas</span>
                      <strong>{records.length}</strong>
                      <small>
                        {actionTotals.fraccionar} fraccionar ·{" "}
                        {actionTotals.vestir} vestir · {actionTotals.encajonar}{" "}
                        encajonar
                      </small>
                    </div>
                  </article>
                </div>

                <article className="operations-card">
                  <div className="card-title">
                    <span className="mini-icon">
                      <Icon name="sheet" />
                    </span>
                    <div>
                      <h2>{selected.label}</h2>
                      <p>Desglose de operaciones reconocidas</p>
                    </div>
                  </div>
                  <div className="operation-bars">
                    {[
                      ["Fraccionar", selected.fraccionar, "primary"],
                      ["Vestir", selected.vestir, "secondary"],
                      ["Encajonar", selected.encajonar, "neutral"],
                    ].map(([label, value, tone]) => (
                      <button
                        key={String(label)}
                        onClick={() => setView("programacion")}
                        className="operation-row"
                      >
                        <span className={`operation-dot ${tone}`} />
                        <span>{label}</span>
                        <span className="bar">
                          <span
                            className={String(tone)}
                            style={{
                              width: `${selected.operations ? Math.max(4, (Number(value) / selected.operations) * 100) : 0}%`,
                            }}
                          />
                        </span>
                        <strong>{value}</strong>
                      </button>
                    ))}
                  </div>
                </article>
              </div>

              <article className="readiness-card">
                <div className="readiness-heading">
                  <span className="cart-symbol">
                    <Icon name="alert" />
                  </span>
                  <div>
                    <h2>
                      {requirementState.loading
                        ? "Calculando faltantes…"
                        : `${shortages.length} insumos con faltante`}
                    </h2>
                    <p>
                      {requirementState.loading
                        ? "Actualizando fichas técnicas, stock y programa."
                        : `${requirementState.mapped} operaciones calculadas con el programa vigente.`}
                    </p>
                  </div>
                </div>
                <div className="readiness-steps">
                  <div className="ready">
                    <span>1</span>
                    <div>
                      <strong>Programa de producción</strong>
                      <small>{records.length} operaciones reconocidas</small>
                    </div>
                    <Icon name="check" />
                  </div>
                  <div className={requirementState.mapped > 0 ? "ready" : ""}>
                    <span>2</span>
                    <div>
                      <strong>Fichas técnicas</strong>
                      <small>
                        {bomProducts.length} aprobadas ·{" "}
                        {requirementState.provisional} provisionales del Sheet
                      </small>
                    </div>
                    <Icon
                      name={requirementState.mapped > 0 ? "check" : "lock"}
                    />
                  </div>
                  <div className={stock.length > 0 ? "ready" : ""}>
                    <span>3</span>
                    <div>
                      <strong>Stock disponible</strong>
                      <small>
                        {stock.length
                          ? `${stock.length} insumos con existencia cargada`
                          : "Pendiente de carga inicial"}
                      </small>
                    </div>
                    <Icon name={stock.length > 0 ? "check" : "lock"} />
                  </div>
                </div>
                <div className="honest-state">
                  <strong>
                    {shortages.length ? "Reporte disponible" : "Estado actual"}
                  </strong>
                  <p>
                    {shortages.length
                      ? `Hay ${shortages.length} materiales con faltante. Abrí Faltantes para revisar el detalle por insumo y semana.`
                      : requirements.length
                        ? "El stock disponible cubre las necesidades calculadas del programa."
                        : "Todavía faltan datos para calcular faltantes."}
                  </p>
                </div>
                <button
                  className="primary-button"
                  onClick={() => {
                    setView(shortages.length ? "faltantes" : "programacion");
                    if (shortages.length) void loadRequirements();
                  }}
                >
                  {shortages.length
                    ? "Ver faltantes"
                    : "Validar programación"}
                </button>
              </article>
            </section>

            <section className="diagnostic-strip">
              <div>
                <span className="status-dot error" />
                <strong>
                  {missingCodeRecords.length} dato requiere revisión
                </strong>
                <small>Semana tentativa · producto sin código</small>
              </div>
              <button onClick={() => setView("programacion")}>
                Ver diagnóstico completo <span>→</span>
              </button>
            </section>
          </>
        )}

        {view === "programacion" && (
          <section className="program-view">
            <div className="page-heading compact">
              <div>
                <p className="eyebrow">Prioridad 1 · Importador diagnóstico</p>
                <h1>Programación reconocida</h1>
                <p>
                  Cada registro conserva su semana, línea, operación y fila de
                  origen.
                </p>
              </div>
              <button
                className="refresh-button"
                onClick={() => setView("resumen")}
              >
                ← Volver al resumen
              </button>
            </div>
            {programChange.total > 0 && (
              <div className="change-banner">
                <span className="mini-icon">
                  <Icon name="sync" />
                </span>
                <div>
                  <strong>Último cambio detectado</strong>
                  <p>
                    {programChange.added} agregadas · {programChange.modified}{" "}
                    modificadas · {programChange.removed} eliminadas
                  </p>
                </div>
                <time>
                  {new Intl.DateTimeFormat("es-AR", {
                    hour: "2-digit",
                    minute: "2-digit",
                  }).format(new Date(programChange.detectedAt))}
                </time>
              </div>
            )}
            <div className="diagnostic-cards">
              <article>
                <span className="ok-icon">
                  <Icon name="check" />
                </span>
                <div>
                  <strong>3 pestañas semanales</strong>
                  <small>Actual, próxima y tentativa</small>
                </div>
              </article>
              <article>
                <span className="ok-icon">
                  <Icon name="check" />
                </span>
                <div>
                  <strong>4 secciones por semana</strong>
                  <small>Líneas 1, 2, 3 y tareas manuales</small>
                </div>
              </article>
              <article className="warning-card">
                <span>
                  <Icon name="alert" />
                </span>
                <div>
                  <strong>
                    {missingCodeRecords.length} incidencia crítica
                  </strong>
                  <small>Impide relacionar una fila con su ficha técnica</small>
                </div>
              </article>
            </div>
            <div className="program-layout">
              <article className="table-card">
                <div
                  className={`source-banner ${sourceState.live ? "live" : "snapshot"}`}
                >
                  <span className="pulse" />
                  <div>
                    <strong>
                      {sourceState.live
                        ? "Conexión automática activa"
                        : "Modo de validación"}
                    </strong>
                    <p>{sourceState.notice}</p>
                  </div>
                  <button
                    onClick={() => void synchronizeProgram(true)}
                    disabled={refreshing}
                  >
                    {refreshing ? "Actualizando…" : "Actualizar"}
                  </button>
                </div>
                <div className="table-toolbar">
                  <div>
                    <h2>{records.length} filas interpretadas</h2>
                    <p>
                      {sourceState.live
                        ? "Última sincronización"
                        : "Instantánea validada"}{" "}
                      el{" "}
                      {new Intl.DateTimeFormat("es-AR", {
                        day: "2-digit",
                        month: "short",
                        hour: "2-digit",
                        minute: "2-digit",
                      }).format(new Date(sourceState.fetchedAt))}
                      .
                    </p>
                  </div>
                  <label className="search-box">
                    <Icon name="search" />
                    <input
                      value={query}
                      onChange={(event) => setQuery(event.target.value)}
                      placeholder="Buscar código, marca o variedad"
                    />
                  </label>
                </div>
                <div className="filter-row">
                  {showChangesOnly&&<button className="changes-filter" onClick={()=>setShowChangesOnly(false)}>Cambios detectados ×</button>}
                  <label>
                    Semana
                    <select
                      value={weekFilter}
                      onChange={(event) => setWeekFilter(event.target.value)}
                    >
                      <option value="all">Todas</option>
                      {weeks.map((week) => (
                        <option key={week.id} value={week.id}>
                          {week.label}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Acción
                    <select
                      value={actionFilter}
                      onChange={(event) => setActionFilter(event.target.value)}
                    >
                      <option value="all">Todas</option>
                      <option value="FRACCIONAR">Fraccionar</option>
                      <option value="VESTIR">Vestir</option>
                      <option value="ENCAJONAR">Encajonar</option>
                    </select>
                  </label>
                  <label>
                    Sector
                    <select
                      value={lineFilter}
                      onChange={(event) => setLineFilter(event.target.value)}
                    >
                      <option value="all">Todos</option>
                      <option value="linea-1">Línea 1</option>
                      <option value="linea-2">Línea 2</option>
                      <option value="linea-3">Línea 3</option>
                      <option value="tareas-manuales">Tareas manuales</option>
                    </select>
                  </label>
                  <span className="table-summary">
                    {filteredRows.length} resultados
                  </span>
                </div>
                <div className="sheet-program">
                  {groupedProgramRows.map(({ week, lines }) => (
                    <section className="sheet-week" key={week.id}>
                      <header>
                        <div>
                          <strong>SEMANA {week.label}</strong>
                          <span>
                            {week.status} ·{" "}
                            {lines.reduce(
                              (sum, line) => sum + line.rows.length,
                              0,
                            )}{" "}
                            operaciones
                          </span>
                        </div>
                      </header>
                      {lines.map(({ line, rows }) => (
                        <div className="sheet-line" key={line}>
                          <h3>{lineLabel(line)}</h3>
                          <div className="table-scroll">
                            <table>
                              <thead>
                                <tr>
                                  {[
                                    "Día",
                                    "Acción",
                                    "PIN",
                                    "Código",
                                    "Marca",
                                    "Variedad",
                                    "Año",
                                    "Cap.",
                                    "Cierre",
                                    "Litros",
                                    "Cliente",
                                    "País",
                                    "Cajas",
                                    "U/C",
                                    "Botellas",
                                    "Botella",
                                    "Tapón",
                                    "Cápsula/Tapa",
                                    "Caja",
                                    "Etiqueta frente",
                                    "Contraetiqueta",
                                    "Observaciones",
                                  ].map((head) => (
                                    <th key={head}>{head}</th>
                                  ))}
                                </tr>
                              </thead>
                              <tbody>
                                {rows.map((record) => (
                                  <tr
                                    key={record.id}
                                    data-warning={!record.productCode}
                                    data-completed={record.completed||undefined}
                                  >
                                    <td>{record.dateLabel || "—"}</td>
                                    <td>
                                      <span
                                        className={`action-badge ${record.action.toLowerCase()}`}
                                      >
                                        {record.action}
                                      </span>
                                      {record.completed&&<span className="completed-badge">REALIZADO</span>}
                                    </td>
                                    <td>{record.pin || "—"}</td>
                                    <td className="number-cell">
                                      {record.productCode || "Sin código"}
                                    </td>
                                    <td>{record.brand || "—"}</td>
                                    <td>{record.variety || "—"}</td>
                                    <td>{record.vintage || "—"}</td>
                                    <td>{record.capacity || "—"}</td>
                                    <td>{record.closure || "—"}</td>
                                    <td>{record.liters || "—"}</td>
                                    <td>{record.client || "—"}</td>
                                    <td>{record.country || "—"}</td>
                                    <td>{record.cases || "—"}</td>
                                    <td>{record.unitsPerCase || "—"}</td>
                                    <td className="number-cell">
                                      {formatNumber(record.bottles)}
                                    </td>
                                    <td className="material-cell">
                                      {record.materials.bottle || "—"}
                                    </td>
                                    <td className="material-cell">
                                      {record.materials.closure || "—"}
                                    </td>
                                    <td className="material-cell">
                                      {record.materials.capsuleOrCap || "—"}
                                    </td>
                                    <td className="material-cell">
                                      {record.materials.case || "—"}
                                    </td>
                                    <td className="material-cell">
                                      {record.materials.frontLabel || "—"}
                                    </td>
                                    <td className="material-cell">
                                      {record.materials.backLabel || "—"}
                                    </td>
                                    <td className="notes-cell">
                                      {record.notes || "—"}
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      ))}
                    </section>
                  ))}
                </div>
              </article>
              <aside className="issues-card">
                <div className="card-title">
                  <span className="mini-icon warning">
                    <Icon name="alert" />
                  </span>
                  <div>
                    <h2>Diagnóstico</h2>
                    <p>Controles previos al cálculo</p>
                  </div>
                </div>
                {missingCodeRecords.map((record) => (
                  <div className="issue error" key={record.id}>
                    <span className="status-dot error" />
                    <div>
                      <strong>Producto sin código</strong>
                      <p>
                        {record.brand} · {record.variety} {record.vintage} ·{" "}
                        {formatNumber(record.bottles)} botellas
                      </p>
                      <small>
                        {record.weekLabel} · {lineLabel(record.line)} · fila{" "}
                        {record.sourceRow}
                      </small>
                    </div>
                  </div>
                ))}
                <div className="issue info">
                  <span className="status-dot info" />
                  <div>
                    <strong>Códigos de insumos todavía incompletos</strong>
                    <p>
                      Se resolverán con la ficha técnica del ERP, sin depender de la carga
                      tardía del Sheet.
                    </p>
                    <small>
                      {withoutEmbeddedMaterials.length} operaciones sin
                      referencia embebida
                    </small>
                  </div>
                </div>
                <div className="source-note">
                  <strong>Regla de importación</strong>
                  <p>
                    Las filas se reconocen por encabezados y acción, no por
                    posiciones fijas. Así, insertar filas en el Sheet no rompe
                    la lectura.
                  </p>
                </div>
              </aside>
            </div>
          </section>
        )}

        {view === "productos" && (
          <section className="program-view">
            <div className="page-heading compact">
              <div>
                <p className="eyebrow">
                  Prioridad 3 · Interpretación automática
                </p>
                <h1>Productos programados</h1>
                <p>
                  Maestro temporal construido directamente desde las operaciones
                  del Sheet.
                </p>
              </div>
              <button
                className={`refresh-button ${refreshing ? "busy" : ""}`}
                onClick={() => void synchronizeProgram(true)}
                disabled={refreshing}
                aria-busy={refreshing}
              >
                <Icon name="sync" />
                {refreshing ? "Actualizando…" : "Actualizar"}
              </button>
            </div>
            <div className="diagnostic-cards">
              <article>
                <span className="ok-icon">
                  <Icon name="check" />
                </span>
                <div>
                  <strong>{productReport.length} códigos únicos</strong>
                  <small>Detectados en las semanas visibles</small>
                </div>
              </article>
              <article>
                <span className="ok-icon">
                  <Icon name="clipboard" />
                </span>
                <div>
                  <strong>
                    {productReport.filter((item) => !item.inconsistent).length}{" "}
                    productos consistentes
                  </strong>
                  <small>Misma descripción para el mismo código</small>
                </div>
              </article>
              <article
                className={
                  productReport.some((item) => item.inconsistent)
                    ? "warning-card"
                    : ""
                }
              >
                <span>
                  <Icon
                    name={
                      productReport.some((item) => item.inconsistent)
                        ? "alert"
                        : "check"
                    }
                  />
                </span>
                <div>
                  <strong>
                    {productReport.filter((item) => item.inconsistent).length}{" "}
                    conflictos
                  </strong>
                  <small>Códigos usados con descripciones distintas</small>
                </div>
              </article>
            </div>
            <article className="table-card">
              <div className="table-toolbar">
                <div>
                  <h2>Catálogo reconocido</h2>
                  <p>No modifica ni reemplaza la fuente original.</p>
                </div>
                <label className="search-box">
                  <Icon name="search" />
                  <input
                    value={productQuery}
                    onChange={(event) => setProductQuery(event.target.value)}
                    placeholder="Buscar código, marca o variedad"
                  />
                </label>
              </div>
              <div className="table-scroll">
                <table>
                  <thead>
                    <tr>
                      <th>Código</th>
                      <th>Descripción interpretada</th>
                      <th>Operaciones</th>
                      <th>Semanas</th>
                      <th>Botellas involucradas</th>
                      <th>Estado</th>
                    </tr>
                  </thead>
                  <tbody>
                    {visibleProducts.map((product) => (
                      <tr
                        key={product.code}
                        data-warning={product.inconsistent}
                      >
                        <td className="number-cell">{product.code}</td>
                        <td className="record-product">
                          <strong>{product.description}</strong>
                          {product.inconsistent && (
                            <span>{product.descriptions.join(" / ")}</span>
                          )}
                        </td>
                        <td>{product.operations.join(" · ")}</td>
                        <td>{product.weeks.join(" · ")}</td>
                        <td className="number-cell">
                          {formatNumber(product.bottles)}
                        </td>
                        <td>
                          <span
                            className={`row-status ${product.inconsistent ? "review" : "valid"}`}
                          >
                            {product.inconsistent ? "Revisar" : "Consistente"}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="pagination">
                <span>{visibleProducts.length} productos mostrados</span>
              </div>
            </article>
          </section>
        )}

        {view === "bom" && (
          <section className="bom-view">
            <div className="page-heading compact">
              <div>
                <p className="eyebrow">Prioridad 4 · Fichas técnicas</p>
                <h1>Fichas técnicas</h1>
                <p>
                  Definí qué consume cada producto según la operación
                  programada.
                </p>
              </div>
              <button
                className="refresh-button"
                onClick={() => void loadBoms()}
              >
                {bomLoading ? "Actualizando…" : "Actualizar"}
              </button>
            </div>
            <div className="bom-kpis">
              <article>
                <strong>{programmedProducts.length}</strong>
                <span>productos programados</span>
              </article>
              <article>
                <strong>{bomProducts.length}</strong>
                <span>fichas aprobadas</span>
              </article>
              <article>
                <strong>{productsWithSheetMaterials.length}</strong>
                <span>productos con insumos en Sheet</span>
              </article>
            </div>
            <div className="bom-layout">
              <article className="table-card">
                <div className="table-toolbar">
                  <div>
                    <h2>Cobertura del programa</h2>
                    <p>
                      {visibleBomProducts.length} de {programmedProducts.length}{" "}
                      productos
                    </p>
                  </div>
                  <label className="search-box">
                    <Icon name="search" />
                    <input
                      value={bomQuery}
                      onChange={(e) => setBomQuery(e.target.value)}
                      placeholder="Buscar código o producto"
                    />
                  </label>
                </div>
                <div className="bom-product-list">
                  {visibleBomProducts.map((product) => {
                    const saved = bomProducts.find(
                        (item) => item.code === product.code,
                      ),
                      suggested = suggestBomFromProgram(records, product.code);
                    return (
                      <button
                        key={product.code}
                        onClick={() => {
                          setBomMessage(
                            saved
                              ? ""
                              : "Borrador precargado desde el Sheet. Revisalo antes de guardar.",
                          );
                          setBomDraft(
                            saved
                              ? {
                                  code: saved.code,
                                  name: saved.name,
                                  items: saved.items.map((item) => ({
                                    ...item,
                                    substitutes: item.substitutes ?? [],
                                  })),
                                }
                              : {
                                  code: product.code,
                                  name: product.name,
                                  items: suggested.items.length
                                    ? suggested.items
                                    : [emptyBomItem()],
                                },
                          );
                        }}
                      >
                        <span>
                          <strong>{product.code}</strong>
                          <small>{product.name}</small>
                        </span>
                        <span
                          className={`row-status ${saved ? "valid" : "review"}`}
                        >
                          {saved
                            ? `${saved.items.length} insumos aprobados`
                            : suggested.items.length
                              ? `${suggested.items.length} del Sheet`
                              : "Sin insumos"}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </article>
              <article className="table-card">
                <div className="table-toolbar">
                  <div>
                    <h2>
                      {bomDraft.code
                        ? `Ficha ${bomDraft.code}`
                        : "Nueva ficha técnica"}
                    </h2>
                    <p>El consumo se expresa por botella o unidad producida.</p>
                  </div>
                </div>
                <div className="bom-form">
                  <div className="bom-fields">
                    <label>
                      Código de producto
                      <input
                        list="product-codes"
                        value={bomDraft.code}
                        onChange={(event) => {
                          const match = programmedProducts.find(
                            (product) => product.code === event.target.value,
                          );
                          setBomDraft((draft) => ({
                            ...draft,
                            code: event.target.value,
                            name: match?.name ?? draft.name,
                          }));
                        }}
                      />
                      <datalist id="product-codes">
                        {programmedProducts.map((product) => (
                          <option key={product.code} value={product.code}>
                            {product.name}
                          </option>
                        ))}
                      </datalist>
                    </label>
                    <label>
                      Descripción
                      <input
                        value={bomDraft.name}
                        onChange={(event) =>
                          setBomDraft((draft) => ({
                            ...draft,
                            name: event.target.value,
                          }))
                        }
                      />
                    </label>
                  </div>
                  {bomDraft.code && (
                    <div className="sheet-suggestion">
                      <div>
                        <strong>Insumos detectados en Google Sheets</strong>
                        <p>
                          {bomSuggestion.items.length
                            ? `${bomSuggestion.items.length} referencias informadas en ${bomSuggestion.populatedRows} de ${bomSuggestion.sourceRows} operaciones del producto.`
                            : "Todavía no hay insumos informados para este producto."}
                        </p>
                        {!bomSuggestion.complete &&
                          bomSuggestion.sourceRows > 0 && (
                            <small>
                              Información parcial: el Sheet se sigue completando
                              durante la semana.
                            </small>
                          )}
                      </div>
                      <button
                        disabled={!bomSuggestion.items.length}
                        onClick={applySheetMaterials}
                      >
                        Agregar desde Sheet
                      </button>
                    </div>
                  )}
                  <div className="bom-items">
                    <div className="bom-item-head">
                      <strong>Insumos</strong>
                      <button
                        onClick={() =>
                          setBomDraft((draft) => ({
                            ...draft,
                            items: [...draft.items, emptyBomItem()],
                          }))
                        }
                      >
                        + Agregar insumo
                      </button>
                    </div>
                    {bomDraft.items.map((item, index) => (
                      <div className="bom-item" key={index}>
                        <label>
                          Tipo
                          <select
                            value={item.category}
                            onChange={(event) =>
                              updateBomItem(index, {
                                category: event.target.value,
                              })
                            }
                          >
                            {[
                              "Botellas",
                              "Tapones",
                              "Cápsulas",
                              "Etiquetas",
                              "Cajas",
                              "Separadores",
                              "Corchos",
                              "Otros",
                            ].map((value) => (
                              <option key={value}>{value}</option>
                            ))}
                          </select>
                        </label>
                        <label>
                          Código
                          <input
                            value={item.materialCode}
                            onChange={(event) =>
                              updateBomItem(index, {
                                materialCode: event.target.value,
                              })
                            }
                          />
                        </label>
                        <label>
                          Descripción
                          <input
                            value={item.materialName}
                            onChange={(event) =>
                              updateBomItem(index, {
                                materialName: event.target.value,
                              })
                            }
                          />
                        </label>
                        <label>
                          Consumo
                          <input
                            type="number"
                            min="0.000001"
                            step="0.000001"
                            value={item.quantity}
                            onChange={(event) =>
                              updateBomItem(index, {
                                quantity: Number(event.target.value),
                              })
                            }
                          />
                        </label>
                        <label>
                          Operación
                          <select
                            value={item.action}
                            onChange={(event) =>
                              updateBomItem(index, {
                                action: event.target.value,
                              })
                            }
                          >
                            <option>FRACCIONAR</option>
                            <option>VESTIR</option>
                            <option>ENCAJONAR</option>
                          </select>
                        </label>
                        <label className="substitute-field">
                          Sustitutos autorizados
                          <input
                            placeholder="20391, 20397"
                            value={item.substitutes.join(", ")}
                            onChange={(event) =>
                              updateBomItem(index, {
                                substitutes: event.target.value
                                  .split(",")
                                  .map((value) => value.trim()),
                              })
                            }
                          />
                        </label>
                        <button
                          className="remove-item"
                          aria-label="Eliminar insumo"
                          onClick={() =>
                            setBomDraft((draft) => ({
                              ...draft,
                              items: draft.items.filter(
                                (_, itemIndex) => itemIndex !== index,
                              ),
                            }))
                          }
                        >
                          ×
                        </button>
                      </div>
                    ))}
                  </div>
                  {bomMessage && <p className="bom-message">{bomMessage}</p>}
                  <button
                    className="primary-button bom-save"
                    disabled={bomLoading}
                    onClick={() => void saveBom()}
                  >
                    {bomLoading ? "Guardando…" : "Guardar ficha técnica"}
                  </button>
                </div>
              </article>
            </div>
          </section>
        )}

        {view === "consumos" && (
          <section className="consumption-view">
            <div className="page-heading compact">
              <div>
                <p className="eyebrow">Prioridad 5 · Motor de cálculo</p>
                <h1>Consumo de insumos</h1>
                <p>
                  Demanda calculada desde el programa vigente y las fichas técnicas
                  aprobadas.
                </p>
              </div>
              <button
                className={`refresh-button ${calculationStatus.running ? "busy" : ""}`}
                disabled={calculationStatus.running||refreshing}
                aria-busy={calculationStatus.running}
                onClick={() => void updateAndRecalculate()}
              >
                <Icon name="sync" />
                {calculationStatus.running
                  ? "Actualizando y calculando…"
                  : "Actualizar y recalcular"}
              </button>
            </div>
            <div className="bom-kpis">
              <article>
                <strong>{requirementState.mapped}</strong>
                <span>operaciones con ficha técnica</span>
              </article>
              <article data-warning={requirementState.blocked > 0}>
                <strong>{requirementState.blocked}</strong>
                <span>operaciones bloqueadas</span>
              </article>
              <article>
                <strong>{requirements.length}</strong>
                <span>insumos calculados</span>
              </article>
            </div>
            <CalculationStatus
              status={calculationStatus}
              mapped={requirementState.mapped}
              materials={requirements.length}
              shortages={shortages.length}
              stockItems={stock.length}
            />
            {requirementState.completed>0&&<p className="bom-message">{requirementState.completed} operaciones tachadas en Google Sheets se muestran como realizadas y fueron excluidas del consumo.</p>}
            {requirementState.error && (
              <p className="bom-message consumption-error">
                {requirementState.error}
              </p>
            )}
            {!requirementState.loading && requirements.length === 0 ? (
              <article className="empty-consumption">
                <span className="gated-icon">
                  <Icon name="clipboard" />
                </span>
                <h2>Esperando fichas técnicas</h2>
                <p>
                  El motor está listo. Cargá al menos una ficha técnica para comenzar a
                  calcular consumos reales; no se generan valores estimados.
                </p>
                <button
                  className="primary-button"
                  onClick={() => {
                    setView("bom");
                    void loadBoms();
                  }}
                >
                  Cargar primera ficha
                </button>
              </article>
            ) : (
              <article className="table-card">
                <div className="table-toolbar">
                  <div>
                    <h2>Necesidad bruta por insumo</h2>
                    <p>
                      {visibleRequirements.length} de {requirements.length}{" "}
                      insumos
                    </p>
                  </div>
                  <label className="search-box">
                    <Icon name="search" />
                    <input
                      value={requirementQuery}
                      onChange={(e) => setRequirementQuery(e.target.value)}
                      placeholder="Buscar insumo, producto o semana"
                    />
                  </label>
                </div>
                <div className="table-scroll">
                  <table>
                    <thead>
                      <tr>
                        <th>Tipo</th>
                        <th>Insumo</th>
                        <th>Consumo total</th>
                        <th>Semanas</th>
                        <th>Productos</th>
                        <th>Sustitutos</th>
                      </tr>
                    </thead>
                    <tbody>
                      {visibleRequirements.map((item) => (
                        <tr key={`${item.materialCode}-${item.unit}`}>
                          <td>{item.category}</td>
                          <td className="record-product">
                            <strong>{item.materialCode}</strong>
                            <span>{item.materialName}</span>
                          </td>
                          <td className="number-cell">
                            {formatNumber(item.total)} {item.unit}
                          </td>
                          <td>
                            {item.weeks
                              .map(
                                (week) =>
                                  `${week.weekLabel}: ${formatNumber(week.quantity)}`,
                              )
                              .join(" · ")}
                          </td>
                          <td>{item.products.length}</td>
                          <td>{item.substitutes.join(", ") || "—"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </article>
            )}
          </section>
        )}

        {view === "stock" && (
          <section>
            <div className="page-heading compact">
              <div>
                <p className="eyebrow">Prioridad 6</p>
                <h1>Stock de insumos</h1>
                <p>
                  Actualizá las existencias desde el reporte de insumos en
                  Excel.
                </p>
              </div>
            </div>
            <article className="stock-upload">
              <div className="upload-icon">
                <Icon name="sheet" />
              </div>
              <div>
                <h2>Actualizar stock desde Excel</h2>
                <p>
                  El reporte se agrupa por <strong>Producto</strong> y suma la
                  columna <strong>Cant</strong>.
                </p>
                <small>
                  Incluye depósitos 2, 13, C18, R18 y 2OB, cualquiera sea su estado
                  operativo. Los vencidos quedan excluidos.
                </small>
              </div>
              <input
                ref={stockFileRef}
                hidden
                type="file"
                accept=".xlsx,.xls,.csv"
                onChange={(e) => void selectStockFile(e.target.files?.[0])}
              />
              <button
                className="primary-button upload-button"
                disabled={stockImport.loading}
                onClick={() => stockFileRef.current?.click()}
              >
                {stockImport.fileName ? "Elegir otro archivo" : "Subir Excel"}
              </button>
            </article>
            {stockImport.fileName && (
              <article className="import-preview">
                <div>
                  <strong>{stockImport.fileName}</strong>
                  <p>{stockImport.message}</p>
                  {stockImport.includedRows > 0 && (
                    <small>
                      {stockImport.includedRows} registros incluidos ·{" "}
                      {stockImport.excludedRows} excluidos por vencimiento o
                      depósito
                    </small>
                  )}
                </div>
                {stockImport.errors.length > 0 && (
                  <div className="import-errors">
                    <strong>{stockImport.errors.length} observaciones</strong>
                    {stockImport.errors.slice(0, 5).map((error) => (
                      <span key={error}>{error}</span>
                    ))}
                  </div>
                )}
                {stockImport.items.length > 0 && (
                  <button
                    className="primary-button"
                    disabled={stockImport.loading}
                    onClick={() => void importStock()}
                  >
                    Importar {stockImport.items.length} insumos
                  </button>
                )}
              </article>
            )}
            <article className="table-card">
              <div className="table-toolbar">
                <div>
                  <h2>Stock disponible</h2>
                  <p>
                    {visibleStock.length} de {stock.length} insumos
                  </p>
                </div>
                <label className="search-box">
                  <Icon name="search" />
                  <input
                    value={stockQuery}
                    onChange={(e) => setStockQuery(e.target.value)}
                    placeholder="Buscar código, descripción, tipo o depósito"
                  />
                </label>
              </div>
              <div className="table-scroll">
                <table>
                  <thead>
                    <tr>
                      <th>Tipo</th>
                      <th>Código</th>
                      <th>Descripción</th>
                      <th>Disponible</th>
                      <th>Distribución por depósito</th>
                    </tr>
                  </thead>
                  <tbody>
                    {visibleStock.map((item) => (
                      <tr key={item.materialCode}>
                        <td>{item.category}</td>
                        <td>{item.materialCode}</td>
                        <td>{item.materialName}</td>
                        <td className="number-cell">
                          {formatNumber(item.quantity)} {item.unit}
                        </td>
                        <td>{Object.keys(item.depots??{}).length?<div className="depot-list">{Object.entries(item.depots).sort(([a],[b])=>a.localeCompare(b)).map(([depot,quantity])=><span key={depot}><b>{depotLabel(depot)}</b> {formatNumber(quantity)}</span>)}</div>:<span className="muted-value">Sin detalle en el reporte</span>}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <details className="manual-stock">
                <summary>Corrección manual de un insumo</summary>
                <div className="bom-form">
                  <div className="bom-fields">
                    <label>
                      Código
                      <input
                        value={stockDraft.materialCode}
                        onChange={(e) =>
                          setStockDraft({
                            ...stockDraft,
                            materialCode: e.target.value,
                          })
                        }
                      />
                    </label>
                    <label>
                      Descripción
                      <input
                        value={stockDraft.materialName}
                        onChange={(e) =>
                          setStockDraft({
                            ...stockDraft,
                            materialName: e.target.value,
                          })
                        }
                      />
                    </label>
                    <label>
                      Categoría
                      <input
                        value={stockDraft.category}
                        onChange={(e) =>
                          setStockDraft({
                            ...stockDraft,
                            category: e.target.value,
                          })
                        }
                      />
                    </label>
                    <label>
                      Cantidad
                      <input
                        type="number"
                        min="0"
                        value={stockDraft.quantity}
                        onChange={(e) =>
                          setStockDraft({
                            ...stockDraft,
                            quantity: Number(e.target.value),
                          })
                        }
                      />
                    </label>
                  </div>
                  <button
                    className="primary-button"
                    onClick={() => void saveStock()}
                  >
                    Guardar corrección
                  </button>
                </div>
              </details>
            </article>
          </section>
        )}

        {view === "faltantes" && (
          <section>
            <div className="page-heading compact">
              <div>
                <p className="eyebrow">Prioridad 7</p>
                <h1>Faltantes</h1>
                <p>Insumos cuya necesidad supera el stock disponible.</p>
              </div>
              <button
                className={`refresh-button ${calculationStatus.running ? "busy" : ""}`}
                disabled={calculationStatus.running||refreshing}
                aria-busy={calculationStatus.running}
                onClick={() => void updateAndRecalculate()}
              >
                <Icon name="sync" />
                {calculationStatus.running
                  ? "Actualizando y calculando…"
                  : "Actualizar y recalcular"}
              </button>
            </div>
            <div className="bom-kpis">
              <article>
                <strong>{requirementState.mapped}</strong>
                <span>operaciones calculadas</span>
              </article>
              <article>
                <strong>{requirementState.provisional}</strong>
                <span>fichas provisionales del Sheet</span>
              </article>
              <article data-warning={shortages.length > 0}>
                <strong>{shortages.length}</strong>
                <span>insumos con faltante</span>
              </article>
            </div>
            <CalculationStatus
              status={calculationStatus}
              mapped={requirementState.mapped}
              materials={requirements.length}
              shortages={shortages.length}
              stockItems={stock.length}
            />
            {requirementState.completed>0&&(
              <p className="bom-message">
                {requirementState.completed} operaciones tachadas en Google Sheets se consideran realizadas y fueron excluidas del cálculo de faltantes.
              </p>
            )}
            {lineTransfers.length>0&&<details className="line-transfer-manager">
              <summary>Traslados a línea informados ({lineTransfers.length})</summary>
              <p>Estas cantidades se restan directamente de la necesidad total pendiente; no se suman al stock ni se vuelven a descontar del faltante.</p>
              <div className="line-transfer-list">
                {lineTransfers.map(transfer=><div className="line-transfer-row" key={transfer.materialKey}>
                  <strong>{transfer.materialCode}</strong>
                  <input type="number" min="0" step="1" value={transferDrafts[transfer.materialKey]??String(transfer.quantity)} onChange={event=>setTransferDrafts(current=>({...current,[transfer.materialKey]:event.target.value}))}/>
                  <button disabled={transferSaving===transfer.materialKey} onClick={()=>void saveLineTransfer(transfer.materialKey,transfer.materialCode)}>Guardar</button>
                  <button className="secondary-button" disabled={transferSaving===transfer.materialKey} onClick={()=>{setTransferDrafts(current=>({...current,[transfer.materialKey]:"0"}));void saveLineTransfer(transfer.materialKey,transfer.materialCode,"0");}}>Quitar</button>
                </div>)}
              </div>
            </details>}
            {transferMessage&&<p className="bom-message">{transferMessage}</p>}
            {requirementState.error ? (
              <p className="bom-message consumption-error">
                {requirementState.error}
              </p>
            ) : shortages.length === 0 ? (
              <article className="empty-consumption">
                <h2>
                  {requirements.length
                    ? "No hay faltantes"
                    : "Todavía no hay consumos calculables"}
                </h2>
                <p>
                  {requirements.length
                    ? "El stock disponible cubre las necesidades del programa actual."
                    : `No se encontraron insumos para relacionar con el programa. ${requirementState.blocked} operaciones siguen bloqueadas.`}
                </p>
              </article>
            ) : (
              <div className="shortage-report-shell">
                <div className="shortage-toolbar">
                  <div>
                    <h2>Faltantes agrupados por tipo de insumo</h2>
                    <p>{visibleShortages.length} de {shortages.length} insumos · stock compartido y detalle semanal</p>
                  </div>
                  <label className="search-box">
                    <Icon name="search" />
                    <input value={shortageQuery} onChange={(e)=>setShortageQuery(e.target.value)} placeholder="Buscar código, insumo, producto o semana"/>
                  </label>
                  <button className="secondary-button report-button" onClick={()=>void downloadShortageReport()}><Icon name="sheet"/> Descargar Excel</button>
                  <button className="primary-button report-button" onClick={printShortageReport}>Imprimir / guardar PDF</button>
                </div>
                <div className="shortage-groups">
                  {shortageGroups.map(group=><section className="shortage-group" key={group.label}>
                    <header className="shortage-group-header">
                      <div><span>Tipo de insumo</span><h2>{group.label}</h2></div>
                      <strong>{group.items.length} insumos · faltante total {formatNumber(group.totalShortage)}</strong>
                    </header>
                    <div className="shortage-group-body">
                      {group.items.map(item=><article className="shortage-material" key={item.groupKey}>
                        <div className="shortage-material-title">
                          <div>
                            <h3>{item.materialCode} · {item.materialName}</h3>
                            <p>{item.stockCodes.length>1?`Stock compartido: ${item.stockCodes.join(" + ")}`:"Código individual"} · primer faltante: {firstShortageWeek(item)}</p>
                          </div>
                          <strong>{formatNumber(item.shortage)} {item.unit}</strong>
                        </div>
                        <div className="shortage-metrics">
                          <div><span>Necesidad total</span><b>{formatNumber(item.total)}</b><small>Necesidad original {formatNumber(item.originalTotal)} − trasladado {formatNumber(item.transferred)}</small></div>
                          <div><span>Stock en depósitos</span><b>{formatNumber(item.available)}</b><small>{Object.entries(item.depots).map(([depot,quantity])=>`${depotLabel(depot)}: ${formatNumber(quantity)}`).join(" · ")||"Sin stock cargado"}</small></div>
                          <div className="line-moved"><span>Trasladado a línea</span><b>{formatNumber(item.transferred)}</b><small>Descuenta directamente la necesidad total</small></div>
                          <div className="shortage-total"><span>Faltante total</span><b>{formatNumber(item.shortage)}</b><small>Necesidad total ajustada − stock</small></div>
                        </div>
                        <div className="line-transfer-editor">
                          <label>
                            Cantidad ya trasladada a la línea
                            <input type="number" min="0" step="1" value={transferDrafts[item.groupKey]??String(item.transferred)} onChange={event=>setTransferDrafts(current=>({...current,[item.groupKey]:event.target.value}))}/>
                          </label>
                          <button className="primary-button" disabled={transferSaving===item.groupKey} onClick={()=>void saveLineTransfer(item.groupKey,item.materialCode)}>{transferSaving===item.groupKey?"Guardando…":"Guardar y recalcular"}</button>
                        </div>
                        <div className="shortage-detail-grid">
                          <section>
                            <h4>Stock por código</h4>
                            <div className="table-scroll compact-table"><table><thead><tr><th>Código</th><th>Descripción</th><th>Stock total</th><th>Depósitos</th></tr></thead><tbody>
                              {item.stockBreakdown.map(stockItem=><tr key={stockItem.materialCode}><td><strong>{stockItem.materialCode}</strong></td><td>{stockItem.materialName}</td><td>{formatNumber(stockItem.quantity)}</td><td>{Object.entries(stockItem.depots).map(([depot,quantity])=>`${depotLabel(depot)}: ${formatNumber(quantity)}`).join(" · ")||"Sin stock"}</td></tr>)}
                            </tbody></table></div>
                          </section>
                          <section>
                            <h4>Faltante por semana</h4>
                            <div className="table-scroll compact-table"><table><thead><tr><th>Semana</th><th>Necesidad original</th><th>Trasladado</th><th>Necesidad pendiente</th><th>Cubierto por stock</th><th>Faltante</th><th>Saldo stock</th></tr></thead><tbody>
                              {item.weeklyShortages.map(week=><tr key={week.weekId}><td><strong>{week.weekLabel}</strong></td><td>{formatNumber(week.quantity)}</td><td>{formatNumber(week.transferred)}</td><td>{formatNumber(week.pendingQuantity)}</td><td>{formatNumber(week.covered)}</td><td className={week.shortage>0?"number-cell":""}>{formatNumber(week.shortage)}</td><td>{formatNumber(week.remainingAvailable)}</td></tr>)}
                            </tbody></table></div>
                          </section>
                        </div>
                      </article>)}
                    </div>
                  </section>)}
                </div>
              </div>
            )}
          </section>
        )}

        {view === "usuarios" && session.role === "admin" && (
          <section>
            <div className="page-heading compact">
              <div>
                <p className="eyebrow">Administración</p>
                <h1>{adminTab==="usuarios"?"Usuarios y permisos":adminTab==="configuracion"?"Configuración operativa":"Diagnóstico del sistema"}</h1>
                <p>{adminTab==="usuarios"?"Creá cuentas, definí accesos, restablecé contraseñas o desactivá usuarios.":adminTab==="configuracion"?"Consultá los parámetros activos sin modificar la lógica que ya está funcionando.":"Comprobá la conexión, la última lectura y los datos recibidos desde Google Sheets."}</p>
              </div>
            </div>
            <nav className="admin-tabs" aria-label="Secciones de administración">
              <button data-active={adminTab==="usuarios"} onClick={()=>setAdminTab("usuarios")}>Usuarios y permisos</button>
              <button data-active={adminTab==="configuracion"} onClick={()=>setAdminTab("configuracion")}>Configuración</button>
              <button data-active={adminTab==="diagnostico"} onClick={()=>setAdminTab("diagnostico")}>Diagnóstico</button>
            </nav>
            {adminTab==="usuarios"&&<article className="table-card">
              <div className="bom-form">
                <div className="bom-fields">
                  <label>
                    Nombre
                    <input
                      value={userDraft.name}
                      onChange={(e) =>
                        setUserDraft({ ...userDraft, name: e.target.value })
                      }
                    />
                  </label>
                  <label>
                    Correo
                    <input
                      type="email"
                      value={userDraft.email}
                      onChange={(e) =>
                        setUserDraft({ ...userDraft, email: e.target.value })
                      }
                    />
                  </label>
                  <label>
                    Usuario
                    <input
                      value={userDraft.username}
                      onChange={(e) =>
                        setUserDraft({ ...userDraft, username: e.target.value })
                      }
                    />
                  </label>
                  <label>
                    {userDraft.id
                      ? "Nueva contraseña (opcional)"
                      : "Contraseña temporal"}
                    <input
                      type="password"
                      value={userDraft.password}
                      onChange={(e) =>
                        setUserDraft({ ...userDraft, password: e.target.value })
                      }
                      placeholder={
                        userDraft.id
                          ? "Dejar vacío para conservarla"
                          : "Obligatoria para usuarios nuevos"
                      }
                    />
                  </label>
                  <label>
                    Perfil
                    <select
                      value={userDraft.role}
                      onChange={(e) =>
                        setUserDraft({ ...userDraft, role: e.target.value })
                      }
                    >
                      <option value="planner">Usuario normal</option>
                      <option value="admin">Administrador</option>
                    </select>
                  </label>
                  <label>
                    Acceso
                    <select
                      value={userDraft.active ? "activo" : "inactivo"}
                      onChange={(e) =>
                        setUserDraft({
                          ...userDraft,
                          active: e.target.value === "activo",
                        })
                      }
                    >
                      <option value="activo">Habilitado</option>
                      <option value="inactivo">Bloqueado</option>
                    </select>
                  </label>
                </div>
                {userDraft.role !== "admin" && (
                  <fieldset className="permission-grid">
                    <legend>Módulos habilitados</legend>
                    {[
                      ["programacion", "Programación"],
                      ["productos", "Productos"],
                      ["bom", "Ficha técnica"],
                      ["consumos", "Consumos"],
                      ["stock", "Stock"],
                      ["faltantes", "Faltantes"],
                    ].map(([id, label]) => (
                      <label key={id}>
                        <input
                          type="checkbox"
                          checked={userDraft.permissions
                            .split(",")
                            .includes(id)}
                          onChange={(e) => {
                            const current = new Set(
                              userDraft.permissions.split(",").filter(Boolean),
                            );
                            if (e.target.checked) current.add(id);
                            else current.delete(id);
                            setUserDraft({
                              ...userDraft,
                              permissions: [...current].join(","),
                            });
                          }}
                        />
                        {label}
                      </label>
                    ))}
                  </fieldset>
                )}
                {userMessage && <p className="bom-message">{userMessage}</p>}
                <div className="user-form-actions">
                  <button
                    className="primary-button"
                    onClick={() => void saveUser()}
                  >
                    {userDraft.id ? "Guardar cambios" : "Crear usuario"}
                  </button>
                  {userDraft.id > 0 && (
                    <button
                      className="secondary-button"
                      onClick={() => setUserDraft(emptyUserDraft())}
                    >
                      Cancelar edición
                    </button>
                  )}
                </div>
              </div>
              <div className="table-toolbar">
                <div>
                  <h2>Usuarios registrados</h2>
                  <p>
                    {visibleUsers.length} de {users.length} usuarios
                  </p>
                </div>
                <label className="search-box">
                  <Icon name="search" />
                  <input
                    value={userQuery}
                    onChange={(e) => setUserQuery(e.target.value)}
                    placeholder="Buscar nombre, usuario, correo o perfil"
                  />
                </label>
              </div>
              <div className="table-scroll">
                <table>
                  <thead>
                    <tr>
                      <th>Nombre</th>
                      <th>Usuario</th>
                      <th>Correo</th>
                      <th>Perfil</th>
                      <th>Acceso</th>
                      <th>Permisos</th>
                      <th>Contraseña</th>
                      <th>Acciones</th>
                    </tr>
                  </thead>
                  <tbody>
                    {visibleUsers.map((user) => (
                      <tr key={user.id}>
                        <td>{user.name}</td>
                        <td>{user.username || "—"}</td>
                        <td>{user.email}</td>
                        <td>
                          {user.role === "admin"
                            ? "Administrador"
                            : "Usuario normal"}
                        </td>
                        <td>
                          <span
                            className={`row-status ${user.active ? "valid" : "review"}`}
                          >
                            {user.active ? "Habilitado" : "Bloqueado"}
                          </span>
                        </td>
                        <td>
                          {user.permissions === "*"
                            ? "Todos"
                            : user.permissions.split(",").length + " módulos"}
                        </td>
                        <td>{user.passwordConfigured?"Configurada · editable":"Sin configurar"}</td>
                        <td>
                          <div className="row-actions">
                            <button onClick={() => editUser(user)}>
                              Editar
                            </button>
                            {user.username !== "admin" ? (
                              <>
                                <button onClick={() => void toggleUser(user)}>
                                  {user.active ? "Bloquear" : "Habilitar"}
                                </button>
                                <button
                                  className="danger"
                                  onClick={() => void deleteUser(user)}
                                >
                                  Eliminar
                                </button>
                              </>
                            ) : (
                              <span className="protected-user">
                                Cuenta protegida
                              </span>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </article>}
            {adminTab==="configuracion"&&<article className="table-card admin-system-card">
              <div className="table-toolbar"><div><h2>Configuración operativa</h2><p>Solo el administrador puede modificar estos parámetros.</p></div><span className="row-status valid">Guardada en D1</span></div>
              <div className="admin-settings-form">
                <label>ID de Google Sheets<input value={settingsDraft.spreadsheetId} onChange={event=>setSettingsDraft(current=>({...current,spreadsheetId:event.target.value}))}/><small>No se muestran ni modifican aquí las credenciales privadas de Google.</small></label>
                <label>Sincronización automática (segundos)<input type="number" min="10" max="3600" value={settingsDraft.syncIntervalSeconds} onChange={event=>setSettingsDraft(current=>({...current,syncIntervalSeconds:Number(event.target.value)}))}/><small>Valor recomendado: 30 segundos. Todos los dispositivos comparten una sola lectura de Google por ciclo.</small></label>
                <label>Caché compartida (segundos)<input type="number" min="0" max="300" value={settingsDraft.cacheSeconds} onChange={event=>setSettingsDraft(current=>({...current,cacheSeconds:Number(event.target.value)}))}/><small>D1 conserva la última lectura válida para todos los usuarios. Recomendado: 30 segundos o más.</small></label>
                <label>Depósitos incluidos<input value={settingsDraft.includedDepots.join(", ")} onChange={event=>setSettingsDraft(current=>({...current,includedDepots:event.target.value.split(",").map(value=>value.trim().toUpperCase()).filter(Boolean)}))}/><small>Separados por coma. 13 = Producción · C18 = Calidad · 2 = Depósito 2.</small></label>
              </div>
              <div className="settings-actions"><button className="primary-button" onClick={()=>void saveSettings()}>Guardar configuración</button>{settingsMessage&&<span>{settingsMessage}</span>}</div>
              <div className="admin-config-grid">
                <section><span>Capacidad de importación</span><strong>Hasta 20.000 insumos</strong><small>La carga se realiza por lotes y verifica el total guardado.</small></section>
                <section><span>Base de datos</span><strong>Cloudflare D1</strong><small>Usuarios, fichas técnicas, stock y distribución por depósito.</small></section>
              </div>
              <div className="admin-protected-note"><strong>Protección de credenciales</strong><p>El correo de servicio y la clave privada de Google permanecen como secretos de Cloudflare. Desde aquí se modifican solamente los parámetros operativos seguros.</p></div>
            </article>}
            {adminTab==="diagnostico"&&<article className="table-card admin-system-card">
              <div className="table-toolbar"><div><h2>Estado de la integración</h2><p>Información de la sesión actual.</p></div><button className="export-button" disabled={refreshing} onClick={()=>void synchronizeProgram(true)}>{refreshing?"Probando…":"Probar conexión"}</button></div>
              <div className="admin-diagnostic-grid">
                <section data-ok={sourceState.live}><span>Conexión</span><strong>{sourceState.live?"Sincronizado en vivo":"Instantánea validada"}</strong><small>{sourceState.notice}</small></section>
                <section><span>Última lectura</span><strong>{new Intl.DateTimeFormat("es-AR",{dateStyle:"short",timeStyle:"medium"}).format(new Date(sourceState.fetchedAt))}</strong><small>Hora informada por la última respuesta válida.</small></section>
                <section><span>Semanas detectadas</span><strong>{weeks.length}</strong><small>{weeks.map(week=>week.label).join(" · ")||"Sin semanas reconocidas"}</small></section>
                <section><span>Operaciones recibidas</span><strong>{records.length}</strong><small>{records.filter(record=>record.action==="FRACCIONAR").length} fraccionar · {records.filter(record=>record.action==="VESTIR").length} vestir · {records.filter(record=>record.action==="ENCAJONAR").length} encajonar</small></section>
                <section><span>Stock almacenado</span><strong>{stock.length} insumos</strong><small>{Object.keys(stock.reduce<Record<string,number>>((all,item)=>{for(const depot of Object.keys(item.depots??{}))all[depot]=(all[depot]??0)+1;return all;},{})).join(" · ")||"Sin depósitos cargados"}</small></section>
                <section data-ok={!requirementState.error}><span>Motor de cálculo</span><strong>{requirementState.error?"Requiere atención":"Operativo"}</strong><small>{requirementState.error||`${requirementState.mapped} operaciones calculadas · ${requirementState.blocked} bloqueadas`}</small></section>
              </div>
              <div className="admin-protected-note"><strong>Sincronización multiusuario</strong><p>Todos los dispositivos leen la misma copia de D1. Si Google necesita una actualización, un solo Worker la realiza y los demás usuarios continúan trabajando con la última lectura válida.</p></div>
            </article>}
          </section>
        )}

        {view === "pendiente" && (
          <section className="gated-view">
            <span className="gated-icon">
              <Icon name="lock" />
            </span>
            <p className="eyebrow">Desarrollo por prioridades</p>
            <h1>Este módulo se habilitará después</h1>
            <p>
              Primero debemos validar completamente la lectura del programa.
              Esto evita que las fichas técnicas, el stock y los faltantes se construyan sobre datos
              interpretados de forma incorrecta.
            </p>
            <button
              className="primary-button"
              onClick={() => setView("programacion")}
            >
              Continuar con Programación
            </button>
          </section>
        )}
      </div>
      <button
        className="chat-launcher"
        onClick={() => setChatOpen((value) => !value)}
        aria-label="Abrir asistente"
      >
        <Icon name={chatOpen ? "check" : "clipboard"} />
        <span>Consultar</span>
      </button>
      {chatOpen && (
        <aside className="chat-panel">
          <header>
            <div>
              <strong>Asistente general</strong>
              <small>ERP de insumos + preguntas de cualquier tema</small>
            </div>
            <button onClick={() => setChatOpen(false)}>×</button>
          </header>
          <div className="chat-quick">
            <button
              disabled={chatLoading}
              onClick={() => void askAssistant("¿Está funcionando la sincronización?")}
            >
              Sincronización
            </button>
            <button
              disabled={chatLoading}
              onClick={() => void askAssistant("¿Qué faltantes tengo?")}
            >
              Faltantes
            </button>
            <button disabled={chatLoading} onClick={() => void askAssistant("Dame un resumen de hoy")}>
              Resumen de hoy
            </button>
            <button
              disabled={chatLoading}
              onClick={() => void askAssistant("¿Qué cambió en la programación?")}
            >
              ¿Qué cambió?
            </button>
            <button
              disabled={chatLoading}
              onClick={() => void askAssistant("¿Cuál es el estado del sistema?")}
            >
              Estado del sistema
            </button>
            <button
              disabled={chatLoading}
              onClick={() => void askAssistant("¿Cómo funciona la aplicación?")}
            >
              Cómo funciona
            </button>
          </div>
          <div className="chat-messages">
            {chatMessages.map((message, index) => (
              <div className={`chat-message ${message.from}`} key={index}>
                {message.text}
              </div>
            ))}
          </div>
          <form
            onSubmit={(event) => {
              event.preventDefault();
              void askAssistant(chatInput);
            }}
          >
            <input
              value={chatInput}
              onChange={(event) => setChatInput(event.target.value)}
              placeholder="Preguntá lo que quieras o escribí un código"
              disabled={chatLoading}
            />
            <button disabled={chatLoading}>{chatLoading?"Pensando…":"Enviar"}</button>
          </form>
        </aside>
      )}
    </main>
  );
}
