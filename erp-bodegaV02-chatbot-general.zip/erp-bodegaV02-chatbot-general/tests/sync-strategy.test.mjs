import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";

const page = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");
const sheets = await readFile(new URL("../lib/google-sheets.ts", import.meta.url), "utf8");
const route = await readFile(new URL("../app/api/program/route.ts", import.meta.url), "utf8");
const database = await readFile(new URL("../db/index.ts", import.meta.url), "utf8");

test("la sincronizacion automatica consulta la API compartida y no fuerza Google por navegador", () => {
  assert.match(page, /force[\s\S]*?"\/api\/program\?fresh=1"[\s\S]*?mode==="automatic"[\s\S]*?"\/api\/program\?background=1"[\s\S]*?mode==="stored"/);
  assert.doesNotMatch(page, /setTimeout\(resolve,8_000\)/);
  assert.match(page, /setInterval\([\s\S]*?runAutomaticCycle[\s\S]*?settings\.syncIntervalSeconds\*1000/);
  assert.match(page, /window\.addEventListener\("focus",onFocus\)/);
  assert.match(page, /window\.addEventListener\("online",onOnline\)/);
});

test("D1 contiene un lease compartido para impedir lecturas simultaneas de Google", () => {
  assert.match(database, /CREATE TABLE IF NOT EXISTS program_sync_state/);
  assert.match(sheets, /async function acquireSyncLock/);
  assert.match(sheets, /WHERE program_sync_state\.lease_until <= \?/);
  assert.match(sheets, /if \(!acquired\)/);
  assert.doesNotMatch(sheets, /let cachedProgram/);
  assert.doesNotMatch(sheets, /let pendingProgram/);
});

test("el cache no puede ser sobrescrito por una lectura mas vieja", () => {
  assert.match(sheets, /WHERE excluded\.fetched_at >= program_cache\.fetched_at/);
});

test("la ruta mantiene la ultima lectura valida y expone el estado central", () => {
  assert.match(route, /readProgramSyncState/);
  assert.match(route, /Programación compartida desde D1/);
  assert.match(route, /Google no respondió; el ERP sigue funcionando con la última lectura real guardada en D1/);
});

test("la actividad automatica es no bloqueante y solo la accion manual muestra el spinner", () => {
  assert.match(page, /const showActivity=force\|\|mode==="standard"/);
  assert.match(page, /className=\{`refresh-button \$\{refreshing \? "busy" : ""\}`\}/);
});
