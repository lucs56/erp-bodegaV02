# Activar el chatbot general en Cloudflare

El ERP puede responder consultas operativas sin IA externa, pero para responder preguntas de cualquier tema necesita una clave de la API de OpenAI.

## Variables necesarias

En la configuración del Worker agregá:

- `OPENAI_API_KEY` como secreto.
- `OPENAI_CHAT_MODEL` como variable opcional. Valor recomendado: `gpt-5.6-luna`.
- `OPENAI_MODEL` se mantiene solamente por compatibilidad con funciones
  existentes, como el lector de fichas técnicas. El chat prioriza
  `OPENAI_CHAT_MODEL`.

Podés omitir `OPENAI_CHAT_MODEL`: el chat usará `OPENAI_MODEL` si existe y,
como último respaldo, `gpt-5.6-luna`.

## Importante

- No pegues la clave en el código.
- No la agregues a `.env.example`.
- No la subas a GitHub.
- La clave se usa únicamente dentro del Worker y nunca se envía al navegador.
- El chat acepta texto libre, conserva el contexto reciente y puede usar
  búsqueda web cuando la pregunta requiere información actual.
- Cada usuario puede realizar hasta 20 consultas por minuto para proteger la
  cuenta ante errores o automatizaciones accidentales.

## Prueba rápida después del deploy

Abrí el chatbot y probá, por ejemplo:

1. `¿Qué faltantes tengo de botellas?` -> debe usar los datos del ERP.
2. `¿Quién fue San Martín?` -> debe responder como asistente general.
3. `¿Cuál es el resultado de 125 por 37?` -> debe responder normalmente.
4. `¿Qué noticias importantes hay hoy?` -> puede usar búsqueda web.
5. Hacé una segunda pregunta relacionada con la anterior -> debe conservar el contexto reciente de la conversación.
