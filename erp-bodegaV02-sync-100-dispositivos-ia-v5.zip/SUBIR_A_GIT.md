# Subir a GitHub

Repositorio: `https://github.com/lucs56/erp-bodegaV02.git`

Copiar todo el contenido de esta carpeta dentro del repositorio local `erp-bodegaV02`, reemplazando los archivos existentes y conservando la carpeta oculta `.git`.

Luego ejecutar:

```bash
git status
git add -A
git commit -m "Mejorar sincronizacion para 100 dispositivos y agregar IA general"
git push origin main
```

Si el push es rechazado por cambios remotos:

```bash
git pull --rebase origin main
git push origin main
```

Después del despliegue, configurá en Cloudflare:

- secreto `OPENAI_API_KEY`;
- variable `OPENAI_CHAT_MODEL` con el valor `gpt-5.6-luna`.

No subas la clave de OpenAI a GitHub.
