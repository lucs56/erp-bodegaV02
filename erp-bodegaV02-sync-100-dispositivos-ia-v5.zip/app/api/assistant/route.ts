import {
  generalAssistantFallback,
  type GeneralAssistantContext,
} from "../../../lib/assistant";
import { sessionUser } from "../../../lib/auth";
import {
  assistantInstructions,
  assistantModelCandidates,
  buildAssistantInput,
  sanitizeAssistantHistory,
} from "../../../lib/assistant-ai";
import { readRuntimeEnv } from "../../../lib/runtime-env";

export const dynamic = "force-dynamic";

type OpenAIResponsePayload = {
  output_text?: string;
  output?: Array<{
    content?: Array<{ type?: string; text?: string }>;
  }>;
  error?: { message?: string; code?: string };
};

const MAX_REQUEST_BYTES = 128 * 1024;
const AI_TIMEOUT_MS = 25_000;
const RATE_LIMIT_PER_MINUTE = 20;
const localRateLimits = new Map<string, { count: number; resetAt: number }>();

export async function GET(request: Request) {
  const user = await sessionUser(request);
  if (!user?.active)
    return Response.json({ error: "Sesión requerida." }, { status: 401 });
  const runtime = await readRuntimeEnv([
    "OPENAI_API_KEY",
    "OPENAI_CHAT_MODEL",
    "OPENAI_MODEL",
  ]);
  return Response.json(
    {
      enabled: Boolean(runtime.OPENAI_API_KEY),
      model:
        runtime.OPENAI_CHAT_MODEL?.trim() ||
        runtime.OPENAI_MODEL?.trim() ||
        "gpt-5.6-luna",
    },
    { headers: { "cache-control": "private, no-store" } },
  );
}

export async function POST(request: Request) {
  try {
    const user = await sessionUser(request);
    if (!user?.active)
      return Response.json({ error: "Sesión requerida." }, { status: 401 });
    if (Number(request.headers.get("content-length") ?? 0) > MAX_REQUEST_BYTES)
      return Response.json({ error: "La consulta es demasiado grande." }, { status: 413 });
    if (!consumeRateLimit(user.username || user.email))
      return Response.json(
        { error: "Se enviaron demasiadas consultas. Esperá un minuto y volvé a intentar." },
        { status: 429 },
      );

    const body = await request.json() as {
      question?: string;
      context?: GeneralAssistantContext;
      history?: unknown;
    };
    const question = String(body.question ?? "").trim().slice(0, 4000);
    if (!question)
      return Response.json({ error: "La consulta está incompleta." }, { status: 400 });

    const fallback = body.context
      ? generalAssistantFallback(question, body.context)
      : "La consulta no pudo procesarse con el contexto local.";

    // Una consulta puntual por código de insumo se responde siempre con los
    // datos determinísticos del ERP para no inventar cantidades ni depósitos.
    if (body.context?.materialQuery)
      return Response.json({ answer: fallback, mode: "erp-data" });

    const runtime = await readRuntimeEnv([
      "OPENAI_API_KEY",
      "OPENAI_CHAT_MODEL",
      "OPENAI_MODEL",
    ]);
    if (!runtime.OPENAI_API_KEY) {
      return Response.json({
        answer: isClearlyErpFallback(fallback)
          ? fallback
          : "La IA general todavía no está conectada en Cloudflare. Configurá el secreto OPENAI_API_KEY para que pueda responder preguntas de cualquier tema. Las consultas operativas del ERP siguen funcionando localmente.",
        mode: "local-no-ai",
      });
    }

    const history = sanitizeAssistantHistory(body.history);
    const input = buildAssistantInput(question, body.context, history);
    const models = assistantModelCandidates(
      runtime.OPENAI_CHAT_MODEL || runtime.OPENAI_MODEL,
    );
    const safetyIdentifier = await privacySafeUserId(user.username || user.email);

    for (const model of models) {
      try {
        const result = await requestOpenAI({
          apiKey: runtime.OPENAI_API_KEY,
          model,
          input,
          safetyIdentifier,
        });
        if (result.answer) {
          return Response.json({
            answer: result.answer,
            mode: "ai-general",
            model,
          });
        }
        if (result.stopTrying) break;
      } catch {
        // Si una variante de modelo no está disponible, probamos la siguiente.
      }
    }

    return Response.json({
      answer: isClearlyErpFallback(fallback)
        ? fallback
        : "No pude obtener respuesta de la IA general en este momento. Probá nuevamente en unos segundos. Las consultas del ERP continúan disponibles.",
      mode: "local-ai-error",
    });
  } catch {
    return Response.json({ error: "No se pudo procesar la consulta." }, { status: 400 });
  }
}

async function requestOpenAI({
  apiKey,
  model,
  input,
  safetyIdentifier,
}: {
  apiKey: string;
  model: string;
  input: Array<{ role: "developer" | "user" | "assistant"; content: string }>;
  safetyIdentifier: string;
}) {
  const controller = new AbortController();
  const timeout = globalThis.setTimeout(() => controller.abort(), AI_TIMEOUT_MS);
  let response: Response;
  try {
    response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        authorization: `Bearer ${apiKey}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        model,
        instructions: assistantInstructions(),
        input,
        tools: [{ type: "web_search" }],
        tool_choice: "auto",
        reasoning: { effort: "low" },
        safety_identifier: safetyIdentifier,
        store: false,
        max_output_tokens: 1_200,
      }),
      cache: "no-store",
      signal: controller.signal,
    });
  } finally {
    globalThis.clearTimeout(timeout);
  }

  const payload = await response.json().catch(() => ({})) as OpenAIResponsePayload;
  if (!response.ok) {
    // 401/403 indican clave/permisos: cambiar de modelo no lo arregla.
    const stopTrying = [401, 403, 429].includes(response.status);
    return { answer: "", stopTrying, status: response.status };
  }

  const answer =
    payload.output_text?.trim() ||
    payload.output
      ?.flatMap((item) => item.content ?? [])
      .find((item) => item.type === "output_text" && item.text)
      ?.text?.trim() ||
    "";
  return { answer, stopTrying: false, status: response.status };
}

function isClearlyErpFallback(answer: string) {
  return !/IA general|cualquier tema/i.test(answer);
}

function consumeRateLimit(userKey: string) {
  const now = Date.now();
  const current = localRateLimits.get(userKey);
  if (!current || current.resetAt <= now) {
    localRateLimits.set(userKey, { count: 1, resetAt: now + 60_000 });
    return true;
  }
  if (current.count >= RATE_LIMIT_PER_MINUTE) return false;
  current.count += 1;
  if (localRateLimits.size > 1_000) {
    for (const [key, value] of localRateLimits)
      if (value.resetAt <= now) localRateLimits.delete(key);
  }
  return true;
}

async function privacySafeUserId(value: string) {
  const digest = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(`erp-assistant:${value}`),
  );
  return [...new Uint8Array(digest)]
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("");
}
