import { drizzle } from "drizzle-orm/d1";
import * as schema from "./schema";

let schemaReady: Promise<void> | undefined;
const APP_SCHEMA_VERSION = 6;

async function ensureSchema(database: D1Database) {
  schemaReady ??= (async () => {
    // Una instalación ya migrada requiere una sola lectura liviana por nueva
    // instancia del Worker. Así cien clientes fríos no repiten todos los DDL y
    // PRAGMA defensivos en D1 al mismo tiempo.
    if (await schemaIsCurrent(database)) return;

    const setupStatements = [
      `CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
        code TEXT NOT NULL,
        name TEXT NOT NULL,
        active INTEGER DEFAULT 1 NOT NULL,
        updated_at TEXT NOT NULL
      )`,
      "CREATE UNIQUE INDEX IF NOT EXISTS products_code_uq ON products (code)",
      `CREATE TABLE IF NOT EXISTS bom_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
        product_id INTEGER NOT NULL,
        material_code TEXT NOT NULL,
        material_name TEXT NOT NULL,
        category TEXT NOT NULL,
        quantity REAL NOT NULL,
        unit TEXT DEFAULT 'unidad' NOT NULL,
        action TEXT NOT NULL,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
      )`,
      "CREATE UNIQUE INDEX IF NOT EXISTS bom_product_material_action_uq ON bom_items (product_id, material_code, action)",
      `CREATE TABLE IF NOT EXISTS bom_substitutes (
        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
        bom_item_id INTEGER NOT NULL,
        material_code TEXT NOT NULL,
        priority INTEGER DEFAULT 1 NOT NULL,
        FOREIGN KEY (bom_item_id) REFERENCES bom_items(id) ON DELETE CASCADE
      )`,
      "CREATE UNIQUE INDEX IF NOT EXISTS bom_substitute_uq ON bom_substitutes (bom_item_id, material_code)",
      `CREATE TABLE IF NOT EXISTS stock_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
        material_code TEXT NOT NULL,
        material_name TEXT NOT NULL,
        category TEXT NOT NULL,
        quantity REAL DEFAULT 0 NOT NULL,
        unit TEXT DEFAULT 'unidad' NOT NULL,
        updated_at TEXT NOT NULL
      )`,
      "CREATE UNIQUE INDEX IF NOT EXISTS stock_material_uq ON stock_items (material_code)",
      `CREATE TABLE IF NOT EXISTS stock_depot_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
        material_code TEXT NOT NULL,
        depot TEXT NOT NULL,
        quantity REAL DEFAULT 0 NOT NULL,
        updated_at TEXT NOT NULL
      )`,
      "CREATE UNIQUE INDEX IF NOT EXISTS stock_depot_material_uq ON stock_depot_items (material_code, depot)",
      `CREATE TABLE IF NOT EXISTS line_transfers (
        material_key TEXT PRIMARY KEY NOT NULL,
        material_code TEXT NOT NULL,
        quantity REAL DEFAULT 0 NOT NULL,
        updated_at TEXT NOT NULL
      )`,
      `CREATE TABLE IF NOT EXISTS app_users (
        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
        email TEXT NOT NULL,
        username TEXT,
        password_hash TEXT,
        name TEXT NOT NULL,
        role TEXT DEFAULT 'planner' NOT NULL,
        active INTEGER DEFAULT 1 NOT NULL,
        permissions TEXT DEFAULT 'programacion,productos,bom,consumos,stock,faltantes,compras' NOT NULL,
        updated_at TEXT NOT NULL
      )`,
      "CREATE UNIQUE INDEX IF NOT EXISTS app_users_email_uq ON app_users (email)",
      `CREATE TABLE IF NOT EXISTS app_settings (
        key TEXT PRIMARY KEY NOT NULL,
        value TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )`,
      `CREATE TABLE IF NOT EXISTS program_cache (
        key TEXT PRIMARY KEY NOT NULL,
        value TEXT NOT NULL,
        fetched_at TEXT NOT NULL
      )`,
      `CREATE TABLE IF NOT EXISTS program_sync_state (
        key TEXT PRIMARY KEY NOT NULL,
        lease_until INTEGER DEFAULT 0 NOT NULL,
        last_attempt_at TEXT,
        last_success_at TEXT,
        last_error TEXT
      )`,
      `CREATE TABLE IF NOT EXISTS program_sync_lock (
        key TEXT PRIMARY KEY NOT NULL,
        lease_until INTEGER DEFAULT 0 NOT NULL,
        owner TEXT NOT NULL
      )`,
    ];

    await database.batch(setupStatements.map((sql) => database.prepare(sql)));

    const columns = await database.prepare("PRAGMA table_info(app_users)").all<{ name: string }>();
    const names = new Set(columns.results.map((column) => column.name));
    if (!names.has("username")) await database.exec("ALTER TABLE app_users ADD username TEXT;");
    if (!names.has("password_hash")) await database.exec("ALTER TABLE app_users ADD password_hash TEXT;");
    await database.exec("CREATE UNIQUE INDEX IF NOT EXISTS app_users_username_uq ON app_users (username);");

    // Migración defensiva para instalaciones que ya recibieron una versión
    // anterior del sincronizador. CREATE TABLE IF NOT EXISTS no agrega columnas
    // nuevas a una tabla persistente, por eso verificamos el esquema real.
    const lockColumns = await database.prepare("PRAGMA table_info(program_sync_lock)").all<{ name: string }>();
    const lockNames = new Set(lockColumns.results.map((column) => column.name));
    if (!lockNames.has("lease_until"))
      await database.exec("ALTER TABLE program_sync_lock ADD lease_until INTEGER DEFAULT 0 NOT NULL;");
    if (!lockNames.has("owner"))
      await database.exec("ALTER TABLE program_sync_lock ADD owner TEXT DEFAULT '' NOT NULL;");

    const syncColumns = await database.prepare("PRAGMA table_info(program_sync_state)").all<{ name: string }>();
    const syncNames = new Set(syncColumns.results.map((column) => column.name));
    if (!syncNames.has("lease_until"))
      await database.exec("ALTER TABLE program_sync_state ADD lease_until INTEGER DEFAULT 0 NOT NULL;");
    if (!syncNames.has("last_attempt_at"))
      await database.exec("ALTER TABLE program_sync_state ADD last_attempt_at TEXT;");
    if (!syncNames.has("last_success_at"))
      await database.exec("ALTER TABLE program_sync_state ADD last_success_at TEXT;");
    if (!syncNames.has("last_error"))
      await database.exec("ALTER TABLE program_sync_state ADD last_error TEXT;");

    await database
      .prepare(
        `INSERT INTO app_settings (key,value,updated_at) VALUES (?,?,?)
         ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at`,
      )
      .bind("__schema_version", String(APP_SCHEMA_VERSION), new Date().toISOString())
      .run();

  })().catch((error) => {
    schemaReady = undefined;
    throw error;
  });

  await schemaReady;
}

async function schemaIsCurrent(database: D1Database) {
  try {
    const row = await database
      .prepare("SELECT value FROM app_settings WHERE key = ?")
      .bind("__schema_version")
      .first<{ value: string }>();
    return Number(row?.value ?? 0) >= APP_SCHEMA_VERSION;
  } catch {
    // En una base nueva todavía no existe app_settings; continúa la creación.
    return false;
  }
}

export async function getDb() {
  const database = await getD1Database();
  return drizzle(database, { schema });
}

export async function getD1Database() {
  const { env } = await import("cloudflare:workers");
  if (!env.DB) {
    throw new Error(
      "Cloudflare D1 binding `DB` is unavailable. Set the `d1` field in .openai/hosting.json to `DB` or let your control plane inject the real binding values before using the database."
    );
  }

  await ensureSchema(env.DB);
  return env.DB;
}
