import "server-only";
import * as XLSX from "xlsx";
import { parseProgramSheet, type ParsedWeek } from "./program-parser";
import { readSettings } from "./app-settings";
import { getD1Database } from "../db";
import { struckRowsBySheet } from "./xlsx-strikethrough";
import { fetchWithRetry } from "./resilient-fetch";

const DEFAULT_SHEET_ID = "1XL44rx3sNKpxowAQzY1iSjy7s8lYOsPTMngD6xeBDPQ";
const SHEETS_SCOPE = "https://www.googleapis.com/auth/spreadsheets.readonly";
const TOKEN_URL = "https://oauth2.googleapis.com/token";
const PROGRAM_CACHE_KEY = "live";
const SYNC_LOCK_KEY = "google-sheets";
const SYNC_LOCK_LEASE_MS = 60_000;
const WAIT_FOR_LEADER_MS = 28_000;
const WAIT_POLL_MS = 2_000;
const SYNC_ERROR_COOLDOWN_MS = 60_000;
const PUBLIC_EXPORT_TIMEOUT_MS = 25_000;
const GOOGLE_API_TIMEOUT_MS = 12_000;

let cachedToken: { value: string; expiresAt: number } | null = null;
let isolateRefreshFlight: Promise<LiveProgram | null> | null = null;
let isolateSnapshot: { value: LiveProgram; fetchedAt: string } | null = null;

export type LiveProgram = {
  spreadsheetId: string;
  title: string;
  fetchedAt: string;
  weeks: ParsedWeek[];
};

type StoredProgramRow = {
  value: string;
  fetched_at: string;
};

export type ProgramSyncState = {
  syncing: boolean;
  leaseUntil: number;
  lastAttemptAt: string | null;
  lastSuccessAt: string | null;
  lastError: string | null;
};

type LockResult = {
  acquired: boolean;
  owner: string | null;
  degraded: boolean;
};

/**
 * Compatibilidad con el resto del ERP.
 * force=true fuerza una nueva lectura de Google y espera el resultado.
 */
export async function readLiveProgram(force = false): Promise<LiveProgram | null> {
  return refreshProgramFromGoogle(force, true);
}

/**
 * Sincronización compartida y tolerante a fallas.
 *
 * Reglas principales:
 * - D1 es la copia común para todos los dispositivos.
 * - Solo un request obtiene el lease normal y consulta Google.
 * - Si el mecanismo de lock falla, el sistema no deja de funcionar: entra en
 *   modo degradado y permite una lectura directa para recuperar la programación.
 * - Una respuesta de Google con 0 operaciones nunca reemplaza una lectura
 *   válida previa. Esto evita que un error de parseo vacíe todo el ERP.
 * - En un arranque en frío, si otro request tomó el lock pero nunca publica el
 *   resultado, el request que espera hace una recuperación directa al vencer la
 *   espera. Así el sistema no puede quedar clavado indefinidamente en 0.
 */
export async function refreshProgramFromGoogle(
  force = false,
  waitForLeader = false,
): Promise<LiveProgram | null> {
  const settings = await readSettings();
  const stored = await readStoredProgram();
  const freshnessSeconds = Math.max(
    15,
    Number(settings.syncIntervalSeconds) || 30,
    Number(settings.cacheSeconds) || 0,
  );

  if (!force && stored && isFresh(stored.fetchedAt, freshnessSeconds)) {
    return stored.value;
  }

  // Una misma instancia del Worker puede recibir muchas solicitudes a la vez.
  // Este single-flight local evita trabajo duplicado incluso antes de consultar
  // el lease compartido de D1. D1 sigue siendo quien coordina entre instancias.
  if (isolateRefreshFlight) {
    if (stored && !waitForLeader) return stored.value;
    return (await isolateRefreshFlight) ?? stored?.value ?? null;
  }

  const lock = await acquireSyncLockSafe();
  if (!lock.acquired) {
    if (stored && !waitForLeader) return stored.value;

    if (waitForLeader) {
      const leaderResult = await waitForLeaderResult(stored?.fetchedAt ?? null);
      if (leaderResult) return leaderResult;
    }

    // Recuperación de arranque en frío. Si por cualquier motivo el líder no
    // publicó nada, se prioriza disponibilidad por encima del lock.
    if (!stored && lock.degraded) {
      return runIsolateRefresh(() =>
        fetchValidateAndStore(settings.spreadsheetId, null, true),
      );
    }

    return stored?.value ?? null;
  }

  return runIsolateRefresh(async () => {
    let successAt: string | null = null;
    let failure: unknown = null;

    try {
      // Otro request pudo terminar justo antes de que este request tomara el
      // lease. Evitamos una consulta duplicada en el ciclo automático.
      if (!force) {
        const latest = await readStoredProgram();
        if (latest && isFresh(latest.fetchedAt, freshnessSeconds)) {
          successAt = latest.fetchedAt;
          return latest.value;
        }

        // Si Google acaba de fallar, mantenemos la última lectura y esperamos
        // un minuto antes de probar nuevamente. Sin este enfriamiento, cien
        // dispositivos podrían encadenar reintentos apenas se libera el lease.
        if (stored) {
          const state = await readProgramSyncState();
          if (isErrorCooldownActive(state)) return stored.value;
        }
      }

      const fresh = await fetchValidateAndStore(
        settings.spreadsheetId,
        stored?.value ?? null,
        lock.degraded,
      );
      successAt = fresh?.fetchedAt ?? null;
      return fresh ?? stored?.value ?? null;
    } catch (error) {
      failure = error;
      if (stored) return stored.value;
      throw error;
    } finally {
      await releaseSyncLockSafe(lock.owner, successAt, failure);
    }
  });
}

/** Lee siempre la última lectura válida guardada en D1, aunque sea antigua. */
export async function readLastStoredProgram(): Promise<LiveProgram | null> {
  return (await readStoredProgram())?.value ?? null;
}

export async function readProgramSyncState(): Promise<ProgramSyncState> {
  try {
    const db = await getD1Database();
    const [stateRow, lockRow] = await Promise.all([
      db
        .prepare(
          "SELECT last_attempt_at,last_success_at,last_error FROM program_sync_state WHERE key = ?",
        )
        .bind(SYNC_LOCK_KEY)
        .first<{
          last_attempt_at: string | null;
          last_success_at: string | null;
          last_error: string | null;
        }>(),
      db
        .prepare("SELECT lease_until FROM program_sync_lock WHERE key = ?")
        .bind(SYNC_LOCK_KEY)
        .first<{ lease_until: number | string | null }>(),
    ]);
    const leaseUntil = Number(lockRow?.lease_until ?? 0);
    return {
      syncing: leaseUntil > Date.now(),
      leaseUntil,
      lastAttemptAt: stateRow?.last_attempt_at ?? null,
      lastSuccessAt: stateRow?.last_success_at ?? null,
      lastError: stateRow?.last_error ?? null,
    };
  } catch {
    return {
      syncing: false,
      leaseUntil: 0,
      lastAttemptAt: null,
      lastSuccessAt: null,
      lastError: null,
    };
  }
}

async function readStoredProgram(): Promise<{ value: LiveProgram; fetchedAt: string } | null> {
  try {
    const db = await getD1Database();
    const row = await db
      .prepare("SELECT value,fetched_at FROM program_cache WHERE key = ?")
      .bind(PROGRAM_CACHE_KEY)
      .first<StoredProgramRow>();
    if (!row?.value) return null;
    const value = JSON.parse(row.value) as LiveProgram;
    if (!isUsableProgram(value)) return null;
    const snapshot = { value, fetchedAt: row.fetched_at || value.fetchedAt };
    isolateSnapshot = snapshot;
    return snapshot;
  } catch {
    // D1 es la fuente compartida. Esta copia de proceso es únicamente un
    // salvavidas para que una instancia ya caliente no golpee Google si D1
    // atraviesa una falla breve.
    return isolateSnapshot;
  }
}

async function writeSharedCache(value: LiveProgram) {
  assertUsableProgram(value);
  const db = await getD1Database();
  await db
    .prepare(
      `INSERT INTO program_cache (key,value,fetched_at) VALUES (?,?,?)
       ON CONFLICT(key) DO UPDATE SET
         value=excluded.value,
         fetched_at=excluded.fetched_at
       WHERE excluded.fetched_at >= program_cache.fetched_at`,
    )
    .bind(PROGRAM_CACHE_KEY, JSON.stringify(value), value.fetchedAt)
    .run();
  isolateSnapshot = { value, fetchedAt: value.fetchedAt };
}

async function fetchValidateAndStore(
  spreadsheetId: string,
  fallback: LiveProgram | null,
  degradedLock: boolean,
) {
  try {
    const fresh = await fetchLiveProgram(spreadsheetId);
    assertUsableProgram(fresh);
    try {
      await writeSharedCache(fresh);
    } catch (storageError) {
      if (!degradedLock) throw storageError;
      // Si D1 está transitoriamente fuera de servicio, la instancia líder
      // conserva la lectura en memoria. No se promete sincronización global
      // hasta que D1 vuelva, pero tampoco se deja la pantalla vacía.
      isolateSnapshot = { value: fresh, fetchedAt: fresh.fetchedAt };
    }
    await writeSyncSuccess(fresh.fetchedAt);
    return fresh;
  } catch (error) {
    const prefix = degradedLock
      ? "El lock de sincronización estaba en modo degradado. "
      : "";
    await writeSyncError(`${prefix}${errorMessage(error)}`);
    if (fallback) return fallback;
    throw error;
  }
}

async function acquireSyncLockSafe(): Promise<LockResult> {
  const owner = createLockOwner();
  try {
    const db = await getD1Database();
    const now = Date.now();
    const leaseUntil = now + SYNC_LOCK_LEASE_MS;
    await db
      .prepare(
        `INSERT INTO program_sync_lock (key,lease_until,owner)
         VALUES (?,?,?)
         ON CONFLICT(key) DO UPDATE SET
           lease_until=excluded.lease_until,
           owner=excluded.owner
         WHERE program_sync_lock.lease_until <= ?`,
      )
      .bind(SYNC_LOCK_KEY, leaseUntil, owner, now)
      .run();

    // No dependemos de meta.changes ni de RETURNING. Verificamos quién quedó
    // como dueño del lease después del UPSERT. Si otro Worker ya lo tenía, su
    // owner permanece sin cambios hasta que venza el lease.
    const lockRow = await db
      .prepare("SELECT owner,lease_until FROM program_sync_lock WHERE key=?")
      .bind(SYNC_LOCK_KEY)
      .first<{ owner: string; lease_until: number | string }>();
    const acquired =
      lockRow?.owner === owner && Number(lockRow.lease_until) === leaseUntil;
    if (!acquired) return { acquired: false, owner: null, degraded: false };

    await writeSyncAttempt();
    return { acquired: true, owner, degraded: false };
  } catch (error) {
    // Con una copia válida fallamos cerrado: quien llama devuelve D1/memoria y
    // no inicia una estampida contra Google. Solo un arranque sin ninguna copia
    // usa el single-flight local como recuperación.
    await writeSyncError(`Lock D1 no disponible: ${errorMessage(error)}`);
    return { acquired: false, owner: null, degraded: true };
  }
}

async function releaseSyncLockSafe(
  owner: string | null,
  successAt: string | null,
  failure: unknown,
) {
  try {
    if (failure) await writeSyncError(errorMessage(failure));
    else if (successAt) await writeSyncSuccess(successAt);

    if (!owner) return;
    const db = await getD1Database();
    await db
      .prepare("DELETE FROM program_sync_lock WHERE key=? AND owner=?")
      .bind(SYNC_LOCK_KEY, owner)
      .run();
  } catch {
    // El lease vence por sí solo. Nunca se bloquea la respuesta por liberar lock.
  }
}

async function writeSyncAttempt() {
  try {
    const db = await getD1Database();
    const attemptAt = new Date().toISOString();
    await db
      .prepare(
        `INSERT INTO program_sync_state (key,lease_until,last_attempt_at,last_success_at,last_error)
         VALUES (?,0,?,NULL,NULL)
         ON CONFLICT(key) DO UPDATE SET
           last_attempt_at=excluded.last_attempt_at,
           last_error=NULL`,
      )
      .bind(SYNC_LOCK_KEY, attemptAt)
      .run();
  } catch {
    // El estado es observabilidad, no debe impedir la sincronización.
  }
}

async function writeSyncSuccess(successAt: string) {
  try {
    const db = await getD1Database();
    await db
      .prepare(
        `INSERT INTO program_sync_state (key,lease_until,last_attempt_at,last_success_at,last_error)
         VALUES (?,0,?,?,NULL)
         ON CONFLICT(key) DO UPDATE SET
           last_success_at=excluded.last_success_at,
           last_error=NULL`,
      )
      .bind(SYNC_LOCK_KEY, successAt, successAt)
      .run();
  } catch {
    // No bloquea la sincronización real.
  }
}

async function writeSyncError(message: string) {
  try {
    const db = await getD1Database();
    const now = new Date().toISOString();
    await db
      .prepare(
        `INSERT INTO program_sync_state (key,lease_until,last_attempt_at,last_success_at,last_error)
         VALUES (?,0,?,NULL,?)
         ON CONFLICT(key) DO UPDATE SET
           last_attempt_at=excluded.last_attempt_at,
           last_error=excluded.last_error`,
      )
      .bind(SYNC_LOCK_KEY, now, message.slice(0, 500))
      .run();
  } catch {
    // Si falla el registro del error, el error original sigue propagándose.
  }
}

async function waitForLeaderResult(previousFetchedAt: string | null): Promise<LiveProgram | null> {
  const deadline = Date.now() + WAIT_FOR_LEADER_MS;
  while (Date.now() < deadline) {
    await delay(WAIT_POLL_MS);
    const stored = await readStoredProgram();
    if (stored && (!previousFetchedAt || stored.fetchedAt !== previousFetchedAt)) {
      return stored.value;
    }
    const state = await readProgramSyncState();
    if (!state.syncing) return stored?.value ?? null;
  }
  return (await readStoredProgram())?.value ?? null;
}

function createLockOwner() {
  return `${Date.now()}-${crypto.randomUUID()}`;
}

function isFresh(fetchedAt: string, maxAgeSeconds: number) {
  const timestamp = Date.parse(fetchedAt);
  return Number.isFinite(timestamp) && Date.now() - timestamp < maxAgeSeconds * 1000;
}

function isErrorCooldownActive(state: ProgramSyncState) {
  if (!state.lastError || !state.lastAttemptAt) return false;
  const attemptedAt = Date.parse(state.lastAttemptAt);
  return (
    Number.isFinite(attemptedAt) &&
    Date.now() - attemptedAt < SYNC_ERROR_COOLDOWN_MS
  );
}

async function runIsolateRefresh(
  operation: () => Promise<LiveProgram | null>,
) {
  if (isolateRefreshFlight) return isolateRefreshFlight;
  const flight = operation();
  isolateRefreshFlight = flight;
  try {
    return await flight;
  } finally {
    if (isolateRefreshFlight === flight) isolateRefreshFlight = null;
  }
}

function errorMessage(error: unknown) {
  const message = error instanceof Error ? error.message : String(error ?? "Error de sincronización");
  return message.slice(0, 500);
}

function delay(milliseconds: number) {
  return new Promise<void>((resolve) => globalThis.setTimeout(resolve, milliseconds));
}

function operationCount(program: LiveProgram) {
  return program.weeks.reduce((total, week) => total + week.records.length, 0);
}

function isUsableProgram(program: LiveProgram | null | undefined) {
  return Boolean(program && program.weeks.length > 0 && operationCount(program) > 0);
}

function assertUsableProgram(program: LiveProgram) {
  const records = operationCount(program);
  if (program.weeks.length === 0 || records === 0) {
    throw new Error(
      "Google Sheets respondió, pero no se reconocieron operaciones válidas. Se conserva la última programación para evitar vaciar el ERP.",
    );
  }
}

/**
 * Lee Google por dos caminos independientes.
 *
 * 1) Exportación XLSX pública: es el camino más compatible con el ERP original
 *    y conserva el formato de tachado.
 * 2) API autenticada: se usa como respaldo si el Sheet no permite exportación
 *    pública y existen credenciales de Service Account.
 */
async function fetchLiveProgram(configuredSpreadsheetId: string): Promise<LiveProgram> {
  const runtimeEnv = await runtimeVariables();
  const spreadsheetId =
    configuredSpreadsheetId || runtimeEnv.GOOGLE_SHEET_ID || DEFAULT_SHEET_ID;
  const errors: string[] = [];

  try {
    const publicProgram = await readPublicWorkbook(spreadsheetId);
    assertUsableProgram(publicProgram);
    return publicProgram;
  } catch (error) {
    errors.push(`exportación XLSX: ${errorMessage(error)}`);
  }

  const serviceAccountEmail = runtimeEnv.GOOGLE_SHEETS_SERVICE_ACCOUNT_EMAIL;
  const privateKey = runtimeEnv.GOOGLE_SHEETS_PRIVATE_KEY?.replace(/\\n/g, "\n");

  if (serviceAccountEmail && privateKey) {
    try {
      const authenticated = await readAuthenticatedWorkbook(
        spreadsheetId,
        serviceAccountEmail,
        privateKey,
      );
      assertUsableProgram(authenticated);
      return authenticated;
    } catch (error) {
      errors.push(`API autenticada: ${errorMessage(error)}`);
    }
  } else {
    errors.push("API autenticada: no hay Service Account configurada");
  }

  throw new Error(`No se pudo leer la programación. ${errors.join(" · ")}`);
}

async function readAuthenticatedWorkbook(
  spreadsheetId: string,
  serviceAccountEmail: string,
  privateKey: string,
): Promise<LiveProgram> {
  const token = await accessToken(serviceAccountEmail, privateKey);
  const metadataUrl = new URL(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}`,
  );
  metadataUrl.searchParams.set(
    "fields",
    "properties(title),sheets(properties(sheetId,title,index,hidden,gridProperties(rowCount)))",
  );
  const metadata = await googleJson<{
    properties?: { title?: string };
    sheets?: Array<{
      properties?: {
        sheetId?: number;
        title?: string;
        index?: number;
        hidden?: boolean;
        gridProperties?: { rowCount?: number };
      };
    }>;
  }>(metadataUrl, token, GOOGLE_API_TIMEOUT_MS);

  const tabs = (metadata.sheets ?? [])
    .map((sheet) => sheet.properties)
    .filter(
      (properties): properties is NonNullable<typeof properties> =>
        Boolean(properties?.title) && !properties?.hidden,
    )
    .sort((left, right) => (left.index ?? 0) - (right.index ?? 0));

  if (tabs.length === 0) throw new Error("La planilla no contiene pestañas visibles.");

  // Primero se leen solo valores. Esto es mucho más liviano que solicitar
  // includeGridData sobre miles de filas y garantiza que los datos principales
  // estén disponibles rápidamente.
  const valueRanges = tabs.map((tab) => {
    const escapedTitle = String(tab.title).replace(/'/g, "''");
    const rowLimit = Math.min(tab.gridProperties?.rowCount ?? 1500, 5000);
    return `'${escapedTitle}'!A1:Z${rowLimit}`;
  });
  const batchUrl = new URL(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values:batchGet`,
  );
  batchUrl.searchParams.set("majorDimension", "ROWS");
  batchUrl.searchParams.set("valueRenderOption", "FORMATTED_VALUE");
  for (const range of valueRanges) batchUrl.searchParams.append("ranges", range);
  const valuesResponse = await googleJson<{
    valueRanges?: Array<{ values?: unknown[][] }>;
  }>(batchUrl, token, GOOGLE_API_TIMEOUT_MS);

  const valuesByTitle = new Map<string, unknown[][]>();
  tabs.forEach((tab, index) => {
    valuesByTitle.set(
      String(tab.title),
      valuesResponse.valueRanges?.[index]?.values ?? [],
    );
  });

  // Para detectar tachados pedimos formato solo hasta la última fila que
  // realmente contiene valores, no hasta el rowCount total de la hoja.
  const struckByTitle = new Map<string, Set<number>>();
  try {
    const formatUrl = new URL(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}`,
    );
    formatUrl.searchParams.set("includeGridData", "true");
    formatUrl.searchParams.set(
      "fields",
      "sheets(properties(title),data(startRow,rowData(values(effectiveFormat(textFormat(strikethrough))))))",
    );
    for (const tab of tabs) {
      const title = String(tab.title);
      const escapedTitle = title.replace(/'/g, "''");
      const rows = Math.max(1, valuesByTitle.get(title)?.length ?? 1);
      formatUrl.searchParams.append("ranges", `'${escapedTitle}'!A1:Z${rows}`);
    }

    const formats = await googleJson<{
      sheets?: Array<{
        properties?: { title?: string };
        data?: Array<{
          startRow?: number;
          rowData?: Array<{
            values?: Array<{
              effectiveFormat?: { textFormat?: { strikethrough?: boolean } };
            }>;
          }>;
        }>;
      }>;
    }>(formatUrl, token, GOOGLE_API_TIMEOUT_MS);

    for (const sheet of formats.sheets ?? []) {
      const title = String(sheet.properties?.title ?? "");
      const struck = new Set<number>();
      for (const grid of sheet.data ?? []) {
        const startRow = grid.startRow ?? 0;
        for (const [rowIndex, row] of (grid.rowData ?? []).entries()) {
          if (
            (row.values ?? [])
              .slice(0, 26)
              .some(
                (cell) =>
                  cell.effectiveFormat?.textFormat?.strikethrough === true,
              )
          ) {
            struck.add(startRow + rowIndex + 1);
          }
        }
      }
      struckByTitle.set(title, struck);
    }
  } catch (formatError) {
    // Si la API de formato falla, intentamos una última vez la exportación XLSX
    // porque el ERP no debe calcular faltantes ignorando filas tachadas.
    try {
      return await readPublicWorkbook(spreadsheetId);
    } catch {
      throw new Error(
        `Se pudieron leer valores pero no los tachados de Google Sheets: ${errorMessage(formatError)}`,
      );
    }
  }

  const weeks = tabs
    .map((tab) =>
      parseProgramSheet({
        sheetId: Number(tab.sheetId ?? 0),
        title: String(tab.title),
        values: valuesByTitle.get(String(tab.title)) ?? [],
        struckRows: struckByTitle.get(String(tab.title)),
      }),
    )
    .filter((week) => week.weekId !== "unknown");

  return {
    spreadsheetId,
    title: metadata.properties?.title ?? "Programación",
    fetchedAt: new Date().toISOString(),
    weeks,
  };
}

async function readPublicWorkbook(spreadsheetId: string): Promise<LiveProgram> {
  const url = new URL(`https://docs.google.com/spreadsheets/d/${spreadsheetId}/export`);
  url.searchParams.set("format", "xlsx");
  url.searchParams.set("_", Date.now().toString());

  const response = await googleFetch(
    url,
    {
      cache: "no-store",
      headers: {
        "cache-control": "no-cache, no-store",
        pragma: "no-cache",
      },
    },
    PUBLIC_EXPORT_TIMEOUT_MS,
    0,
  );

  if (!response.ok) {
    throw new Error(
      response.status === 401 || response.status === 403
        ? "Google Sheets no permite descargar la programación por enlace."
        : `Google Sheets respondió ${response.status} al exportar XLSX.`,
    );
  }

  const contentType = response.headers.get("content-type") ?? "";
  const buffer = await response.arrayBuffer();
  if (buffer.byteLength < 1000) {
    throw new Error("Google devolvió un archivo XLSX vacío o incompleto.");
  }
  if (contentType.includes("text/html")) {
    throw new Error("Google devolvió una página de acceso en lugar del XLSX.");
  }

  const workbook = XLSX.read(buffer, {
    type: "array",
    cellDates: true,
    cellStyles: true,
    bookFiles: true,
  });
  const struckRows = struckRowsBySheet(workbook);
  const weeks = workbook.SheetNames.map((title, index) =>
    parseProgramSheet({
      sheetId: index + 1,
      title,
      values: XLSX.utils.sheet_to_json<unknown[]>(workbook.Sheets[title], {
        header: 1,
        defval: "",
        raw: false,
      }),
      struckRows: struckRows.get(title),
    }),
  ).filter((week) => week.weekId !== "unknown");

  return {
    spreadsheetId,
    title: "Programación Junín",
    fetchedAt: new Date().toISOString(),
    weeks,
  };
}

async function accessToken(email: string, privateKey: string) {
  if (cachedToken && cachedToken.expiresAt > Date.now() + 60_000) {
    return cachedToken.value;
  }
  const now = Math.floor(Date.now() / 1000);
  const header = base64Url(
    new TextEncoder().encode(JSON.stringify({ alg: "RS256", typ: "JWT" })),
  );
  const claims = base64Url(
    new TextEncoder().encode(
      JSON.stringify({
        iss: email,
        scope: SHEETS_SCOPE,
        aud: TOKEN_URL,
        iat: now - 30,
        exp: now + 3600,
      }),
    ),
  );
  const unsigned = `${header}.${claims}`;
  const key = await crypto.subtle.importKey(
    "pkcs8",
    pemBytes(privateKey),
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const signature = await crypto.subtle.sign(
    "RSASSA-PKCS1-v1_5",
    key,
    new TextEncoder().encode(unsigned),
  );
  const assertion = `${unsigned}.${base64Url(new Uint8Array(signature))}`;
  const response = await googleFetch(
    TOKEN_URL,
    {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
        assertion,
      }),
    },
    GOOGLE_API_TIMEOUT_MS,
    0,
  );
  if (!response.ok) {
    throw new Error(`Google rechazó la autenticación de solo lectura (${response.status}).`);
  }
  const body = (await response.json()) as {
    access_token?: string;
    expires_in?: number;
  };
  if (!body.access_token) throw new Error("Google no devolvió un token de acceso.");
  cachedToken = {
    value: body.access_token,
    expiresAt: Date.now() + (body.expires_in ?? 3600) * 1000,
  };
  return cachedToken.value;
}

async function googleJson<T>(url: URL, token: string, timeoutMs: number): Promise<T> {
  const response = await googleFetch(
    url,
    { headers: { authorization: `Bearer ${token}` }, cache: "no-store" },
    timeoutMs,
    0,
  );
  if (!response.ok) {
    let detail = "";
    try {
      const body = (await response.json()) as {
        error?: { message?: string };
      };
      detail = body.error?.message ? `: ${body.error.message}` : "";
    } catch {
      // La respuesta puede no ser JSON.
    }
    throw new Error(`No se pudo leer Google Sheets (${response.status})${detail}.`);
  }
  return response.json() as Promise<T>;
}

async function runtimeVariables() {
  const values: Record<string, string | undefined> = {
    GOOGLE_SHEET_ID:
      typeof process !== "undefined" ? process.env.GOOGLE_SHEET_ID : undefined,
    GOOGLE_SHEETS_SERVICE_ACCOUNT_EMAIL:
      typeof process !== "undefined"
        ? process.env.GOOGLE_SHEETS_SERVICE_ACCOUNT_EMAIL
        : undefined,
    GOOGLE_SHEETS_PRIVATE_KEY:
      typeof process !== "undefined"
        ? process.env.GOOGLE_SHEETS_PRIVATE_KEY
        : undefined,
  };
  try {
    const workers = await import("cloudflare:workers");
    const workerEnv = workers.env as unknown as Record<string, unknown>;
    for (const name of Object.keys(values)) {
      if (!values[name] && typeof workerEnv[name] === "string") {
        values[name] = workerEnv[name] as string;
      }
    }
  } catch {
    // Node-based build validation does not expose the Cloudflare runtime module.
  }
  return values;
}

function googleFetch(
  input: RequestInfo | URL,
  init: RequestInit | undefined,
  timeoutMs: number,
  maxRetries: number,
) {
  return fetchWithRetry(input, init, {
    timeoutMs,
    maxRetries,
    retryDelayMs: 700,
  });
}

function pemBytes(pem: string) {
  const encoded = pem.replace(
    /-----BEGIN PRIVATE KEY-----|-----END PRIVATE KEY-----|\s/g,
    "",
  );
  const binary = atob(encoded);
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}

function base64Url(bytes: Uint8Array) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary)
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}
