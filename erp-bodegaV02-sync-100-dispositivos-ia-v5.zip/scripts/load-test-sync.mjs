#!/usr/bin/env node

const target = process.argv[2];
const requestedClients = Number(process.argv[3] ?? 100);

if (!target) {
  console.error(
    "Uso: npm run test:sync-load -- https://tu-worker.workers.dev [cantidad]",
  );
  process.exit(64);
}

if (!Number.isInteger(requestedClients) || requestedClients < 1 || requestedClients > 500) {
  console.error("La cantidad debe ser un entero entre 1 y 500.");
  process.exit(64);
}

const endpoint = new URL("/api/program?background=1", target);
const startedAt = performance.now();

const requests = Array.from({ length: requestedClients }, async (_, index) => {
  // Simula el pequeño desfase natural de cien navegadores sin prolongar la prueba.
  await new Promise((resolve) => setTimeout(resolve, Math.floor(Math.random() * 1_500)));
  const requestStartedAt = performance.now();
  const response = await fetch(endpoint, {
    cache: "no-store",
    signal: AbortSignal.timeout(80_000),
    headers: { "x-sync-load-client": String(index + 1) },
  });
  const payload = await response.json().catch(() => ({}));
  return {
    status: response.status,
    durationMs: Math.round(performance.now() - requestStartedAt),
    records: Array.isArray(payload.records) ? payload.records.length : 0,
    fetchedAt: String(payload.source?.fetchedAt ?? ""),
    mode: String(payload.source?.mode ?? "unknown"),
  };
});

const settled = await Promise.allSettled(requests);
const successes = settled
  .filter((result) => result.status === "fulfilled")
  .map((result) => result.value);
const failures = settled.filter((result) => result.status === "rejected");
const httpErrors = successes.filter((result) => result.status < 200 || result.status >= 300);
const durations = successes.map((result) => result.durationMs).sort((a, b) => a - b);
const percentile = (value) =>
  durations.length
    ? durations[Math.min(durations.length - 1, Math.ceil(durations.length * value) - 1)]
    : 0;
const versions = new Set(successes.map((result) => result.fetchedAt).filter(Boolean));
const empty = successes.filter((result) => result.records === 0);

console.log(JSON.stringify({
  endpoint: endpoint.toString(),
  clients: requestedClients,
  completed: successes.length,
  failed: failures.length + httpErrors.length,
  emptyResponses: empty.length,
  sharedVersions: versions.size,
  p50Ms: percentile(0.5),
  p95Ms: percentile(0.95),
  maxMs: durations.at(-1) ?? 0,
  totalMs: Math.round(performance.now() - startedAt),
}, null, 2));

if (failures.length || httpErrors.length || empty.length) process.exit(1);
