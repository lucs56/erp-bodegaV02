import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";

const page = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");
const sheets = await readFile(new URL("../lib/google-sheets.ts", import.meta.url), "utf8");
const route = await readFile(new URL("../app/api/program/route.ts", import.meta.url), "utf8");
const database = await readFile(new URL("../db/index.ts", import.meta.url), "utf8");
const settings = await readFile(new URL("../lib/app-settings.ts", import.meta.url), "utf8");

test("la sincronizacion automatica usa un request lider y no waitUntil", () => {
  assert.match(page, /mode==="automatic"[\s\S]*?"\/api\/program\?background=1"/);
  assert.match(route, /refreshProgramFromGoogle\(force, force \|\| !automatic\)/);
  assert.doesNotMatch(route, /scheduleBackgroundRefresh/);
});

test("D1 contiene un lease compartido con owner y migracion defensiva", () => {
  assert.match(database, /CREATE TABLE IF NOT EXISTS program_sync_state/);
  assert.match(database, /CREATE TABLE IF NOT EXISTS program_sync_lock/);
  assert.match(database, /PRAGMA table_info\(program_sync_lock\)/);
  assert.match(database, /ALTER TABLE program_sync_lock ADD owner/);
  assert.match(sheets, /SELECT owner,lease_until FROM program_sync_lock/);
  assert.doesNotMatch(sheets, /meta\?\.changes/);
  assert.match(sheets, /DELETE FROM program_sync_lock WHERE key=\? AND owner=\?/);
  assert.doesNotMatch(sheets, /let cachedProgram/);
  assert.doesNotMatch(sheets, /let pendingProgram/);
});

test("el cache no puede ser sobrescrito por una lectura mas vieja ni por cero operaciones", () => {
  assert.match(sheets, /WHERE excluded\.fetched_at >= program_cache\.fetched_at/);
  assert.match(sheets, /Google Sheets respondió, pero no se reconocieron operaciones válidas/);
  assert.match(sheets, /if \(!isUsableProgram\(value\)\) return null/);
});

test("la lectura de Google tiene dos caminos independientes", () => {
  assert.match(sheets, /readPublicWorkbook\(spreadsheetId\)/);
  assert.match(sheets, /readAuthenticatedWorkbook/);
  assert.match(sheets, /exportación XLSX/);
  assert.match(sheets, /API autenticada/);
});

test("el lock evita estampidas y el arranque en frio conserva recuperacion", () => {
  assert.match(sheets, /isolateRefreshFlight/);
  assert.match(sheets, /SYNC_ERROR_COOLDOWN_MS/);
  assert.match(sheets, /return \{ acquired: false, owner: null, degraded: true \}/);
  assert.match(sheets, /if \(!stored && lock\.degraded\)/);
});

test("las instancias frias no repiten migraciones ni lecturas de configuracion", () => {
  assert.match(database, /APP_SCHEMA_VERSION/);
  assert.match(database, /schemaIsCurrent\(database\)/);
  assert.match(database, /__schema_version/);
  assert.match(settings, /SETTINGS_CACHE_MS/);
  assert.match(settings, /settingsCache/);
});

test("el cliente da tiempo al request sin hacer reintentos duplicados", () => {
  assert.match(page, /mode==="stored"\?5_000:70_000/);
  assert.match(page, /mode==="stored"\?5_000:70_000,[\s\S]*?0,/);
  assert.doesNotMatch(page, /for\(let attempt=0;attempt<8/);
  assert.match(page, /Math\.random\(\)/);
  assert.match(page, /erp-program-sync/);
});
