import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const page = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");
const route = await readFile(new URL("../app/api/program/route.ts", import.meta.url), "utf8");

test("la sincronizacion automatica no muestra spinner global", () => {
  assert.match(page, /const showActivity=force\|\|mode==="standard"/);
});

test("el primer ingreso carga stock mientras Google sincroniza en paralelo", () => {
  assert.match(page, /const programSync=synchronizeProgram\(false,false,"automatic"\)/);
  assert.match(page, /Promise\.all\(\[loadBoms\(\), loadStock\(\), loadLineTransfers\(\)\]\)/);
  assert.match(page, /await programSync/);
});

test("el resumen muestra el error real si programacion queda vacia", () => {
  assert.match(page, /Programación sin datos/);
  assert.match(page, /sourceState\.notice/);
  assert.match(page, /Reintentar Google/);
});

test("el ciclo automatico no depende de scheduleBackgroundRefresh", () => {
  assert.match(route, /const automatic = mode\.get\("background"\) === "1"/);
  assert.match(route, /refreshProgramFromGoogle\(force, force \|\| !automatic\)/);
  assert.doesNotMatch(route, /scheduleBackgroundRefresh/);
});

test("la primera programacion recibida dispara el calculo sin marcar un cambio falso", () => {
  assert.match(page, /const previousRecords=recordsRef\.current/);
  assert.match(page, /payloadChanged=change\.total>0/);
  assert.match(page, /previousRecords\.length>0&&liveRef\.current/);
});

test("cien navegadores no sincronizan todos en el mismo instante", () => {
  assert.match(page, /const jitterMs=.*Math\.random/);
  assert.match(page, /locks\.request\("erp-program-sync"/);
  assert.doesNotMatch(page, /window\.setInterval\(/);
});
