# Corrección de sincronización v4

Esta versión corrige el caso observado en producción donde Stock cargaba desde D1 pero Programación quedaba en 0 y la pantalla permanecía en estado de actualización.

Cambios principales:

1. La programación guardada con 0 operaciones deja de considerarse una lectura válida. Nunca puede reemplazar una programación útil.
2. Google Sheets se intenta leer por dos caminos independientes: primero la exportación XLSX compatible con el ERP original y, si falla, la API autenticada con Service Account.
3. La exportación XLSX conserva el formato de tachado utilizado para excluir operaciones realizadas.
4. La API autenticada lee primero valores y luego solamente el rango utilizado para detectar tachados, reduciendo el tamaño de la consulta.
5. El lock de D1 es fail-open: un problema en la tabla de lock no puede dejar a todo el ERP sin programación.
6. El arranque en frío tiene recuperación directa si otro request tomó el lease pero no consiguió publicar datos.
7. El lock ya no depende de `meta.changes`; verifica directamente el owner guardado en D1.
8. Se agrega migración defensiva del esquema de sincronización para bases D1 que pasaron por versiones previas.
9. El primer ingreso carga Stock y fichas técnicas mientras la programación se sincroniza en paralelo, evitando bloquear toda la pantalla.
10. Si la programación sigue vacía, el Resumen muestra el error real de Google y un botón `Reintentar Google`.

Configuración recomendada:

- Sincronización automática: 30 segundos.
- Caché compartida: 30 segundos.
- La base D1 continúa siendo la fuente compartida para los usuarios; Google se consulta solamente cuando la copia necesita refrescarse.
