# Subir a GitHub

Repositorio: `https://github.com/lucs56/erp-bodegaV02.git`

Copiar todo el contenido de esta carpeta dentro del repositorio local `erp-bodegaV02`, reemplazando los archivos existentes y conservando la carpeta oculta `.git`.

Luego ejecutar:

```bash
git status
git add -A
git commit -m "Corregir lectura de Google Sheets y sincronizacion multiusuario"
git push origin main
```

Si el push es rechazado por cambios remotos:

```bash
git pull --rebase origin main
git push origin main
```
